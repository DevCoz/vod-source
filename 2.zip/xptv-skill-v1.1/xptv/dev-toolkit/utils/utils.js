import axios from 'axios'

const $fetch = {
    get: async (url, options = {}) => {
        const response = await axios.get(url, {
            ...options,
            responseType: 'text',
        })
        return { data: response.data }
    },
    download: async (url, options = {}) => {
        const response = await axios.get(url, {
            ...options,
            responseType: 'arraybuffer',
        })
        return { data: response.data }
    },
    post: async (url, body, options = {}) => {
        const response = await axios.post(url, body, {
            ...options,
            responseType: 'text',
        })
        return { data: response.data }
    },
}

const jsonify = (obj) => JSON.stringify(obj)
const argsify = (str) => {
    if (typeof str === 'object' && str !== null) return str
    return JSON.parse(str)
}

const $print = (...args) => {
    console.log('[XPTV]', ...args)
}

export { $fetch, jsonify, argsify, $print }
