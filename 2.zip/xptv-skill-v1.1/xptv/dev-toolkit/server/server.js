import express from 'express'
import * as funcs from '../src/debug.js'

const app = express()
app.use(express.text({ type: '*/*' }))

const PORT = process.env.PORT || 3000

// CORS
app.use((req, res, next) => {
    res.header('Access-Control-Allow-Origin', '*')
    res.header('Access-Control-Allow-Headers', 'Content-Type')
    if (req.method === 'OPTIONS') return res.sendStatus(200)
    next()
})

// Request logging
app.use((req, res, next) => {
    const ts = new Date().toISOString().slice(11, 19)
    const body = typeof req.body === 'string' ? req.body.substring(0, 300) : ''
    console.log(`[${ts}] ${req.method} ${req.path}${body ? '  body=' + body : ''}`)
    next()
})

// Health check
app.get('/', (_req, res) => {
    const routes = Object.keys(funcs).map((name) => {
        const method = name === 'getConfig' || name === 'getLocalInfo' ? 'GET' : 'POST'
        return { name, method, path: `/${name}` }
    })
    res.json({ ok: true, routes })
})

// Register interface routes
Object.keys(funcs).forEach((fnName) => {
    if (fnName === 'getConfig' || fnName === 'getLocalInfo') {
        app.get(`/${fnName}`, async (req, res) => {
            try {
                const result = await funcs[fnName]()
                res.send(result)
            } catch (err) {
                console.error(`[${fnName}] ERROR:`, err.message)
                res.status(500).json({ success: false, error: err.message })
            }
        })
    } else {
        app.post(`/${fnName}`, async (req, res) => {
            try {
                const result = await funcs[fnName](req.body)
                res.send(result)
            } catch (err) {
                console.error(`[${fnName}] ERROR:`, err.message)
                res.status(500).json({ success: false, error: err.message })
            }
        })
    }
})

const server = app.listen(PORT, () => {
    console.log(`XPTV dev server running on http://localhost:${PORT}`)
    console.log(`  GET  http://localhost:${PORT}/           → health + routes`)
    console.log(`  GET  http://localhost:${PORT}/getLocalInfo`)
    console.log(`  GET  http://localhost:${PORT}/getConfig`)
    console.log(`  POST http://localhost:${PORT}/getCards`)
    console.log(`  POST http://localhost:${PORT}/getTracks`)
    console.log(`  POST http://localhost:${PORT}/getPlayinfo`)
    console.log(`  POST http://localhost:${PORT}/search`)
})

// Graceful shutdown
const shutdown = (signal) => {
    console.log(`\n${signal} received, shutting down...`)
    server.close(() => {
        console.log('Server closed.')
        process.exit(0)
    })
    setTimeout(() => process.exit(1), 3000)
}
process.on('SIGINT', () => shutdown('SIGINT'))
process.on('SIGTERM', () => shutdown('SIGTERM'))
