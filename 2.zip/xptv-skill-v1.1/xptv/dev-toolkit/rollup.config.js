import replace from '@rollup/plugin-replace'

/**
 * Rollup 配置：将 dev-toolkit 的 ES module 源码转换为 XPTV 兼容格式
 *
 * 转换规则：
 *   - import { $fetch, jsonify, argsify } from '../utils/utils.js'  → 删除（XPTV 内置）
 *   - import CryptoJS from 'crypto-js'                             → const CryptoJS = createCryptoJS();
 *   - import * as cheerio from 'cheerio'                           → const cheerio = createCheerio();
 *   - export { ... }                                               → 删除（XPTV 自动识别函数）
 *   - console.log / console.error                                  → $print
 */

export default {
    input: 'src/debug.js',
    output: {
        file: 'dist/output.xptv.js',
        format: 'es',
    },
    external: () => false,
    plugins: [
        replace({
            preventAssignment: true,
            delimiters: ['', ''],
            values: {
                "import { $fetch, jsonify, argsify } from '../utils/utils.js'": '',
                "import { \$fetch, jsonify, argsify } from '../utils/utils.js'": '',
                "import CryptoJS from 'crypto-js'": 'const CryptoJS = createCryptoJS();',
                "import * as cheerio from 'cheerio'": 'const cheerio = createCheerio();',
                'export { getLocalInfo, getConfig, getCards, getTracks, getPlayinfo, search }': '',
                'export { getLocalInfo, getConfig, getCards, getTracks, getPlayinfo, search };': '',
                'console.error': '$print',
                'console.log': '$print',
            },
        }),
    ],
}
