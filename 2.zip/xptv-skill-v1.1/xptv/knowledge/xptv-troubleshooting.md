# XPTV 脚本常见问题排查

## 1. 列表为空

**原因 & 解决**:

| 原因 | 检查方法 |
|------|---------|
| HTML 选择器错误 | `console.log(data)` 打印响应，确认 DOM 结构 |
| 动态加载 | 查看 Network 面板，找到实际 API 请求 |
| 请求头缺失 | 添加 User-Agent、Referer |
| 编码问题 | 检查 URL 是否需要 encodeURIComponent |

```js
// 调试技巧：打印响应长度和前 500 字符
console.log('Response length:', data.length);
console.log('Response preview:', data.substring(0, 500));

// 尝试多个选择器
const s1 = $('article.bs');
const s2 = $('.video-item');
const s3 = $('li');
console.log('Selector results:', s1.length, s2.length, s3.length);
```

---

## 2. 无法播放

**原因 & 解决**:

| 原因 | 解决方案 |
|------|---------|
| getPlayinfo 返回无效 URL | 检查 URL 是否完整、可访问 |
| 缺少 Referer | 添加正确的 Referer 请求头 |
| 视频地址加密 | 分析加密方式，用 CryptoJS 解密 |
| iframe 嵌套 | 提取 iframe src，再次请求解析 |

```js
// getPlayinfo 调试
async function getPlayinfo(ext) {
  try {
    ext = argsify(ext);
    const { url } = ext;
    const { data } = await $fetch.get(url);
    
    // 返回调试信息
    return jsonify({
      debug: { url, dataLength: data.length, preview: data.substring(0, 300) },
      urls: [playUrl]
    });
  } catch (e) {
    console.error('getPlayinfo error:', e);
    return jsonify({ urls: [] });
  }
}
```

---

## 3. $fetch.post() 返回异常

**最常见的错误 — 参数格式**:

```js
// ✅ 正确：三个参数 — url, body, options
const { data } = await $fetch.post(url, { key: 'val' }, { headers: {} });

// ❌ 错误：两个参数，data 和 headers 塞在同一个对象中
const { data } = await $fetch.post(url, {
  data: { key: 'val' },
  headers: { 'Content-Type': 'application/json' }
});
```

---

## 4. Base64 解码失败

**原因**: JSC 沙箱中没有 `Buffer` 和 `atob`

```js
// ❌ 不可用
Buffer.from(str, 'base64').toString()
atob(str)

// ✅ 使用 CryptoJS
const CryptoJS = createCryptoJS();
const decoded = CryptoJS.enc.Utf8.stringify(
  CryptoJS.enc.Base64.parse(str)
);
```

---

## 5. 中文乱码

```js
// XML CDATA 标签中的中文
const nameMatch = content.match(/<name><!\[CDATA\[(.*?)\]\]><\/name>/);

// URL 中的中文
const encoded = encodeURIComponent('中文关键词');
```

---

## 6. 分页不工作

确认源站使用的参数名：
- `page` / `pg` / `paged` / `p`
- 页码从 0 还是 1 开始

```js
// 先打印确认
console.log('Current page:', page);
// 尝试不同参数名
url += `&pg=${page}`;   // MacCMS 常用
url += `?paged=${page}`; // WordPress 常用
```

---

## 7. 搜索无结果

```js
// 确认搜索参数名
const url = `${SITE}/?s=${encodeURIComponent(text)}`;      // WordPress
const url = `${API}?ac=list&wd=${encodeURIComponent(text)}`; // MacCMS
const url = `${SITE}/search?q=${encodeURIComponent(text)}`;  // 通用
```

---

## 8. getTracks 返回空剧集

```js
// 确认选择器
console.log('Episodes found:', $('.eplister a').length);

// 如果为空，给一个兜底
if (tracks.length === 0) {
  tracks.push({ name: '播放', ext: { url: ext.url } });
}
```

---

## 9. 跨域/防盗链

```js
// 添加完整请求头
const headers = {
  'User-Agent': UA,
  'Referer': SITE + '/',
  'Origin': SITE,
  'Accept': '*/*'
};
```

---

## 调试流程 Checklist

1. ✅ `getLocalInfo` 返回正确格式
2. ✅ `getConfig` tabs 有内容
3. ✅ `getCards` list 不为空
4. ✅ `getTracks` 能获取剧集
5. ✅ `getPlayinfo` 返回可播放 URL
6. ✅ `search` 能搜到结果
7. ✅ 所有返回都用 `jsonify()` 包装
8. ✅ 所有入参都用 `argsify()` 解析
9. ✅ `console.log` 用于调试，生产环境移除


## 10. 搜索被验证码拦截（smart_verify）

某些 MacCMS 站点搜索需要先通过 `smart_verify`：

**流程**：
1. 首次 GET 搜索页，从 `Set-Cookie` 获取 `PHPSESSID`
2. POST `/index.php/ajax/smart_verify` 提交 `smart_token`
3. 带已验证的 Cookie 重新请求搜索页

**smart_token 生成**：
```js
// 通常格式: MD5(timestamp + secret)
const ts = String(Math.floor(Date.now() / 1000))
const smartToken = CryptoJS.MD5(ts + 'YourSecretHere').toString()

// POST body
`smart_token=${encodeURIComponent(smartToken)}&ts=${ts}`
```

**secret 来源**：前端 JS 中搜索 `smart_verify`、`smart_token` 或 `MySecret` 关键词。

**检测方法**：搜索结果页 HTML 包含 `安全验证` 或 `请输入验证码` 字样。

```js
// 完整实现示例
async function search(ext) {
  ext = argsify(ext)
  const { text, page = 1 } = ext
  const keyword = text || ''
  if (!keyword) return jsonify({ list: [], page })

  const searchUrl = `${SITE}/vod/search.html?wd=${encodeURIComponent(keyword)}`

  // 1. 获取 session
  let cookieStr = ''
  const firstVisit = await $fetch.get(searchUrl, { headers: HEADERS })
  const setCookie = firstVisit.respHeaders?.['set-cookie'] || ''
  const sessMatch = String(setCookie).match(/PHPSESSID=([^;]+)/)
  if (sessMatch) cookieStr = `PHPSESSID=${sessMatch[1]}`

  // 2. 验证 session
  const ts = String(Math.floor(Date.now() / 1000))
  const smartToken = CryptoJS.MD5(ts + SECRET).toString()
  await $fetch.post(`${SITE}/index.php/ajax/smart_verify`,
    `smart_token=${smartToken}&ts=${ts}`,
    { headers: { ...HEADERS, Cookie: cookieStr, 'X-Requested-With': 'XMLHttpRequest' } }
  )

  // 3. 带验证 cookie 搜索
  const { data } = await $fetch.get(searchUrl, { headers: { ...HEADERS, Cookie: cookieStr } })
  // ... 解析结果
}
```

---

## 11. iframe 嵌套播放器无法获取播放地址

**症状**：播放页有 `player_aaaa`，但其 `url` 不是直接的视频地址，而是通过 iframe 加载。

**排查流程**：
```
播放页 → player_aaaa.from → 映射 iframe URL
→ iframe HTML → $.post("xxx.php") 端点
→ 提取 vid/t/token → AES 解密 token
→ POST 端点 → 获取 { code: 200, url: "..." }
```

**常见 iframe 域名模式**：
| from 值 | iframe 模式 |
|---------|------------|
| tudou | `xxx.com/acfun{id}.php` |
| vxdev | `xxx.com/yunbox/?type=vxdev&vid={id}` |
| xgvxcd | `xxx.com/yunbox/?type=vxcd&vid={id}` |
| ykbox | `xxx.com/404.php?host=4khls&vid={id}` |

**关键步骤**：
1. 从 iframe HTML 中用正则 `/\$\.post\("([^"]+)"/` 提取动态端点
2. 提取 `vid`, `t`, `token` 三个变量
3. `token` 需要 AES 解密（key/iv 从前端 JS 逆向）
4. POST 端点时带 `X-Requested-With: XMLHttpRequest` 和正确的 `Origin`

---

## 12. getPlayinfo/getTracks 错误返回格式不一致

**问题**：失败时返回 `{ urls: [], headers: [] }`，但标准应为 `{ urls: [] }`。

```js
// ❌ 错误 — 多余的 headers 字段
return jsonify({ urls: [], headers: [] })

// ✅ 正确 — 标准格式
return jsonify({ urls: [] })
```

同理 getTracks：
```js
// ❌
return jsonify({ list: [], info: {}, headers: [] })

// ✅
return jsonify({ list: [], info: {} })
```

**规则**：错误返回只保留核心数据字段，不添加空的辅助字段。


## 13. execB / 解密函数被混淆 (jsjiami.com v6)

**症状**：getPlayinfo 中的 `execB()` / `decryptPlayUrl()` 内部全是 `_0x` 变量，尝试多种 key/IV 组合均失败。

**原因**：jsjiami.com v6 对解密函数进行了深度混淆，包括：
- RC4 字符串加密（所有字符串字面量被加密）
- 死代码注入（大量无用分支）
- 反调试检测（检测 DevTools / console.clear）
- 控制流平坦化（if/else 变成 switch 跳转）

**诊断方法**：

```bash
# 1. 确认是否 jsjiami 混淆
curl -s 'https://example.com/static/player/artplayer/?url=XXX' \
  -H 'User-Agent: Mozilla/5.0' | head -3
# 如果包含 "jsjiami.com.v6" 则确认

# 2. 提取 HTML 中的静态变量（混淆代码可能保留）
curl -s 'https://example.com/static/player/artplayer/?url=XXX' \
  -H 'User-Agent: Mozilla/5.0' | \
  grep -oP '(const|var|let)\s+(isSmartPlay|secretKeySeed|timestamp|playPageUrl)\s*=\s*[^;]+'

# 3. 搜索 API endpoint
curl -s 'https://example.com/static/player/artplayer/?url=XXX' \
  -H 'User-Agent: Mozilla/5.0' | \
  grep -oP 'https?://[^\s"\\]+' | grep -iE 'api|smart|play|webvideo' | sort -u
```

**解决方案**：

静态分析不可行。必须使用 **Puppeteer + CryptoJS 运行时 hook** 捕获真实参数：

1. 用 `evaluateOnNewDocument` 在页面加载前注入 hook
2. 替换 `CryptoJS.AES.decrypt` 和 `CryptoJS.MD5` 捕获每次调用的参数
3. 监控 `fetch` / `XMLHttpRequest` 捕获 API 请求
4. 从 hook 日志中提取真实的 key/IV 对和隐藏 secret

详细步骤参见 `knowledge/xptv-runtime-debug.md`。

## 14. Smart Play API 模式

**症状**：播放页有 `const isSmartPlay = true`，网络请求中有 POST 到外部域名的 API，但 getPlayinfo 总是返回空。

**排查流程**：

```
播放页 → player_aaaa(含 playPageUrl/secretKeySeed/timestamp)
→ POST 远程 API (带 signature) → 返回 { code: 200, url: "加密字符串" }
→ execB(encryptedUrl, timestamp) → 明文播放地址
```

**常见坑**：

| 问题 | 原因 | 解决 |
|------|------|------|
| API 返回 400 Invalid signature | 签名算法不对 | hook MD5 捕获签名计算 |
| API 返回 200 但 execB 解密失败 | HIDDEN_SECRET 变了 | 重新 Puppeteer hook |
| `const timestamp` 不存在 | 变量名变了 | grep `timestamp\|timeStamp\|ts` |
| API endpoint 返回 404 | URL 路径变了 | grep `ticktockwow\|smartplay\|webvideo` |
| execB 解密出的 URL 被截断 | Pkcs7 padding 问题 | 检查 hex-to-ASCII 转换是否正确 |

**vkey 和 code 的区别**：
- `vkey` = HTML 中 `const playPageUrl` 的值（传给 API 做视频标识）
- `code` = HTML 中 `const secretKeySeed` 的值（传给 API 做鉴权）
- 这两者 **不是** execB 的 key derivation 输入
- execB 使用的是混淆代码中硬编码的隐藏 secret（如 `RY7e48naFXPsLJC`）
