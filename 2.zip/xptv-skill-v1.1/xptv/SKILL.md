---
name: xptv
description: "XPTV 脚本开发技能 — 创建、调试和维护 XPTV 本地 JavaScript 脚本（.xptv.js）。覆盖六大接口、MacCMS API、HTML 爬取、网盘源、筛选、搜索和播放解析。触发词：xptv, 写源, xptv脚本, 视频源, 播放源, 写爬虫, 抓取视频, source script, .xptv.js"
---

# XPTV Script Development Skill

## When to Use
- User asks to write/create an XPTV source script
- User asks to fix/debug an existing `.xptv.js` script
- User asks about XPTV script interfaces, data formats, or best practices
- User provides a website and wants an XPTV source for it

## Quick Decision Tree

```
用户请求 → 确定操作类型：
  ├─ 脚本已混淆(jsjiami等) → 直接跳转「运行时调试」(knowledge/xptv-runtime-debug.md)
  ├─ 创建新源 → Step 1: 识别API类型
  ├─ 调试已有脚本 → 直接跳转「调试流程」
  └─ 咨询接口/格式问题 → 查阅 knowledge/ 回答
```

## Reference Documents

Read these files for detailed specs before writing any script:

1. **API Reference**: `knowledge/xptv-api-reference.md` — All six interfaces, parameters, return formats
2. **Toolbox**: `knowledge/xptv-toolbox.md` — `$fetch`, `createCheerio()`, `createCryptoJS()`, helpers
3. **Templates**: `knowledge/xptv-templates.md` — MacCMS API, HTML scraping, cloud drive source templates
4. **Troubleshooting**: `knowledge/xptv-troubleshooting.md` — Common errors and fixes
5. **Runtime Debug**: `knowledge/xptv-runtime-debug.md` — Puppeteer hook for obfuscated code

## Core Architecture

### Six Interfaces
```
getLocalInfo()  → { ver, name, api, type?, }   ← 元数据（见下方说明）
getConfig()     → { ver, title, site, tabs[{name, ext}] }
getCards(ext)   → { list[{vod_id, vod_name, vod_pic, vod_remarks, ext}], filter? }
getTracks(ext)  → { list[{title, tracks[{name, pan?, ext}]}], info? }
getPlayinfo(ext)→ { urls[], headers?[] }
search(ext)     → { list[], page? }
```

> **getLocalInfo 说明**：本地 `.xptv.js` 文件**必须**实现，用于 XPTV 识别和管理源。
> 远程订阅源可省略。不确定时建议实现（不会出错）。`api` 字段必须全局唯一（如 `csp_sitename`）。

### Data Flow
```
getLocalInfo()                     ← 独立调用，XPTV 用此识别和管理源
getConfig.tabs[].ext → getCards(ext)
getCards.list[].ext  → getTracks(ext)
getTracks.list[].tracks[].ext → getPlayinfo(ext)
```

### Cloud Drive (网盘) Pattern
```
getTracks: tracks[].pan = "https://pan.quark.cn/s/..."
getPlayinfo: return { urls: [] }  // empty — player handles pan directly
```

### Critical Rules
1. **All returns**: wrap in `jsonify()`, never return raw objects
2. **All params**: parse with `argsify(ext)`, never use ext as string
3. **$fetch.post()**: `$fetch.post(url, body, { headers: {...} })` — three params: url, body, options
4. **Base64**: Use `createCryptoJS()` — no `Buffer` or `atob` in JSC sandbox
5. **File naming**: `[name].xptv.js`

## Execution Steps (创建新源)

### Step 1: 识别 API 类型
```
要求用户提供目标站点URL。
如果用户未提供URL，询问：
  - 站点地址是什么？
  - 你希望抓取什么内容（电影/电视剧/动漫/直播）？

根据以下信号判断 API 类型：
| 信号                              | 类型         | 模板     |
|-----------------------------------|-------------|----------|
| URL 含 /api.php/provide/vod/      | MacCMS      | T1 或 T4  |
| 网页有视频列表 DOM                | HTML 爬取   | T2       |
| 数据来自网盘分享链接              | 网盘源       | T3       |
| Cloudflare / 人机验证             | HTML+过盾   | T5       |
| 实时流、多 CDN                    | 直播源       | T6       |
| 播放页有 player_aaaa 变量        | 多层加密     | T7       |
| 播放页加载 iframe + POST API      | iframe嵌套播放器 | T8       |
```

**🔎 Checkpoint 1 — 确认API类型**
在继续之前，向用户展示：
- 你的判断结果（属于哪种类型）
- 对应的模板编号
- 简要说明该类型的执行方案
等待用户确认后进入 Step 2。

### Step 2: 获取目标站点信息
```
根据模板类型，需要从用户获取：
- MacCMS: API地址（完整URL）
- HTML爬取: 目标页面URL，确认DOM结构（选择器）
- 网盘: 数据来源URL，网盘类型（夸克/阿里/115/天翼）
- 直播: 站点URL，是否需要签名认证
- 多层加密: 播放页URL，已知的加密方式

如果无法直接获取，使用 web_fetch 抓取目标页面分析结构。
```

### Step 3: 实现六个接口
```
按模板实现，严格遵循以下清单：

□ getLocalInfo() — api字段全局唯一（如 csp_sitename）
□ getConfig()    — 返回 tabs 列表，每个 tab 带 ext 参数
□ getCards(ext)  — 解析 ext 获取 id/page，用 argsify()
□ getTracks(ext) — 解析视频详情页，提取播放线路
□ getPlayinfo(ext) — 提取实际播放地址，必须 try-catch
□ search(ext)    — 实现搜索功能

每个接口必须：
- 入参用 argsify(ext) 解析
- 返回用 jsonify() 包装
- getPlayinfo 外包 try-catch，失败返回 { urls: [] }
```

**🔎 Checkpoint 2 — 代码审查**
六个接口写完后，执行以下检查并将结果展示给用户：
- [ ] 所有 6 个接口都实现了？（远程源可省略 getLocalInfo）
- [ ] 所有返回都用 jsonify() 包装？
- [ ] 所有入参都用 argsify() 解析？
- [ ] getPlayinfo 外包 try-catch，失败返回 `{ urls: [] }`（无 headers 字段）？
- [ ] `$fetch.post()` 使用三参数格式？（url, body, options）
- [ ] Base64 使用 CryptoJS 而非 Buffer/atob？
- [ ] getLocalInfo 的 api 字段不与其他源冲突？
- [ ] 请求头包含 User-Agent 和 Referer？
- [ ] 无注释掉的 createCheerio()/createCryptoJS() 残留？
- [ ] 无硬编码密钥散落在多处？（集中到文件顶部常量区）
等待用户确认后进入测试。

### Step 4: 测试验证（必须执行）

**⚠️ 每个源写完后必须跑完整测试，不跳过。**

#### 搭建测试环境
```bash
# 在 workspace 创建临时测试目录
mkdir -p {name}-devtoolkit/src {name}-devtoolkit/server {name}-devtoolkit/utils
# 复制 dev-toolkit 基础文件
cp skills/xptv/dev-toolkit/utils/utils.js {name}-devtoolkit/utils/
cp skills/xptv/dev-toolkit/server/server.js {name}-devtoolkit/server/
cp skills/xptv/dev-toolkit/package.json {name}-devtoolkit/
# 转换源码为 ES module 格式
echo "import { \$fetch, jsonify, argsify } from '../utils/utils.js'" > {name}-devtoolkit/src/debug.js
echo "import * as cheerio from 'cheerio'" >> {name}-devtoolkit/src/debug.js
# 追加源码（替换 createCheerio/createCryptoJS 为 ES module import，删除注释残留）
sed 's/^const cheerio = createCheerio();//' {name}.xptv.js | \
  sed 's/^const CryptoJS = createCryptoJS()/import CryptoJS from "crypto-js"/' | \
  sed '/\/\/ const cheerio = createCheerio()/d' | \
  sed '/\/\/ const CryptoJS = createCryptoJS()/d' >> {name}-devtoolkit/src/debug.js
# 添加 export
echo "export { getLocalInfo, getConfig, getCards, getTracks, getPlayinfo, search }" >> {name}-devtoolkit/src/debug.js
# 安装依赖并启动
cd {name}-devtoolkit && npm install && node server/server.js &
```

#### 测试检查表（逐接口）

```bash
# 1. getLocalInfo
curl -s http://localhost:3000/getLocalInfo
# 验证: 返回 ver, name, api(唯一), type

# 2. getConfig
curl -s http://localhost:3000/getConfig
# 验证: 返回 tabs 列表，每个 tab 有 name 和 ext

# 3. getCards
curl -s -X POST http://localhost:3000/getCards -H "Content-Type: text/plain" -d '{"page":1}'
# 验证: list 不为空，每个 item 有 vod_id/vod_name/vod_pic/vod_remarks/ext

# 4. getTracks
curl -s -X POST http://localhost:3000/getTracks -H "Content-Type: text/plain" -d '{"id":"房间ID"}'
# 验证: list 有 title+tracks，每个 track 有 name 和 ext.url

# 5. getPlayinfo
curl -s -X POST http://localhost:3000/getPlayinfo -H "Content-Type: text/plain" -d '{"url":"测试URL"}'
# 验证: urls 数组不为空，headers 可选

# 6. search
curl -s -X POST http://localhost:3000/search -H "Content-Type: text/plain" -d '{"text":"测试关键词"}'
# 验证: list 有结果（或明确说明该源不支持搜索）
```

#### 测试报告模板
```
╔══════════════════════════════════════╗
║    {源名} XPTV 源 — 测试报告        ║
╠══════════════════════════════════════╣
║ getLocalInfo  ✅/❌                  ║
║ getConfig    ✅/❌  N tabs           ║
║ getCards     ✅/❌  N rooms          ║
║ getTracks    ✅/❌  N lines          ║
║ getPlayinfo  ✅/❌                   ║
║ search       ✅/❌  N results        ║
╠══════════════════════════════════════╣
║ 结论: 通过/需修复                    ║
╚══════════════════════════════════════╝
```

#### 清理测试环境
```bash
kill $(lsof -t -i:3000) 2>/dev/null
rm -rf {name}-devtoolkit
```

**🔎 Checkpoint 3 — 测试结果**
展示完整测试报告。所有接口通过后进入交付，否则回到 Step 3 修复并重新测试。

### Step 5: 交付与存档
```
- 保存最终脚本为 [name].xptv.js
- 向用户说明使用方法（导入 XPTV 的步骤）
- 如有 dev-toolkit，说明如何本地调试
```

## 调试流程 (Fix Existing Script)

当用户提供出错的脚本时：

### D1: 收集信息
```
- 获取脚本内容
- 获取错误症状（列表为空？无法播放？搜索无结果？）
- 获取目标站点URL
```

### D2: 定位问题
```
根据症状对照 knowledge/xptv-troubleshooting.md：

| 症状           | 优先检查                          |
|---------------|----------------------------------|
| 列表为空        | 选择器、请求头、动态加载、编码     |
| 无法播放        | getPlayinfo URL、Referer、加密    |
| $fetch.post异常 | 参数格式（三参数 vs 两参数）       |
| Base64 失败     | 用 CryptoJS，不用 Buffer/atob    |
| 分页不工作      | 参数名(page/pg/paged)、起始值     |
| 搜索无结果      | 参数名(wd/text/q)、编码           |
| 中文乱码        | CDATA解析、URL编码               |
| 搜索被验证码拦截 | 检查 smart_verify、PHPSESSID cookie |
| iframe 播放器无结果 | 检查 iframe src、POST 端点、token 解密 |
| getPlayinfo 返回空 headers | 应返回 `{ urls: [] }` 而非 `{ urls: [], headers: [] }` |
```

**🔎 Checkpoint — 问题定位**
向用户展示：
- 定位到的问题根因
- 对应的修复方案
等待用户确认后再动手改代码。

### D3: 修复并验证
```
修复后，再次执行 Step 4 的检查清单确认修复。
```


## Fallback Strategies

当首选方案失败时，按以下优先级尝试备选方案：

### API 类型误判时的 Fallback
```
尝试 MacCMS XML 失败 → 尝试 MacCMS JSON (Template 4)
尝试 HTML 爬取失败 → 检查是否是JS渲染（需浏览器环境）→ 告知用户限制
尝试获取播放地址失败 → 检查是否有iframe嵌套 → 递归提取iframe中的播放地址
```

### 请求失败时的 Fallback
```
$fetch.get 返回空/403 → 更换 User-Agent → 添加 Referer → 添加 Cookie → 报告失败
$fetch.post 参数错误 → 尝试 form-urlencoded → 尝试 JSON body → 尝试无 Content-Type
```

### 解析失败时的 Fallback
```
XML 解析失败 → 尝试 JSON 解析 → 尝试 cheerio HTML 解析
cheerio 选择器为空 → 输出前500字符分析DOM → 尝试备选选择器
加密解密失败 → 输出加密原始值 → 提示用户提供前端JS逆向
加密代码被混淆(jsjiami.com v6等) → 静态分析不可行 → 跳转「运行时调试」(knowledge/xptv-runtime-debug.md)
```

### getPlayinfo 返回空时的处理
```
1. 检查播放页是否有 iframe → 提取 iframe src 重新请求
2. 检查是否有动态加载的JS变量（如 player_aaaa）→ 用正则/大括号计数法提取
3. 检查 iframe 中是否有 POST 端点（$.post("xxx.php")）→ 提取 vid/t/token 后 POST
4. 检查是否是网盘链接 → 返回 { urls: [] }，由播放器处理 pan 字段
5. 以上都失败 → 返回 { urls: [] } 并在脚本中 $print 错误信息
```

### 搜索被验证码拦截时的处理
```
1. 检查是否有 smart_verify 机制 → 先 POST /index.php/ajax/smart_verify 获取 token
2. 检查是否需要 Cookie Session → 首次请求获取 PHPSESSID，后续带 cookie
3. smart_token 通常 = MD5(timestamp + secret)，secret 在前端 JS 中
```


## End-to-End Example (完整示例)

### 用户请求
> "帮我写一个XPTV源，目标站是 https://api.example.com，JSON API，返回视频列表"

### 执行流程

**Step 1**: 识别为 JSON API 类型（Template 4），向用户确认：
> 我判断目标站为 JSON API 类型，将使用 Template 4。确认后继续？

**Step 2**: 获取信息 — 用户提供URL，用 web_fetch 抓取分析API返回格式

**Step 3**: 实现六个接口（基于 Template 4 修改 SITE 和字段映射）：

\`\`\`js
// 示例：关键接口实现要点
async function getCards(ext) {
  ext = argsify(ext);                        // ← 必须 argsify
  const { id, page = 1 } = ext;
  const { data } = await $fetch.get(\`\${SITE}/videos?page=\${page}\`, {
    headers: { 'User-Agent': UA }            // ← 必须有 UA
  });
  const json = argsify(data);
  return jsonify({                            // ← 必须 jsonify
    list: json.data.map(item => ({
      vod_id: String(item.id),
      vod_name: item.title,
      vod_pic: item.thumbnail || '',
      ext: { id: String(item.id) }           // ← ext 传给 getTracks
    })),
    page
  });
}

async function getPlayinfo(ext) {
  ext = argsify(ext);
  const { url } = ext;
  if (!url) return jsonify({ urls: [] });     // ← 空URL兜底
  try {                                        // ← 必须 try-catch
    const { data } = await $fetch.get(url, { headers: { 'User-Agent': UA } });
    const json = argsify(data);
    return jsonify({ urls: json.urls || [json.url] || [] });
  } catch (e) {
    return jsonify({ urls: [] });             // ← 失败兜底
  }
}
\`\`\`

**Checkpoint 2**: 检查清单全部打勾 → 用户确认

**Step 4**: 检查 dist/output.xptv.js 编译产物，确认无语法错误

**Step 5**: 交付 [name].xptv.js，说明导入方式

## Anti-Patterns (DO NOT)
- Skip any of the 6 interfaces
- Use `Buffer.from()` or `atob()` for base64
- Pass `$fetch.post(url, data, { headers })` with wrong parameter structure
- Return raw objects without `jsonify()`
- Forget `argsify(ext)` on input parameters
- Use `console.log()` for production (use only for debugging)
- **`api` 字段重复**：`getLocalInfo` 返回的 `api: "csp_xxx"` 必须全局唯一，否则 XPTV 会和其他源冲突
- 跳过检查点直接执行下一步
- **注释掉的 createCheerio()/createCryptoJS() 残留**：dev-toolkit 转换后必须删除所有 `// const xxx = createXxx()` 行
- **重复解析逻辑**：将 DOM 解析提取为公共函数，在多处复用而非复制粘贴
- **错误返回格式不一致**：getPlayinfo/getTracks 失败时返回 `{ urls: [] }` 或 `{ list: [] }`，不要加多余的 `headers: []`

## Error Recovery

| 错误场景 | 处理方式 |
|---------|---------|
| 目标站点无法访问 | 提示用户检查URL，尝试不同UA，建议备用方案 |
| API返回格式与预期不符 | 打印响应前500字符分析，调整解析逻辑 |
| 加密方式未知 | 引导用户提供前端JS代码片段，分析解密逻辑 |
| 选择器无法匹配DOM | 使用 web_fetch 抓取页面，分析实际DOM结构 |
| getPlayinfo返回空 | 检查播放页是否有iframe嵌套、重定向、动态加载 |

## Local Development Toolkit

For complex scripts (API signing, encryption, multi-step auth), use the local dev toolkit in `dev-toolkit/`:

- **Write in ES module** (`src/debug.js`) with standard `import` syntax
- **Test locally** via Express server (`npm run dev` → localhost:3000)
- **Build to XPTV** via rollup (`npm run build` → `dist/output.xptv.js`)
- Rollup auto-replaces `import CryptoJS` → `createCryptoJS()`, etc.

See `dev-toolkit/README.md` for full workflow.
