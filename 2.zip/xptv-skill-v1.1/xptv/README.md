# XPTV 本地开发工具链

## 目录结构

```
dev-toolkit/
├── src/debug.js        ← 源码（ES module，IDE 友好）
├── utils/utils.js      ← 本地模拟 XPTV 沙箱 API
├── server/server.js    ← Express 测试服务器
├── sub-debug.js        ← XPTV 代理脚本（转发到本地 server）
├── dist/script.js      ← rollup 编译产物（生产用 .xptv.js）
├── debug.json          ← XPTV 配置片段
├── rollup.config.js    ← rollup 编译配置
└── package.json        ← 依赖声明
```

## 使用流程

### 1. 初始化项目
```bash
mkdir my-xptv-project && cd my-xptv-project
# 复制 dev-toolkit 内容到项目
cp -r /path/to/dev-toolkit/* .
npm install
```

### 2. 开发调试
```bash
# 启动测试服务器
npm run dev
# 服务器运行在 http://localhost:3000
```

将 `sub-debug.js` 的内容作为 XPTV 源导入（或修改 `debug.json` 中的地址），
XPTV 客户端会把请求转发到本地 server，实现**实时调试**。

### 3. 编译生产脚本
```bash
npm run build
# 产出 → dist/script.js
```

rollup 会自动替换：
- `import CryptoJS from 'crypto-js'` → `const CryptoJS = createCryptoJS();`
- `import * as cheerio from 'cheerio'` → `const cheerio = createCheerio();`
- 移除 ES module import/export 语法

### 4. 从零开始写新源
1. 复制 `src/debug.js` 为 `src/your-source.js`
2. 修改 `rollup.config.js` 的 `input` 指向新文件
3. 用标准 Node.js 语法写（import cheerio、CryptoJS 等）
4. `npm run dev` 测试 → `npm run build` 编译

## 核心优势

| 痛点 | 解决方案 |
|------|---------|
| XPTV 沙箱没有 `import` | 本地用 ES module，编译时自动替换 |
| 没有 cheerio/CryptoJS 包 | npm 安装，本地调试，编译时映射到沙箱 API |
| 没法直接跑 `console.log` | 本地 Node.js 完整调试能力 |
| 反复导入 XPTV 测试 | 代理模式：改代码 → 刷新 XPTV 即可 |
