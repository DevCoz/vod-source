#!/usr/bin/env node

/**
 * XPTV Harness — 本地测试运行器
 *
 * 用法：
 *   node xptv_harness.js smoke <script.xptv.js> [--keyword 测试]
 *   node xptv_harness.js run   <script.xptv.js> --fn getPlayinfo --ext '{"url":"..."}'
 *   node xptv_harness.js list  <script.xptv.js>
 *   node xptv_harness.js analyze <url>
 *
 * smoke:   跑全部 6 个接口的自动测试
 * run:     单步执行指定接口
 * list:    列出脚本实现的接口
 * analyze: 分析目标站点的 API 类型
 */

import { readFileSync, existsSync } from 'fs'
import { resolve, dirname, basename } from 'path'
import { fileURLToPath } from 'url'
import axios from 'axios'
import * as cheerio from 'cheerio'
import CryptoJS from 'crypto-js'

const __dirname = dirname(fileURLToPath(import.meta.url))

// ===== XPTV 运行时模拟 =====

const DEFAULT_TIMEOUT = 20000

const $fetch = {
  get: async (url, options = {}) => {
    const cfg = {
      ...options,
      responseType: 'text',
      timeout: options.timeout || DEFAULT_TIMEOUT,
      validateStatus: () => true,
    }
    const resp = await axios.get(url, cfg)
    return {
      data: resp.data,
      status: resp.status,
      headers: resp.headers || {},
      respHeaders: resp.headers || {},  // 兼容 XPTV 的 respHeaders 访问方式
    }
  },
  download: async (url, options = {}) => {
    const cfg = {
      ...options,
      responseType: 'arraybuffer',
      timeout: options.timeout || DEFAULT_TIMEOUT,
      validateStatus: () => true,
    }
    const resp = await axios.get(url, cfg)
    return {
      data: resp.data,
      status: resp.status,
      headers: resp.headers || {},
      respHeaders: resp.headers || {},
    }
  },
  post: async (url, body, options = {}) => {
    const cfg = {
      ...options,
      responseType: 'text',
      timeout: options.timeout || DEFAULT_TIMEOUT,
      validateStatus: () => true,
    }
    const resp = await axios.post(url, body, cfg)
    return {
      data: resp.data,
      status: resp.status,
      headers: resp.headers || {},
      respHeaders: resp.headers || {},
    }
  },
}

const jsonify = (obj) => JSON.stringify(obj)
const argsify = (str) => {
  if (typeof str === 'object' && str !== null) return str
  return JSON.parse(str)
}
const $print = (...args) => console.log('[XPTV]', ...args)

const _cache = new Map()
const $cache = {
  get: (key) => {
    const entry = _cache.get(key)
    if (!entry) return null
    if (entry.expire > 0 && Date.now() > entry.expire) { _cache.delete(key); return null }
    return entry.value
  },
  set: (key, value, ttlSeconds = 0) => {
    _cache.set(key, { value, expire: ttlSeconds > 0 ? Date.now() + ttlSeconds * 1000 : 0 })
  },
  del: (key) => _cache.delete(key),
}

const $utils = {
  toastInfo: (msg) => console.log(`[TOAST:INFO] ${msg}`),
  toastError: (msg) => console.log(`[TOAST:ERROR] ${msg}`),
  os: () => 'Harness/1.0',
  app: () => '2.0',
  openSafari: (url, ua) => {
    console.log(`[OPEN_SAFARI] ${url}${ua ? ` | ${ua}` : ''}`)
  },
}

// 旧版 XPTV 脚本常见内置 HTML helper；新脚本建议用 createCheerio()/cheerio.load。
const $html = {
  _load: (input) => {
    if (typeof input === 'string') return cheerio.load(input)
    return null
  },
  elements: (input, selector) => {
    if (typeof input === 'string') {
      const $ = cheerio.load(input)
      return $(selector).toArray()
    }
    return cheerio.load('')(input).find(selector).toArray()
  },
  attr: (input, selector, name) => {
    if (typeof input === 'string') {
      const $ = cheerio.load(input)
      return $(selector).first().attr(name) || ''
    }
    const $ = cheerio.load('')
    return selector ? $(input).find(selector).first().attr(name) || '' : $(input).attr(name) || ''
  },
  text: (input, selector) => {
    if (typeof input === 'string') {
      const $ = cheerio.load(input)
      return $(selector).first().text() || ''
    }
    const $ = cheerio.load('')
    return selector ? $(input).find(selector).first().text() || '' : $(input).text() || ''
  },
  html: (input, selector) => {
    if (typeof input === 'string') {
      const $ = cheerio.load(input)
      return $(selector).first().html() || ''
    }
    const $ = cheerio.load('')
    return selector ? $(input).find(selector).first().html() || '' : $(input).html() || ''
  },
}

const INTERFACES = ['getLocalInfo', 'getConfig', 'getCards', 'getTracks', 'getPlayinfo', 'search']

function isObject(value) {
  return value !== null && typeof value === 'object' && !Array.isArray(value)
}

function parseInterfaceReturn(raw, strict = false) {
  const warnings = []
  if (typeof raw !== 'string') {
    if (strict) throw new Error('return value must be a JSON string from jsonify()')
    warnings.push('returned raw object, expected jsonify() string')
    return { parsed: raw, warnings }
  }
  try {
    return { parsed: JSON.parse(raw), warnings }
  } catch (err) {
    throw new Error(`invalid JSON string: ${err.message}`)
  }
}

function validateCard(card, path = 'list[]') {
  const issues = []
  if (!isObject(card)) return [`${path} must be an object`]
  if (!('vod_id' in card)) issues.push(`${path}.vod_id missing`)
  if (!card.vod_name) issues.push(`${path}.vod_name missing`)
  if (!('ext' in card)) issues.push(`${path}.ext missing`)
  else if (!isObject(card.ext)) issues.push(`${path}.ext must be an object`)
  return issues
}

function validateSchema(name, parsed, { strict = false } = {}) {
  const issues = []
  const warnings = []
  if (!isObject(parsed)) return { issues: [`${name} must return an object`], warnings }

  if (name === 'getLocalInfo') {
    if (parsed.ver === undefined) issues.push('ver missing')
    if (!parsed.name) issues.push('name missing')
    if (!parsed.api) issues.push('api missing')
    if (parsed.api && !String(parsed.api).startsWith('csp_')) warnings.push('api should usually start with csp_')
    if (parsed.type !== undefined && ![3, 4].includes(parsed.type)) warnings.push('type should be 3(VOD) or 4(live)')
  } else if (name === 'getConfig') {
    if (parsed.ver === undefined) issues.push('ver missing')
    if (!parsed.title) issues.push('title missing')
    if (!parsed.site) warnings.push('site missing')
    if (!Array.isArray(parsed.tabs)) issues.push('tabs must be an array')
    else if (strict && parsed.tabs.length === 0) issues.push('tabs is empty')
    else parsed.tabs.forEach((tab, i) => {
      if (!isObject(tab)) issues.push(`tabs[${i}] must be an object`)
      else {
        if (!tab.name) issues.push(`tabs[${i}].name missing`)
        if (!isObject(tab.ext)) issues.push(`tabs[${i}].ext must be an object`)
      }
    })
  } else if (name === 'getCards' || name === 'search') {
    if (!Array.isArray(parsed.list)) issues.push('list must be an array')
    else {
      if (strict && parsed.list.length === 0) issues.push('list is empty')
      parsed.list.forEach((card, i) => issues.push(...validateCard(card, `list[${i}]`)))
    }
  } else if (name === 'getTracks') {
    if (!Array.isArray(parsed.list)) issues.push('list must be an array')
    else {
      if (strict && parsed.list.length === 0) issues.push('track group list is empty')
      parsed.list.forEach((group, i) => {
        if (!isObject(group)) issues.push(`list[${i}] must be an object`)
        else {
          if (!group.title) issues.push(`list[${i}].title missing`)
          if (!Array.isArray(group.tracks)) issues.push(`list[${i}].tracks must be an array`)
          else {
            if (strict && group.tracks.length === 0) issues.push(`list[${i}].tracks is empty`)
            group.tracks.forEach((track, j) => {
              if (!isObject(track)) issues.push(`list[${i}].tracks[${j}] must be an object`)
              else {
                if (!track.name) issues.push(`list[${i}].tracks[${j}].name missing`)
                if (!track.pan && !isObject(track.ext)) issues.push(`list[${i}].tracks[${j}] needs pan or ext object`)
              }
            })
          }
        }
      })
    }
  } else if (name === 'getPlayinfo') {
    if (!Array.isArray(parsed.urls)) issues.push('urls must be an array')
    if (parsed.headers !== undefined && !Array.isArray(parsed.headers)) issues.push('headers must be an array when present')
    if (parsed.headers !== undefined && Array.isArray(parsed.urls) && parsed.urls.length === 0) warnings.push('omit headers when urls is empty')
    if (strict && Array.isArray(parsed.urls) && parsed.urls.length === 0) warnings.push('urls is empty; valid for cloud-drive sources only')
  }

  return { issues, warnings }
}

function summarizeParsed(parsed) {
  let summary = ''
  if (parsed?.list) summary += ` | ${parsed.list.length} items`
  if (parsed?.tabs) summary += ` | ${parsed.tabs.length} tabs`
  if (parsed?.urls) summary += ` | ${parsed.urls.length} urls`
  if (parsed?.name) summary += ` | ${parsed.name}`
  if (parsed?.ver !== undefined) summary += ` | ver=${parsed.ver}`
  return summary
}

// ===== 脚本加载 =====

function loadScript(scriptPath) {
  const absPath = resolve(scriptPath)
  if (!existsSync(absPath)) {
    console.error(`Error: File not found: ${absPath}`)
    process.exit(1)
  }

  let code = readFileSync(absPath, 'utf8')

  // 转换 XPTV 内置函数调用为 harness 实现
  code = code.replace(/const\s+CryptoJS\s*=\s*createCryptoJS\(\)\s*;?/g, '')
  code = code.replace(/const\s+cheerio\s*=\s*createCheerio\(\)\s*;?/g, '')

  // 用 Function 构造器模拟 XPTV 沙箱
  const wrapper = new Function(
    '$fetch', 'jsonify', 'argsify', '$print', '$cache', '$utils', '$html',
    'CryptoJS', 'cheerio', '$config_str', 'createCheerio', 'createCryptoJS', 'loadJSEncrypt',
    `${code}\n;return {
      getLocalInfo: typeof getLocalInfo !== 'undefined' ? getLocalInfo : undefined,
      getConfig: typeof getConfig !== 'undefined' ? getConfig : undefined,
      getCards: typeof getCards !== 'undefined' ? getCards : undefined,
      getTracks: typeof getTracks !== 'undefined' ? getTracks : undefined,
      getPlayinfo: typeof getPlayinfo !== 'undefined' ? getPlayinfo : undefined,
      search: typeof search !== 'undefined' ? search : undefined,
    }`
  )

  const funcs = wrapper(
    $fetch, jsonify, argsify, $print, $cache, $utils, $html,
    CryptoJS, cheerio, '{}', () => cheerio, () => CryptoJS, () => ({})
  )

  // 过滤掉 undefined 的接口
  const available = {}
  for (const [name, fn] of Object.entries(funcs)) {
    if (typeof fn === 'function') available[name] = fn
  }
  return available
}

// ===== 带超时的接口执行 =====

async function runWithTimeout(fn, body, timeoutMs = DEFAULT_TIMEOUT) {
  return Promise.race([
    body !== undefined ? fn(body) : fn(),
    new Promise((_, reject) =>
      setTimeout(() => reject(new Error(`timeout after ${timeoutMs}ms`)), timeoutMs)
    )
  ])
}

// ===== Smoke Test =====

async function smokeTest(scriptPath, opts = {}) {
  const funcs = loadScript(scriptPath)
  const keyword = opts.keyword || 'test'
  const perInterfaceTimeout = opts.timeout || DEFAULT_TIMEOUT
  const strict = Boolean(opts.strict)
  const results = {}

  const run = async (name, body) => {
    const fn = funcs[name]
    if (!fn) {
      results[name] = { ok: strict ? false : null, summary: 'not implemented' }
      return
    }
    const start = Date.now()
    try {
      const data = await runWithTimeout(fn, body, perInterfaceTimeout)
      const { parsed, warnings: returnWarnings } = parseInterfaceReturn(data, strict)
      const { issues, warnings: schemaWarnings } = validateSchema(name, parsed, { strict })
      const ms = Date.now() - start
      const warnings = [...returnWarnings, ...schemaWarnings]
      let summary = `${ms}ms${summarizeParsed(parsed)}`
      if (warnings.length) summary += ` | ⚠ ${warnings.length} warning(s)`
      if (issues.length) {
        results[name] = { ok: false, error: issues.join('; '), warnings, ms }
      } else {
        results[name] = { ok: true, summary, warnings }
      }
    } catch (err) {
      results[name] = { ok: false, error: err.message, ms: Date.now() - start }
    }
  }

  console.log(`\n🧪 Smoke test: ${basename(scriptPath)}${strict ? ' (strict)' : ''}\n`)

  // 1. getLocalInfo
  await run('getLocalInfo')

  // 2. getConfig
  await run('getConfig')

  // 3. getCards — 用 getConfig 的第一个 tab
  let firstTabExt = '{"page":1,"id":"1"}'
  try {
    if (funcs.getConfig) {
      const cfgData = await runWithTimeout(funcs.getConfig, undefined, perInterfaceTimeout)
      const { parsed: cfg } = parseInterfaceReturn(cfgData, false)
      if (cfg?.tabs?.[0]?.ext) {
        firstTabExt = JSON.stringify({ ...cfg.tabs[0].ext, page: 1 })
      }
    }
  } catch {}
  await run('getCards', firstTabExt)

  // 4. getTracks — 用 getCards 的第一个结果
  try {
    if (!funcs.getCards) throw new Error('getCards not implemented')
    const cardsData = await runWithTimeout(funcs.getCards, firstTabExt, perInterfaceTimeout)
    const { parsed: cards } = parseInterfaceReturn(cardsData, false)
    if (cards?.list?.[0]) {
      const trackExt = JSON.stringify(cards.list[0].ext || { url: cards.list[0].vod_id, id: cards.list[0].vod_id })
      await run('getTracks', trackExt)

      // 5. getPlayinfo — 用 getTracks 的第一个 track
      try {
        if (!funcs.getTracks) throw new Error('getTracks not implemented')
        const tracksData = await runWithTimeout(funcs.getTracks, trackExt, perInterfaceTimeout)
        const { parsed: tracks } = parseInterfaceReturn(tracksData, false)
        if (tracks?.list?.[0]?.tracks?.[0]) {
          const firstTrack = tracks.list[0].tracks[0]
          const playExt = JSON.stringify(firstTrack.ext || {})
          await run('getPlayinfo', playExt)
        } else {
          results.getPlayinfo = { ok: strict ? false : null, summary: 'no tracks to test with' }
        }
      } catch {
        results.getPlayinfo = { ok: strict ? false : null, summary: 'getTracks failed, skip' }
      }
    } else {
      results.getTracks = { ok: strict ? false : null, summary: 'no cards to test with' }
      results.getPlayinfo = { ok: strict ? false : null, summary: 'no cards to test with' }
    }
  } catch {
    results.getTracks = { ok: strict ? false : null, summary: 'getCards failed, skip' }
    results.getPlayinfo = { ok: strict ? false : null, summary: 'getCards failed, skip' }
  }

  // 6. search
  await run('search', JSON.stringify({ text: keyword, page: 1 }))

  // 打印结果
  const icons = { true: '✅', false: '❌', null: '⏭️', undefined: '❓' }
  const order = INTERFACES
  for (const name of order) {
    const r = results[name] || { ok: undefined, summary: 'missing' }
    const icon = icons[String(r.ok)]
    console.log(`  ${icon} ${name.padEnd(14)} ${r.summary || r.error || ''}`)
    if (r.warnings?.length) {
      for (const warning of r.warnings) console.log(`     ⚠ ${warning}`)
    }
  }

  const passed = Object.values(results).filter(r => r.ok === true).length
  const failed = Object.values(results).filter(r => r.ok === false).length
  const skipped = Object.values(results).filter(r => r.ok === null || r.ok === undefined).length
  const warnings = Object.values(results).reduce((sum, r) => sum + (r.warnings?.length || 0), 0)
  console.log(`\n  Result: ${passed} passed, ${failed} failed, ${skipped} skipped`)
  if (warnings) console.log(`  Warnings: ${warnings}`)
  console.log()

  return { passed, failed, skipped, warnings, results }
}

// ===== 单步执行 =====

async function runSingle(scriptPath, fnName, extStr) {
  const funcs = loadScript(scriptPath)
  const fn = funcs[fnName]
  if (!fn) {
    console.error(`Error: Function '${fnName}' not found in script.`)
    console.error(`Available: ${Object.keys(funcs).join(', ') || 'none'}`)
    process.exit(1)
  }

  console.log(`\n▶ ${fnName}(${extStr || ''})\n`)
  const start = Date.now()
  try {
    const data = extStr ? await fn(extStr) : await fn()
    const ms = Date.now() - start
    const { parsed, warnings } = parseInterfaceReturn(data, false)
    console.log(JSON.stringify(parsed, null, 2))
    if (warnings.length) console.log(`\n⚠ ${warnings.join('; ')}`)
    console.log(`\n⏱ ${ms}ms`)
  } catch (err) {
    console.error(`❌ Error: ${err.message}`)
    console.error(err.stack)
    process.exit(1)
  }
}

// ===== List interfaces =====

function listInterfaces(scriptPath) {
  const funcs = loadScript(scriptPath)
  console.log(`\n📋 Interfaces in ${basename(scriptPath)}:\n`)
  for (const name of INTERFACES) {
    const icon = funcs[name] ? '✅' : '❌'
    console.log(`  ${icon} ${name}`)
  }
  console.log()
}

// ===== Analyze site =====

async function analyzeSite(url) {
  console.log(`\n🔍 Analyzing: ${url}\n`)

  try {
    const { data } = await $fetch.get(url, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
      },
      timeout: 15000,
    })
    const html = typeof data === 'string' ? data : JSON.stringify(data)

    const signals = []

    // MacCMS API
    if (url.includes('/api.php/provide/vod/') || html.includes('api.php/provide/vod')) {
      signals.push('✅ MacCMS API detected (/api.php/provide/vod/)')
    }

    // JSON API
    try {
      const json = typeof data === 'string' ? JSON.parse(data) : data
      if (json.list || json.data || json.results) {
        signals.push('✅ JSON API detected (has list/data/results key)')
      }
    } catch {}

    // HTML 视频列表
    if (html.includes('class="video-item"') || html.includes('class="bs"') || html.includes('class="movie-item"')) {
      signals.push('✅ HTML 视频列表 DOM detected')
    }

    // player_aaaa
    if (html.includes('player_aaaa')) {
      signals.push('✅ player_aaaa found → multi-layer encryption likely')
    }

    // iframe 播放器
    const iframeMatch = html.match(/<iframe[^>]+src=["'][^"']+["']/gi)
    if (iframeMatch && iframeMatch.length > 0) {
      signals.push(`✅ iframe detected (${iframeMatch.length} found) → iframe player pattern`)
    }

    // Smart Play
    if (html.includes('isSmartPlay') || html.includes('secretKeySeed') || html.includes('ticktockwow')) {
      signals.push('✅ Smart Play API detected')
    }

    // Cloudflare
    if (html.includes('challenge-platform') || html.includes('cf-browser-verification') || html.includes('Just a moment')) {
      signals.push('⚠️ Cloudflare protection detected')
    }

    // 验证码
    if (html.includes('安全验证') || html.includes('请输入验证码') || html.includes('verifyBox')) {
      signals.push('⚠️ CAPTCHA/verification page detected')
    }

    // SPA 框架
    if (html.includes('__NUXT__') || html.includes('__NEXT_DATA__') || html.includes('nuxt-link')) {
      signals.push('⚠️ SPA framework detected (Nuxt/Next.js) — cheerio may not see content')
    }

    // jsjiami 混淆
    if (html.includes('jsjiami.com') || html.includes('jsjiami.v')) {
      signals.push('⚠️ jsjiami obfuscation detected — runtime hook needed')
    }

    // 网盘链接
    if (html.includes('pan.quark.cn') || html.includes('alipan.com') || html.includes('115.com') || html.includes('cloud.189.cn')) {
      signals.push('✅ Cloud drive links detected → 网盘源 pattern')
    }

    // 直播流
    if (html.includes('.m3u8') || html.includes('rtmp://') || html.includes('live_url')) {
      signals.push('✅ Live stream URLs detected → 直播源 pattern')
    }

    // WordPress
    if (html.includes('wp-content') || html.includes('wordpress')) {
      signals.push('📝 WordPress site — use data-lazy-src for images')
    }

    if (signals.length === 0) {
      signals.push('❓ No clear signals — may need manual inspection')
    }

    for (const s of signals) {
      console.log(`  ${s}`)
    }

    // 推荐小模板/参考入口
    console.log('\n📋 Recommended starting point:')
    if (signals.some(s => s.includes('MacCMS'))) {
      console.log('  → JSON API small template, or inspect MacCMS XML endpoints manually')
    } else if (signals.some(s => s.includes('Smart Play'))) {
      console.log('  → Play decrypt snippets + site-specific Smart Play analysis')
    } else if (signals.some(s => s.includes('multi-layer'))) {
      console.log('  → Play decrypt snippets')
    } else if (signals.some(s => s.includes('iframe'))) {
      console.log('  → Minimal HTML template + iframe extraction')
    } else if (signals.some(s => s.includes('Cloud drive'))) {
      console.log('  → Pan small template')
    } else if (signals.some(s => s.includes('Live stream'))) {
      console.log('  → Minimal script, return direct live URLs from getPlayinfo()')
    } else if (signals.some(s => s.includes('Cloudflare'))) {
      console.log('  → Minimal HTML template + only necessary anti-bot snippet')
    } else {
      console.log('  → Minimal HTML template')
    }

  } catch (err) {
    console.error(`❌ Failed to fetch ${url}: ${err.message}`)
  }
}

// ===== CLI =====

const args = process.argv.slice(2)
const command = args[0]
const target = args[1]

function usage() {
  console.log(`
XPTV Harness — 本地测试运行器

用法：
  node xptv_harness.js smoke   <script.xptv.js> [--keyword 关键词] [--timeout ms] [--strict]
  node xptv_harness.js run     <script.xptv.js> --fn <接口名> [--ext '{"..."}']
  node xptv_harness.js list    <script.xptv.js>
  node xptv_harness.js analyze <url>

示例：
  node xptv_harness.js smoke ./my_source.xptv.js
  node xptv_harness.js smoke ./my_source.xptv.js --keyword 龙珠
  node xptv_harness.js smoke ./my_source.xptv.js --timeout 30000
  node xptv_harness.js run ./my_source.xptv.js --fn getCards --ext '{"id":"1","page":1}'
  node xptv_harness.js run ./my_source.xptv.js --fn getPlayinfo --ext '{"url":"/play/xxx-1-1.html"}'
  node xptv_harness.js list ./my_source.xptv.js
  node xptv_harness.js analyze https://example.com
`)
}

if (!command || !target) {
  usage()
  process.exit(0)
}

if (command === 'smoke') {
  const kwIdx = args.indexOf('--keyword')
  const keyword = kwIdx !== -1 ? args[kwIdx + 1] : undefined
  const toIdx = args.indexOf('--timeout')
  const timeout = toIdx !== -1 ? parseInt(args[toIdx + 1]) : undefined
  const strict = args.includes('--strict')
  smokeTest(target, { keyword, timeout, strict }).then(r => process.exit(r.failed > 0 ? 1 : 0))
} else if (command === 'run') {
  const fnIdx = args.indexOf('--fn')
  const extIdx = args.indexOf('--ext')
  if (fnIdx === -1) {
    console.error('Error: --fn <接口名> is required for run command')
    process.exit(1)
  }
  const fnName = args[fnIdx + 1]
  const extStr = extIdx !== -1 ? args[extIdx + 1] : undefined
  runSingle(target, fnName, extStr)
} else if (command === 'list') {
  listInterfaces(target)
} else if (command === 'analyze') {
  analyzeSite(target)
} else {
  console.error(`Unknown command: ${command}`)
  usage()
  process.exit(1)
}
