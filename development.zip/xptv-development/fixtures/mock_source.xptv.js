const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36';
const SITE = 'https://example.com';

async function getLocalInfo() {
  return jsonify({ ver: 1, name: 'Mock源', api: 'csp_mock', type: 3 });
}

async function getConfig() {
  return jsonify({
    ver: 1,
    title: 'Mock源',
    site: SITE,
    tabs: [{ name: '全部', ext: { id: 'all' } }]
  });
}

async function getCards(ext) {
  ext = argsify(ext);
  const { page = 1 } = ext;
  return jsonify({
    list: [{
      vod_id: 'mock-1',
      vod_name: 'Mock Movie',
      vod_pic: SITE + '/cover.jpg',
      vod_remarks: '测试',
      ext: { id: 'mock-1', url: SITE + '/detail/mock-1.html' }
    }],
    page
  });
}

async function getTracks(ext) {
  ext = argsify(ext);
  return jsonify({
    list: [{
      title: '默认线路',
      tracks: [{ name: '第1集', ext: { url: SITE + '/video/mock-1.m3u8' } }]
    }],
    info: { vod_desc: 'Harness mock fixture' }
  });
}

async function getPlayinfo(ext) {
  ext = argsify(ext);
  return jsonify({
    urls: [ext.url],
    headers: [{ 'User-Agent': UA, 'Referer': SITE + '/' }]
  });
}

async function search(ext) {
  ext = argsify(ext);
  const { text, wd, page = 1 } = ext;
  const keyword = text || wd || '';
  return jsonify({
    list: [{
      vod_id: 'mock-search-1',
      vod_name: keyword ? `搜索结果: ${keyword}` : 'Mock Search Result',
      vod_pic: SITE + '/search-cover.jpg',
      vod_remarks: '搜索测试',
      ext: { id: 'mock-search-1', url: SITE + '/detail/mock-search-1.html' }
    }],
    page
  });
}
