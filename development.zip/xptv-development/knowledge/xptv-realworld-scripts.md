# XPTV 实战脚本样本分析

本文档是辅助材料，用于分析公开脚本包、记录案例和解释常见历史写法。
统计结论只代表样本中的实战现象，不替代开发者文档或 `xptv-official-doc.md`
原文。开发者文档与实战样本冲突时，正式 `.xptv.js` 按开发者文档处理。

使用顺序：先读 `xptv-official-doc.md`、`xptv-api-reference.md`、`xptv-toolbox.md`，
再按需要读取本文档。

## 样本来源

2026-06-24 对用户提供的两个公开脚本包做静态扫描：

- `xptv-extensions-main.zip`
- `xptv-main (1).zip`

样本合计 93 个 `.js` 脚本：

| 目录 | 数量 |
|------|------|
| `xptv-extensions-main/js` | 68 |
| `xptv-main/vod` | 24 |
| `xptv-main/av` | 1 |

## 文件级统计

| 写法/接口 | 命中 |
|----------|------|
| `getConfig()` | 93 / 93 |
| `getCards(ext)` | 93 / 93 |
| `getTracks(ext)` | 93 / 93 |
| `getPlayinfo(ext)` | 93 / 93 |
| `search(ext)` | 91 / 93 |
| `getLocalInfo()` | 3 / 93 |
| `argsify(...)` | 93 / 93 |
| `jsonify(...)` | 87 / 93 |
| `Buffer.*` | 3 / 93 |
| `$html.*` / `openSafari` | 12 / 93 |
| `openSafari` | 7 / 93 |
| `Just a moment...` | 3 / 93 |
| `SafeLine` | 1 / 93 |
| `安全验证` | 2 / 93 |
| `smart_verify` | 1 / 93 |
| `$fetch.download()` | 1 / 93 |
| jsjiami v7 混淆 | 13 / 93 |

## 校准结论

### 1. 远程订阅脚本不等于本地 `.xptv.js`

样本中大多数脚本由订阅 JSON 加载，通常没有 `getLocalInfo()`。这不代表本地
`.xptv.js` 可以省略入口。

- 分析远程脚本：不要因缺少 `getLocalInfo()` 判定错误。
- 交付本地 `.xptv.js`：必须补 `getLocalInfo()`，并保证 `api` 全局唯一。
- 从远程脚本改成本地脚本：按开发者文档本地 `.xptv.js` 口径补入口和调用链，不继承历史兼容写法。

### 2. `argsify()` / `jsonify()` 常见用法

93 个样本全部直接使用 `argsify(...)`。常见写法：

```js
const $config = argsify($config_str)

async function getCards(ext) {
  ext = argsify(ext)
  return jsonify({ list: [] })
}
```

### 3. `search(ext)` 可缺省，但本地成品建议给兜底

样本中 2 个脚本没有 `search()`，对应订阅配置里也可能标明无搜索。交付本地
完整脚本时，若源站不支持搜索，建议显式返回空列表：

```js
async function search(ext) {
  return jsonify({ list: [] })
}
```

搜索入参以开发者文档 `ext.text` 为准：

```js
ext = argsify(ext)
const keyword = ext.text || ''
```

### 4. 历史/环境写法不要进入默认模板

样本中少量脚本包含以下历史或环境相关写法：

- `$html.*`
- `$utils.openSafari()`（只在实际过盾命中点按需使用）
- `{ urls: [], headers: [...] }`
- `console.log(...)`

处理原则：

- 分析公开样本时允许识别这些写法，但不要作为默认模板铺开。
- `getPlayinfo()` 失败或网盘源返回 `{ urls: [] }` 即可。

### 5. 混淆脚本先走反混淆路径

样本中约 13 个脚本包含 `jsjiami.com.v7` 特征。遇到这类脚本时：

- 不要先人工改业务逻辑。
- 先使用 `decode-js` 技能或运行时调试流程还原可读结构。
- 反混淆前只做文件级判断，例如接口是否存在、是否直接返回 JSON 字符串。

### 6. 过盾写法只作命中点参考

实战脚本不会统一提取 `isVerifyPage()`。常见做法是在 `$fetch.get()` 后马上判断实际命中的
标题、标记或错误码：

```js
if (String(data || "").includes("Just a moment...")) {
  $utils.openSafari(url, UA)
}
```

当前响应还能被原选择器安全解析时继续原流程；纯验证页才返回空列表或空播放地址。
`smart_verify`、PoW / Cookie、OCR 验证码属于站点专用逻辑，只在目标站实际需要时实现。

## 案例索引

这些案例只用于校准规则，不代表通用模板。

| 案例 | 用途 |
|------|------|
| hanime1 | `Just a moment...` 只触发 `openSafari()`，验证后继续原解析流程 |
| jable / novipnoad / wogg | Cloudflare 默认页按命中请求点打开浏览器，能解析时继续流程 |
| 厂长资源 | SafeLine / Access Forbidden 是纯验证页，只在 `getCards()`、`getTracks()` 必要点返回空结果 |
| czzy | SafeLine 解密 / challenge 是站点专用重逻辑，不作为新源默认模板 |
| lmm85 | 搜索 `smart_verify`：PHPSESSID + MD5 token + Cookie 重试 |
| gying | PoW + Cookie / `$cache`：需要用户配置或站点算法，不默认添加 |
| saohuo | `$fetch.download()` 下载验证码图片并 OCR，只用于二进制验证码场景 |
| PanSou | API 网盘源，结果用真实 `pan` 链接；不自定义 `argsify/jsonify` |

案例使用原则：

- 先按开发者文档确认接口和返回结构。
- 从案例借鉴“站点实际命中点”，不要把案例里的防御逻辑扩散成默认模板。
- 公开脚本中的远程订阅差异、历史 helper、兼容写法只用于问题定位。

## 导入实战脚本检查清单

从公开脚本包移植或精简脚本时按此顺序检查：

- 先按开发者文档确认目标接口和返回格式；本文档只辅助判断旧脚本差异。
- 明确目标：远程订阅脚本还是本地 `.xptv.js`。
- 若目标为本地 `.xptv.js`，补 `getLocalInfo()`；若仍是远程脚本，不强行补。
- XPTV 传入的 `ext`、`$config_str` 先 `argsify()` 再取字段。
- 所有返回统一 `jsonify(...)`；历史脚本使用其他返回方式时按目标环境判断。
- 在线播放 track 用 `ext.url`；只有真实网盘链接才用 `pan`。
- `$fetch.post()` 使用三参数格式：`url, body, { headers }`。
- 搜索读取开发者文档约定的 `ext.text`。
- 失败兜底返回有效结构，不抛出未捕获异常。
