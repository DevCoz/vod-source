# XPTV API Reference

> 本文档以开发者文档为准。标注 `[开发者]` 的内容来自开发者文档或开发者示例；
> 标注 `[实战补充]` 的内容只用于说明常见场景和排障，不覆盖开发者文档口径。
> 开发者文档与实战样本冲突时，正式 `.xptv.js` 按开发者文档处理。

## 工具库

```js
// 常用运行时工具 [开发者]
const $config = argsify($config_str)

// 需要解析 HTML 时再初始化
const cheerio = createCheerio()

// 需要加解密、Base64、MD5 等能力时再初始化
const CryptoJS = createCryptoJS()

// 配置参数 — 导入源时在 XPTV 设置中填写的 ext 字符串 [开发者]
$config_str

// 日志打印 [开发者]
$print("xxx") // 输出到 http://ip:8110/log

// 网络请求 [开发者]
const { data } = await $fetch.get('http://xx.com', { headers: {} })
const { data } = await $fetch.post('http://xx.com', { name: 'xx' }, { headers: {} })
const json = argsify(data)

// 缓存 [开发者]
const v = $cache.get('key')
$cache.set('key', 'value')
$cache.del('key')

// 提示 [开发者]
$utils.toastInfo('xxx')
$utils.toastError('xxx')

// 系统信息 [开发者]
$utils.os()   // e.g. "tvOS/18.1"
$utils.app()  // e.g. "2.0"
```

### $fetch 补充说明

> 开发者 tldr 示例中 `$fetch.get` 有一处未写 `await`；实际接口函数是 `async`，
> 网络请求应 `await` 后再读取 `data`，避免对 Promise 解构。

```js
// [实战补充] respHeaders — 获取响应头（如 Set-Cookie）
const resp = await $fetch.get(url, { headers })
const setCookie = resp.respHeaders?.['set-cookie'] || resp.headers?.['set-cookie'] || ''

// [实战补充] timeout — 请求超时（毫秒）
const { data } = await $fetch.get(url, { headers, timeout: 20000 })

// [实战补充] download — 下载二进制资源（验证码图片、字体、图片等）
const { data: bin } = await $fetch.download(url, { headers, timeout: 20000 })
// bin 是二进制字符串，不是 UTF-8 HTML/JSON；不要 argsify(bin) 或 cheerio.load(bin)
const firstByte = bin.charCodeAt(0) & 0xff

// [实战补充] POST body 必须作为第二参数（三参数格式），不是 axios 风格
// ✅ 正确
await $fetch.post(url, 'key=value', { headers: { 'Content-Type': 'application/x-www-form-urlencoded' } })
await $fetch.post(url, jsonify({ key: 'value' }), { headers: { 'Content-Type': 'application/json' } })

// ❌ 错误 — 会发送 JSON 而非 form-urlencoded
await $fetch.post(url, { data: { key: 'value' }, headers: {} })
```

### $utils 过盾补充 `[实战补充]`

`$utils.openSafari(url, UA)`、`$fetch.download(url, options)` 等过盾能力以
`xptv-anti-bot.md` 为唯一详细口径。API 参考只确认这些能力可在实战排障中按需使用；
正式脚本不要默认加过盾、不要默认提取 `isVerifyPage()` helper。
### $cache 补充说明

```js
// [实战补充] 支持 TTL（秒）
$cache.set('key', 'value', 300)  // 5 分钟后过期
```

---

## 1. getLocalInfo() — 本地源信息

**用途**: XPTV 识别和管理该源。本地 `.xptv.js` 文件需要此方法。 `[开发者]`

**返回**:
```js
{
  ver: 1,                    // 固定为 1 [开发者]
  name: "源名称",            // [开发者]
  api: "csp_唯一标识符",     // 唯一，不可重复 [开发者]
  type: 3,                   // [实战补充] 可选，VOD=3, 直播=4
}
```

**示例**:
```js
async function getLocalInfo() {
  return jsonify({
    ver: 1,
    name: "播剧网",
    api: "csp_ysxq",
    type: 3,
  });
}
```

> **注意**: 开发者文档示例中变量名 `appConfig`（大写）和 `return jsonify(appconfig)`（小写）不一致，实际使用时请统一。

---

## 2. getConfig() — 源配置

**用途**: 返回导航标签页配置 `[开发者]`

**返回**:
```js
{
  ver: 1,                    // [开发者]
  title: "源标题",           // [开发者]
  site: "https://example.com", // [开发者]
  tabs: [                    // [开发者]
    {
      name: "标签名称",      // [开发者]
      ext: { id: "分类ID" }  // [开发者] 传给 getCards
    }
  ]
}
```

**横式图片**: 横式图片加 `ui: 1` `[实战补充]`。

## 3. getCards(ext) — 视频列表

**入参 ext** `[开发者]`:
```js
{
  id: "分类ID",       // 来自 tabs[].ext.id
  page: 1,            // 分页，默认 1
  filters: {}         // 可选，筛选参数字典 [String: String]
}
```

使用时通常先执行 `ext = argsify(ext)`，再解构字段。

**解构写法**:
```js
const { page = 1, id, filters = {} } = ext;
```

**返回**:
```js
{
  list: [                    // [开发者]
    {
      vod_id: "唯一ID",      // [开发者]
      vod_name: "视频名",    // [开发者]
      vod_pic: "封面URL",    // [开发者]
      vod_remarks: "更新至12集", // [开发者]
      vod_duration: "片长",  // [实战补充] 可选（直播源可显示在线人数）
      vod_time: "更新时间",  // [实战补充] 可选
      vod_pubdate: "上映日期", // [实战补充] 可选
      ext: { url: "详情页URL" } // [开发者] 传给 getTracks
    }
  ],
  filter: [                  // [开发者] 可选，筛选定义
    {
      key: "type",           // [开发者] → ext.filters.type
      name: "类型",          // [开发者]
      init: "all",           // [开发者] 默认值
      value: [               // [开发者]
        { n: "全部", v: "all" },
        { n: "喜剧", v: "喜剧" }
      ]
    }
  ]
}
```

### Filter 协议 `[开发者]`

- `filter[].key` → 下次请求的 `ext.filters[key]`
- 请求缺少某个筛选键时，按该项 `init` 处理
- 非法值回退到 `init`
- 响应无 `filter` 字段（或为空）→ 视为无筛选页面

### `filterList` 写法 `[实战补充]`

`filterList` 不是 XPTV 返回字段，而是脚本内部可选的筛选常量表。正式返回仍使用
开发者协议中的 `filter` 字段。

适合使用 `filterList` 的情况：
- 站点分类筛选项固定，且多个分类需要各自维护筛选。
- 用户明确要求增加筛选列表。
- 不会明显拉长脚本或增加维护成本。

不建议默认添加的情况：
- 目标源只需要简单分类浏览。
- 筛选项容易变化或页面解析成本较高。
- 精简源已经能稳定搜索、分类、播放。

```js
const filterList = {
  "1": [
    {
      key: "cateId",
      name: "类型",
      init: "",
      value: [
        { n: "全部", v: "" },
        { n: "喜剧", v: "喜剧" }
      ]
    }
  ]
}

async function getCards(ext) {
  ext = argsify(ext)
  const filters = ext.filters || {}
  const cateId = filters.cateId || ""
  // 用 cateId 构造分类 URL
  return jsonify({ list: list, filter: filterList[ext.id] || [] })
}
```

> 注意：不要返回 `{ filterList: ... }`；客户端识别的是 `filter`。

---

## 4. getTracks(ext) — 播放线路

**入参 ext**:
```js
{
  id: "视频ID",     // [开发者]
  url: "详情URL"    // [开发者] 来自 getCards 的 ext
}
```

**返回（在线播放源）**:
```js
{
  list: [                    // [开发者]
    {
      title: "线路名称",     // [开发者]
      tracks: [              // [开发者]
        {
          name: "第1集",     // [开发者]
          ext: { url: "播放链接" } // [开发者] 传给 getPlayinfo
        }
      ]
    }
  ],
  info: {                    // [实战补充] 可选
    vod_pic: "真实封面URL",
    vod_desc: "剧情简介"
  }
}
```

**返回（网盘源）** `[实战补充]`:
```js
{
  list: [
    {
      title: "夸克网盘",
      tracks: [
        {
          name: "S01E01.1080P",
          pan: "https://pan.quark.cn/s/xxx",  // 用 pan 字段
          ext: {}                               // 网盘不需要 ext.url
        }
      ]
    }
  ]
}
```

**网盘模式**: tracks 中用 `pan` 字段代替 `ext.url`，`getPlayinfo()` 返回 `{ urls: [] }` `[实战补充]`

> 在线播放 track 使用 `ext.url`；网盘 track 使用真实 `pan` 链接。不要把空
> `pan` 当成可用网盘线路。

---

## 5. getPlayinfo(ext) — 播放地址

**入参 ext** `[开发者]`:
```js
{
  url: "播放链接"   // 来自 getTracks 的 ext.url
}
```

**返回（在线播放源）** `[开发者]`:
```js
{
  urls: ["https://example.com/video.m3u8"],
  headers: [{ "User-Agent": "...", "Referer": "..." }]  // 可选
}
```

**带外挂字幕** `[实战补充]`:
```js
{
  urls: ["https://example.com/video.m3u8"],
  headers: [{ "User-Agent": "...", "Referer": "..." }],
  subtitles: [
    { name: "中文字幕", url: "https://xx.com/1.srt" },
    { name: "English", url: "https://xx.com/1.en.srt" }
  ]
}
```

**网盘源**: 返回 `{ urls: [] }` `[实战补充]`

> **注意**: 失败时只返回 `{ urls: [] }`，不要加多余的 `headers: []`。

---

## 6. search(ext) — 搜索

**入参 ext**:
```js
{
  text: "搜索关键词",   // [开发者]
  page: 1              // [实战补充]
}
```

**返回**: 与 getCards 相同 `[开发者]`
```js
{
  list: [{ vod_id, vod_name, vod_pic, vod_remarks, ext }],
  page: 1
}
```

---

## 数据序列化

- **返回 `[开发者]`**: 开发者示例使用 `jsonify(obj)` → JSON string
- **入参 `[开发者]`**: XPTV 传入的 `ext`、`$config_str` 等 JSON 字符串使用运行时 `argsify(...)` → JS object

---

## 数据流

```
getLocalInfo()                              ← 独立调用，XPTV 用此识别和管理源
getConfig.tabs[].ext  → getCards(ext)
getCards.list[].ext   → getTracks(ext)
getTracks.list[].tracks[].ext → getPlayinfo(ext)
```

---

## 网盘类型支持 `[实战补充]`

以下为历史实测/经验整理。正式脚本默认保留百度、夸克、阿里、115、天翼等已确认可用网盘。

| 网盘 | 支持 | URL 格式 |
|------|------|----------|
| 夸克 | ✅ | `https://pan.quark.cn/s/xxx` |
| 阿里 | ✅ | `https://www.alipan.com/s/xxx` |
| 115 | ✅ | `https://115.com/s/xxx` |
| 天翼 | ✅ | `https://cloud.189.cn/t/xxx` |
| 百度 | ✅ | `https://pan.baidu.com/s/xxx` |

---

## XPTV JSC 环境约束 `[实战补充]`

XPTV 运行在 JavaScriptCore (JSC)，不是 Node.js。

**可用全局函数**：
- `createCryptoJS()` — 返回 CryptoJS 实例
- `createCheerio()` — 返回 cheerio 实例
- `loadJSEncrypt()` — 返回 JSEncrypt 实例（RSA）

**不可用**：
- ❌ `Buffer` — 用 `CryptoJS.enc.Base64.parse()`
- ❌ `atob`/`btoa` — 用 CryptoJS
- ❌ `require()` — 用全局函数

**URL 参数提取辅助**：
```js
function extractParam(urlStr, param) {
  const match = urlStr.match(new RegExp('[?&]' + param + '=([^&]+)'));
  if (match && match[1]) {
    try { return decodeURIComponent(match[1]); } catch (e) { return match[1]; }
  }
  return null;
}
```

---

## 实战补充索引（不覆盖开发者文档）

以下内容来自实战观察或客户端行为总结，用于排障。生成正式脚本时，
如果与开发者文档冲突，以开发者文档为准：

| 内容 | 说明 |
|------|------|
| `getLocalInfo` 的 `type` 字段 | VOD=3, 直播=4 |
| `getTracks` 的 `info` 字段 | 返回 `vod_pic`, `vod_desc` |
| `getPlayinfo` 的 `subtitles` 字段 | 外挂字幕支持 |
| 网盘模式 `pan` 字段 | tracks 中用 `pan` 代替 `ext.url` |
| `$fetch.respHeaders` | 获取 Set-Cookie 等响应头 |
| `$fetch.timeout` | 请求超时控制 |
| `$cache` TTL | 第三参数为过期秒数 |
| `$fetch.post` 三参数格式 | 最常见的错误点 |
| JSC 环境约束 | 运行在 JavaScriptCore，不是 Node.js |
