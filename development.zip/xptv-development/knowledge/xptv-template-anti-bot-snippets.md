# 过盾片段模板

完整规则见 `xptv-anti-bot.md`。不要默认铺到所有接口；只在实际命中验证页的请求点内联。
默认片段只覆盖“打开浏览器后继续解析”和“纯验证页返回空结果”。`smart_verify`、PoW、
OCR 验证码按站点专用逻辑处理，不放入通用片段。

## 只触发 Safari，继续解析

```js
const html = String(resp.data || "")
if (html.includes("Just a moment...")) {
  $utils.openSafari(url, UA)
}
const list = parseCards(html)
```

## 纯验证页，返回空结果

```js
const html = String(resp.data || "")
if (html.indexOf("SafeLine") >= 0 || html.indexOf("Access Forbidden") >= 0) {
  $utils.openSafari(url, UA)
  return jsonify({ list: [], page: page, pagecount: 1 })
}
```

`$fetch.download()` 只在验证码图片、滑块背景、字体等二进制资源确实需要分析时使用。

`openSafari()` 传当前请求地址，例如分类页用 `classurl`；不要为了单次判断提取
`isVerifyPage()` helper，也不要默认加入未命中的额外关键词。
