# XPTV 实战案例集

本文档是实战辅助材料，用于理解特定站点逆向、反爬和排障过程。正式脚本的
接口和返回格式仍以开发者文档、API 参考和模板库为准。

---

## 案例 1: kisskh.do Angular SPA 逆向（Archive.org + API 发现）

**站点**: https://kisskh.do（韩剧/动漫流媒体）

**挑战**: Cloudflare 保护，所有 API 返回 403。SSL 证书错误。多个域名变体都解析到同一代理集群 (198.18.4.x)。

**发现过程**:
1. DNS 调查：所有 kisskh 域名解析到 198.18.4.56-59（同一代理集群）
2. Archive.org 回退：用 `https://web.archive.org/web/2025/https://kisskh.do/` 访问缓存
3. 框架检测：Angular SPA（main.js, runtime, polyfills）
4. 从 archive.org 下载 main.js（~1.2MB）分析

**关键技术**：从 Angular bundle 中用正则提取 API 端点
```python
method_pattern = re.compile(
    r'\{key:"(\w+)",value:function[^{]*\{[^}]*this\.httpClient\.\w+\(g\.N\.baseUrl\+"([^"]+)"'
)
methods = method_pattern.findall(js)
```

**发现的 API 端点**（均在 `/api/DramaList/` 下）：
| 方法 | 端点 | 用途 |
|------|------|------|
| GetDramaShow | DramaList/Show | 浏览 |
| GetSearch | DramaList/Search?q={keyword} | 搜索 |
| GetDramaDetail | DramaList/Drama/{id} | 详情+剧集 |
| GetEpisode | DramaList/Episode/{id}.png?kkey= | 播放URL（混淆）|
| GetSub | Sub/{id} | 字幕 |

**坑点**：
- Archive.org 可能返回 HTML 包装而非原始 JS → 用 `js_` 时间戳前缀
- 代码变量被 mangled → 搜索字符串字面量而非变量名
- Cloudflare 站点即使有正确 API 结构也可能无法从 XPTV 访问

**可复用模式**：Archive.org + Angular Bundle 分析（见 xptv-patterns.md）

---

## 案例 2: kisskh.ws AES Token 加密

**站点**: https://kisskh.ws（韩剧/动漫）

**挑战**: 播放 API 需要 AES-128-CBC 加密的 token。

**发现过程**：
1. 用户提供 Python 解密脚本作为参考
2. 需要精确移植 hash 函数（匹配 Python 32 位有符号整数行为）
3. 确认 AES-128-CBC + PKCS7 加密，hex 大写输出

**Token 生成算法**：
```js
// 1. 构造 payload 数组，用 | 连接
const payloadArr = ['', episodeId, '', APP_ID, APP_VERSION, VID_TOKEN, ...];
const joined = payloadArr.join('|');

// 2. hash 函数（匹配 Python 32 位有符号整数）
const hashValue = hashFunc(joined);

// 3. 在位置 1 插入 hash，再次 join
payloadArr.splice(1, 0, String(hashValue));
const finalPayload = payloadArr.join('|');

// 4. AES-128-CBC 加密
const encrypted = CryptoJS.AES.encrypt(finalPayload, key, { iv, mode: CBC, padding: Pkcs7 });
return encrypted.ciphertext.toString(CryptoJS.enc.Hex).toUpperCase();
```

**字幕支持**：字幕 API 用同一 token：`/api/Sub/{episodeId}?kkey={token}`

**坑点**：
- hash 函数必须完全匹配 Python 行为（初版实现结果错误）
- `ts` 和 `time` 参数用 `null` 而非时间戳
- VID_TOKEN 常量必须完整
- AES 解密后 URL 必须 `.trim()` 去除尾部 CR/LF

---

## 案例 3: radio.cn（云听）API 发现

**站点**: https://www.radio.cn（中央广播电视总台）

**挑战**: 页面用 JS 动态加载。源码中可见的 `tacc.radio.cn` API 不可达（连接关闭）。

**发现过程**：
1. 在浏览器中导航到频道页面
2. 用 `performance.getEntriesByType('resource')` 捕获实际网络请求
3. 发现实际工作的 API：`ytmsout.radio.cn`

**实际 API**：
```
GET https://ytmsout.radio.cn/web/appProgram/pageByColumn?pageNo={page}&columnId={id}&pageSize={size}
```

- `columnId` = URL 中的 `name` 参数（非 `channelname`）
- `pageNo` = 从 0 开始

**关键字段**：`playUrlHigh`（m4a 音频 URL，直接播放）

**已知频道**：
| 频道 | columnId | 节目名 |
|------|----------|--------|
| 648 | 1453129 | 笑声编辑部 |
| 649 | 1396377 | 笑口常开 |

**坑点**：`tacc.radio.cn` 不可达，只有 `ytmsout.radio.cn` 和 `ytrecordbroadcast.radio.cn`（CDN）可用。

---

## 案例 4: lmm85.com MacCMS CAPTCHA 绕过

**站点**: https://www.lmm85.com（路漫漫在线动漫）

**挑战**: 搜索页需要 MacCMS PHP session 验证码。分类浏览正常，搜索返回验证页。

### 验证码机制
1. GET `/index.php/verify/index.html?r={random}` → 返回 CAPTCHA 图片 + 设置 PHPSESSID
2. POST `/index.php/ajax/verify_check?type=search&verify={code}` → 验证
3. 成功后同一 PHPSESSID 跳过验证

### 尝试的方案
| 方案 | 结果 | 原因 |
|------|------|------|
| Vision AI | ✅ 可行（~80-90%准确）| 但 JSC 中不可用 |
| 像素分析 | ⚠️ 部分 | 手写风格+抗锯齿 |
| MacCMS API | ❌ 失败 | 站点关闭了所有 API |
| 浏览器自动化 | ✅ 可行 | 但 XPTV 脚本无法控制浏览器 |

**结论**：纯算法绕过在 XPTV JSC 中不可行（无 OCR、无图像处理）。脚本应检测验证码页并优雅返回空。

**脚本实现**：
```js
if (data.includes('安全验证') || data.includes('请输入验证码')) {
  return jsonify({ list: [], page });
}
```

---

## 案例 5: yun.92cj.com 多类型播放器

**站点**: https://www.lmm85.com | **播放器**: yun.92cj.com

**挑战**: 同一播放器域名支持多种播放类型，iframe URL 和 POST 端点各异。

### 播放器类型架构

`var player_aaaa` 的 `from` 字段决定播放类型：

| from 值 | iframe URL 模式 | POST 端点 | 视频 CDN |
|---------|----------------|-----------|----------|
| ykbox | `404.php?host=4khls&vid=...` | `yunbox/ecvod.php` | oceanengine.com |
| vxdev | `yunbox/?type=vxdev&vid=...` | `yunbox/vxdev.php` | groupvideo.photo.qq.com |
| xgvxcd | `yunbox/?type=xgvxcd&vid=...` | `yunbox/xgvxcd.php` | (varies) |
| tudou | vid 即直接 m3u8 URL | N/A | yun.92cj.com |

### 关键发现
1. **iframe URL 构造因类型而异**：ykbox 用 `404.php`，其他用 `yunbox/?type=xxx`
2. **POST 端点必须从 iframe HTML 动态提取**（`$.post("xxx.php")`），不要硬编码
3. **ykbox vid 必须去除 `&t=ecvod` 后缀**
4. **`from=tudou`：vid 就是直接 URL**

### AES Token 解密 (getc)
iframe 页面用 `getc(token)` 解密 base64 token：
```js
const _AES_KEY = 'ejjooopppqqqrwww';  // 从 XOR + base64 + sort 派生
const _AES_IV = '1348987635684651';
```

---

## 案例 6: lmm85.com smart_verify 绕过

**站点**: https://www.lmm85.com

**挑战**: 搜索需要 smart_verify，混淆代码中隐藏加密逻辑。

**发现过程**：
1. 用 decode-js `sojsonv7` 反混淆 `_0x_lmm_crypto.gen(ts)`
2. 揭示：`md5(ts + "MySecretlmm2026")`

**绕过流程**：
1. GET 搜索页 → 服务器设置 `PHPSESSID` cookie
2. POST `/index.php/ajax/smart_verify` 带 `smart_token=md5(ts+"MySecretlmm2026")&ts={timestamp}`（同一 PHPSESSID）
3. 再次 GET 搜索页（同一 PHPSESSID）→ 无验证码，显示结果

**关键**：`$fetch` 必须返回 `respHeaders`（非 `headers`）才能获取 `set-cookie` 用于 session 共享。

---

## 案例 7: CDN domain ≠ main domain

**站点**: heiliao.com → CloudFront CDN

**问题**：
- 主域 `https://heiliao.com` → Nuxt.js SPA shell，无文章数据
- CDN 域 `https://d1bkj2yip30514.cloudfront.net` → SSR 内容，有文章链接

**发现方法**：检查 `link[rel="canonical"]`，或在 HTML 中搜索 CDN URL。

**解决方案**：用 CDN 域名作为 `SITE` 替代主域名。

**图片问题**：图片在 `pic.cshsst.cn` CDN，XPTV 无法加载（平台级限制）。

**通用模式**：如果主域名返回空内容，查找实际提供内容的 CDN 域名。在浏览器中检查 network 请求找到真正的内容域。

---

## 案例: 斗鱼直播 (douyu.com)

**类型**: 直播源 + 多 CDN × 多画质 + 加密签名

**难点**:
1. **多步 MD5 鉴权**: 不是简单 MD5，需要从 `/wgapi/livenc/liveweb/websec/getEncryption` 获取加密参数，然后循环 N 次 MD5 哈希
2. **CDN × 画质矩阵**: 先请求一次获取 `cdnsWithName`（CDN 列表）和 `multirates`（画质列表），双重循环逐个请求流地址
3. **动态 DID**: 32 位随机 hex 作为设备 ID，用于 API 鉴权和搜索 Cookie
4. **form-urlencoded POST**: 流地址 API 需要 form-urlencoded 格式，非 JSON
5. **未开播处理**: `isLive` 为 false 时返回占位 track 而非空列表

**解决要点**:
- 鉴权: `rand_str → N次MD5循环 → 最终MD5(roomId + timestamp)`
- 流地址: `rtmp_url + '/' + rtmp_live` 或 `url` / `live_url`
- getPlayinfo 直接返回 URL + Referer，无需二次解密
- 搜索需要 Cookie: `dy_did=xxx;acf_did=xxx`

**参考**: `douyu.js` 完整实现

---

## 案例: LIBVIO (libvio.lat)

**类型**: HTML 爬取 + Smart Play API + execB 解密

**难点**:
1. **execB 解密密钥派生**: MD5(timestamp + secret) 的 hex 字符串再做 hex-ASCII 编码，取前 16 字符做 IV、后 16 做 Key
2. **artplayer iframe 二级请求**: timestamp 和 secretKeySeed 不在主页面，需额外请求 `/static/player/artplayer/?url=xxx`
3. **多播放线路**: DOM 中 h3 标签存线路名，`.stui-content__playlist` 容器存剧集，顺序需对应
4. **降级链**: Smart Play API 失败 → player_aaaa.url 直接解密 → 全部失败返回空

**解决要点**:
- `extractScriptJSON()` 从 `<script>` 标签中用正则提取 JSON（处理 `var player_aaaa = {...};<\/script>`）
- OG 标签提取 `og:image` 和 `meta[name=description]` 做详情信息补充
- `.clone().children().remove().end().text()` 提取纯文本排除子标签
- hex-to-raw 转换后才能做 AES 解密（输入可能是纯 hex 字符串）

**参考**: `libvio.xptv.js` 完整实现
