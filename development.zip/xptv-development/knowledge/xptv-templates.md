# XPTV Script Templates

> 本模板库默认面向正式本地 `.xptv.js` 成品，写法以开发者文档为准，因此模板包含
> `getLocalInfo()`。模板只保留最小可用骨架；请求头、辅助函数、筛选、过盾和解密都按需增强。

## 选择顺序

1. 能用最小 HTML 模板完成，就不要复制复杂通用 helper。
2. 站点有稳定 JSON API 时，用 JSON API 模板。
3. 真实网盘分享链接用网盘模板，`getTracks().tracks[].pan` 放真实链接。
4. 过盾只复制对应片段，不把过盾模板铺到所有接口。
5. `smart_verify`、PoW、OCR 验证码属于站点专用逻辑，先看 `xptv-anti-bot.md` / 排障文档，不进默认模板。
6. 播放页加密只复制实际用到的解密片段。

## 小模板入口

| 场景 | 文件 |
|------|------|
| 最小 HTML 爬取 | `xptv-template-html-minimal.md` |
| JSON API | `xptv-template-api-json.md` |
| 网盘 pan | `xptv-template-pan.md` |
| 过盾片段 | `xptv-template-anti-bot-snippets.md` |
| 播放页解密 | `xptv-template-play-decrypt.md` |

## 不再默认加载的大模板

旧版 `xptv-templates.md` 曾收录大量通用模板和高级片段，容易让新源过度复杂。现在把默认入口
收敛到上面的五类小模板；更复杂的历史写法请到 `xptv-patterns.md`、`xptv-case-studies.md`
或 `xptv-debugging-case-studies.md` 按场景查阅。
