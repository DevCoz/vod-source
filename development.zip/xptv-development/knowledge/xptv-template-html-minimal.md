# 最小 HTML 爬取模板

适用于无 API、需要解析列表页和详情页的站点。默认不写统一 headers；遇到 403、空列表、
防盗链或播放失败时再补。

```js
const cheerio = createCheerio()
const SITE = "https://example.com"

async function getLocalInfo() {
  return jsonify({ ver: 1, name: "源名", api: "csp_example", type: 3 })
}

async function getConfig() {
  return jsonify({ ver: 1, title: "源名", site: SITE, tabs: [{ name: "首页", ext: { url: "/" }, ui: 1 }] })
}

async function getCards(ext) {
  ext = argsify(ext)
  const page = parseInt(ext.page, 10) || 1
  const url = SITE + (ext.url || "/")
  const { data } = await $fetch.get(url, { timeout: 20000 })
  const $ = cheerio.load(String(data || ""))
  const list = []

  $(".item").each(function (_, el) {
    const a = $(el).find("a").first()
    const name = a.text().trim()
    const href = a.attr("href") || ""
    if (!name || !href) return
    list.push({ vod_id: href, vod_name: name, vod_pic: "", ext: { url: href } })
  })

  return jsonify({ list: list, page: page, pagecount: list.length ? page + 1 : page })
}

async function getTracks(ext) {
  ext = argsify(ext)
  const { data } = await $fetch.get(ext.url, { timeout: 20000 })
  const $ = cheerio.load(String(data || ""))
  const tracks = []

  $("a[href*='play']").each(function (_, el) {
    const a = $(el)
    tracks.push({ name: a.text().trim() || "播放", ext: { url: a.attr("href") || "" } })
  })

  return jsonify({ list: tracks.length ? [{ title: "在线播放", tracks: tracks }] : [] })
}

async function getPlayinfo(ext) {
  ext = argsify(ext)
  return jsonify({ urls: ext.url ? [ext.url] : [] })
}

async function search(ext) {
  return jsonify({ list: [] })
}
```