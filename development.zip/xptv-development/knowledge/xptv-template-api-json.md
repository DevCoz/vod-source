# JSON API 模板

适用于站点直接返回 JSON 列表、详情或播放地址的情况。`$fetch.post()` 必须使用三参数格式：
`$fetch.post(url, body, { headers })`。

```js
const SITE = "https://example.com"
const API = SITE + "/api/list"

async function getLocalInfo() {
  return jsonify({ ver: 1, name: "源名", api: "csp_example_api", type: 3 })
}

async function getConfig() {
  return jsonify({ ver: 1, title: "源名", site: SITE, tabs: [{ name: "全部", ext: { type: "" } }] })
}

async function getCards(ext) {
  ext = argsify(ext)
  const page = parseInt(ext.page, 10) || 1
  const { data } = await $fetch.get(API + "?page=" + page, { timeout: 20000 })
  const rows = (typeof data === "string" ? argsify(data) : data).list || []
  const list = rows.map(function (item) {
    return { vod_id: item.id, vod_name: item.name, vod_pic: item.pic || "", ext: { id: item.id } }
  })
  return jsonify({ list: list, page: page })
}

async function getTracks(ext) {
  ext = argsify(ext)
  const { data } = await $fetch.get(SITE + "/api/detail?id=" + encodeURIComponent(ext.id), { timeout: 20000 })
  const detail = typeof data === "string" ? argsify(data) : data
  return jsonify({ list: [{ title: "默认", tracks: [{ name: "播放", ext: { url: detail.url || "" } }] }] })
}

async function getPlayinfo(ext) {
  ext = argsify(ext)
  return jsonify({ urls: ext.url ? [ext.url] : [] })
}

async function search(ext) {
  return jsonify({ list: [] })
}
```