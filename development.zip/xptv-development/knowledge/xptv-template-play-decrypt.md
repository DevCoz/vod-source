# 播放页解密片段

只在播放页确实存在加密时使用。`createCryptoJS()` 有需要才初始化，AES/MD5 结果记得
`.trim()` 去掉 CR/LF。

```js
const CryptoJS = createCryptoJS()

function decryptAes(cipher, key, iv) {
  const data = CryptoJS.enc.Base64.parse(cipher)
  const k = CryptoJS.enc.Utf8.parse(key)
  const i = CryptoJS.enc.Utf8.parse(iv)
  return CryptoJS.AES.decrypt({ ciphertext: data }, k, { iv: i }).toString(CryptoJS.enc.Utf8).trim()
}

async function getPlayinfo(ext) {
  ext = argsify(ext)
  try {
    const { data } = await $fetch.get(ext.url, { timeout: 20000 })
    const match = String(data || "").match(/encrypted\s*=\s*["']([^"']+)/)
    const url = match ? decryptAes(match[1], "1234567890123456", "1234567890123456") : ""
    return jsonify({ urls: url ? [url] : [] })
  } catch (e) {
    return jsonify({ urls: [] })
  }
}
```