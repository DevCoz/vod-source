# XPTV Debugger — Anti-Bot & Obfuscation Reference

> 本文档是实战补充材料。`openSafari()`、`$fetch.download()` 等能力用于过盾排障，
> 不属于 `xptv-official-doc.md` 原文接口；生成正式 `.xptv.js` 时只在确有需要时按需使用。

## Rate Limiting

**Symptoms:** Search returns "没有搜索到相关的内容" even for known keywords. Intermittent failures.

**Diagnosis:**
1. Test with known keyword
2. Wait 30-60 seconds, retry
3. If succeeds after waiting → rate limiting confirmed

**Example (hanju7.com):** ~30 second interval required between searches.

**Key:** Some sites disguise rate limiting as empty results or "parameter error". Not a code bug.

---

## API Verification Errors (code:1004)

```json
{"code":1004,"data":null,"message":"请先完成验证"}
```

**What works:** getCards, getTracks
**What fails:** search, getPlayinfo → code:1004

**This is NOT a code bug** — server-side anti-bot enforcement. Cannot bypass without solving CAPTCHA or finding alternative endpoints.

**Workaround:** Add defensive null checks so script doesn't crash:
```javascript
const parsed = argsify(response);
if (!parsed || !parsed.data) return jsonify({ list: [] });
```

---

## Browser Handoff: openSafari() `[实战补充]`

**Use when:** `$fetch.get()` 返回 `Just a moment...`、验证码页或必须人工验证的页面。
Cloudflare 默认验证页优先用 `String(data || "").includes("Just a moment...")` 识别；其它标记只在站点
真实命中后再加。

`openSafari()` 是浏览器交接动作，不是同步解锁函数。调用后当前 `$fetch` 的响应不会
自动变成正常 HTML；后续怎么处理要看当前响应是否还能被原解析逻辑安全处理。

**Mode A: 只触发验证，继续原解析流程。**
适用于实战样本已验证可运行，或验证提示不影响当前解析结果的页面。不要为了单个标题判断
提取 helper，也不要默认扩大成站点未命中的额外关键词。

```javascript
const { data } = await $fetch.get(classurl, { headers });
if (String(data || "").includes("Just a moment...")) {
  $utils.openSafari(classurl, UA);
}
const $ = cheerio.load(String(data || ""));
```

**Mode B: 当前响应是纯验证页，继续解析会误判或崩溃。**
这种场景应打开 Safari 后返回空列表、空播放地址，或提示用户验证后重试。

```javascript
const { data } = await $fetch.get(url, { headers });
if (String(data || "").includes("Just a moment...")) {
  $utils.openSafari(url, UA);
  return jsonify({ list: [], page: page || 1, pagecount: 1 });
}
```

**Key:** 过盾判断按站点实际返回最小化编写。优先内联在请求点；传给 `openSafari()` 的
应是当前请求地址（如 `classurl` / `url`），不要固定写站点根地址。只有复用 2 次以上、
处理 JSC 兼容，或站点确实需要时才提取辅助函数。不要默认加入站点未实际命中的额外关键词。

**实战校准:** 93 个公开样本中过盾写法主要分五类，不互相替代：

- Cloudflare 默认页：命中 `Just a moment...` 后 `openSafari()`，当前响应还能安全解析时继续原流程。
- 纯验证页：SafeLine / Access Forbidden 等响应无法安全解析时，打开浏览器后返回空列表或空播放地址。
- `smart_verify`：搜索接口专用，获取 PHPSESSID 后提交 MD5 token，再带 Cookie 重试。
- PoW / Cookie：站点专用挑战，按实际算法和 `$cache` / 用户配置处理，不进入默认模板。
- OCR / 二进制：只有验证码图片、滑块背景、字体等资源确实需要分析时才用 `$fetch.download()`。

---

## Binary Download: $fetch.download() `[实战补充]`

**Use when:** 过盾流程需要下载验证码图片、背景图、滑块图、字体或其他二进制资源。

```javascript
const resp = await $fetch.download(imgUrl, { headers, timeout: 20000 });
const bin = resp.data;                 // 二进制字符串
const firstByte = bin.charCodeAt(0) & 0xff;
```

**Key:** `data` 是二进制字符串，不是 UTF-8 文本或 JSON。不要对它调用 `argsify()`、
`JSON.parse()` 或 `cheerio.load()`。XPTV 的 JSC 环境不要依赖 `Buffer`；需要逐字节分析时
使用 `charCodeAt()`。

---

## GeeTest v4 CAPTCHA

**Cannot be bypassed with pure JS.** Requires browser CDP for trusted mouse events.

### Browser Analysis Steps

1. **Find captcha_id:** `document.querySelector('[class*="geetest_captcha_"]')?.className.match(/geetest_captcha_([a-f0-9]+)/)?.[1]`

2. **Extract background image:** `document.querySelector('.geetest_bg')?.style.backgroundImage`

3. **Analyze cutout position** with canvas pixel analysis (~80px slider piece width)

4. **CDP drag simulation:**
   ```
   Input.dispatchMouseEvent type="mousePressed" x=startX y=startY button="left"
   Input.dispatchMouseEvent type="mouseReleased" x=endX y=endY button="left"
   ```

**Limitations:**
- JS `MouseEvent` has `isTrusted: false` → GeeTest rejects
- GeeTest analyzes mouse movement patterns (acceleration, jitter)
- GeeTest API behind Cloudflare — server-side fetch blocked
- Must be solved in-browser

---

## strencode2() — Encoded Video URLs (91porn)

**Site:** 91porn.com uses `strencode2()` to hide real MP4 URLs.

**Pattern:** The visible `<source src="...">` tag is commented out (fake/dead CDN). Real URL is URL-encoded hex inside `document.write(strencode2("..."))`.

**Extraction (JSC-safe, no decodeURIComponent needed):**
```javascript
const encodeMatch = data.match(/strencode2\(\"([^\"]+)\"\)/);
if (encodeMatch) {
    const mp4Match = encodeMatch[1].match(/https?%3a%2f%2f[^"'\s%]+\.mp4[^"'\s%]*/i);
    if (mp4Match) {
        videoUrl = mp4Match[0]
            .replace(/%3a/gi, ':').replace(/%2f/gi, '/')
            .replace(/%3f/gi, '?').replace(/%3d/gi, '=')
            .replace(/%26/gi, '&').replace(/%2b/gi, '+');
    }
}
```

**Anti-patterns to watch:**
- Commented-out `<source>` tags (`<!-- <source ... -->`)
- `strencode2()` / `strencode()` / `eval()` / `atob()` encoding
- Double-slash in CDN URLs (`//path/` → normalize to `/path/`)
- Multiple CDN domains (some dead, some alive)

---

## Patching Obfuscated Scripts

When script is obfuscated (e.g., jsjiami.com.v7), direct edits are fragile. Patch defensively.

### Adding null checks

Common crash: `JSON['parse'](...)['data']['list'].map(...)` when `data` is null.

```javascript
// Find the pattern
node -e 'const c=require("fs").readFileSync("script.js","utf8");const i=c.indexOf("JSON[");console.log(c.substring(i-20,i+150))'

// Patch: add null check before chained access
const _r=JSON['parse'](...);if(!_r||!_r['data'])return jsonify({'list':[]});return _r['data']['list'][...](...)
```

### Rules for obfuscated code patching:
1. Use exact string matching (whitespace matters)
2. Choose variable names unlikely to collide (e.g., `_0x305699r`)
4. Test with full smoke test after patching
