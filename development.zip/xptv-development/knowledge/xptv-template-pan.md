# 网盘 pan 模板

适用于结果就是百度、夸克、阿里、115、天翼等真实分享链接的源。网盘线路放 `pan`，
`getPlayinfo()` 返回 `{ urls: [] }`。

```js
async function getLocalInfo() {
  return jsonify({ ver: 1, name: "网盘源", api: "csp_pan_example", type: 3 })
}

async function getConfig() {
  return jsonify({ ver: 1, title: "网盘源", site: "", tabs: [] })
}

async function getCards(ext) {
  ext = argsify(ext)
  const kw = ext.text || ""
  if (!kw) return jsonify({ list: [] })
  return jsonify({ list: [] })
}

async function getTracks(ext) {
  ext = argsify(ext)
  return jsonify({
    list: [{
      title: "网盘线路",
      tracks: [{ name: ext.title || "分享链接", pan: ext.url || "", ext: {} }]
    }]
  })
}

async function getPlayinfo(ext) {
  return jsonify({ urls: [] })
}

async function search(ext) {
  return getCards(ext)
}
```