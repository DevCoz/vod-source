# XPTV Toolbox — 工具函数参考

> 本文档以开发者运行时工具为主。标注 `[实战补充]` 的能力来自过盾排障或公开样本观察，
> 用于按需处理特殊场景，不覆盖开发者文档。

## $config_str — 源配置参数

XPTV 导入源时传入的配置字符串（在源设置中填写），脚本中通过 `$config_str` 获取：

```js
const config = argsify($config_str)
// 例如导入时 ext 填了 {"api": "http://192.168.1.100:3000"}
// 则 config.api === "http://192.168.1.100:3000"

// 常见用法：本地调试代理，从配置读取 server 地址
const api = config.api || 'http://localhost:3000'
```

---

## $fetch — HTTP 请求

### GET
```js
// 默认最小请求
const { data } = await $fetch.get('http://xx.com', { timeout: 20000 });

// 站点需要防盗链或浏览器特征时再加 headers
const { data: html } = await $fetch.get('http://xx.com', {
  headers: { 'User-Agent': UA, 'Referer': SITE },
  timeout: 20000
});
```

### POST ⚠️ 关键格式
```js
// ✅ 正确：三参数 — url, body, { headers }
const { data } = await $fetch.post('http://xx.com', { key: 'value' }, {
  headers: { 'Content-Type': 'application/json' }
});

// ✅ POST 表单（字符串 body）
const { data } = await $fetch.post('http://xx.com', 'key=value&foo=bar', {
  headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
});

// ❌ 错误：{ data, headers } 塞在第二个参数 — 不支持
const { data } = await $fetch.post('http://xx.com', {
  data: { key: 'value' },
  headers: { 'Content-Type': 'application/json' }
});
```

### 解析响应
```js
const json = argsify(data);  // JSON string → object
```

### DOWNLOAD `[实战补充]`
```js
// 下载二进制资源，如验证码图片、字体、图片等
const { data } = await $fetch.download(url, {
  headers: { 'User-Agent': UA, 'Referer': SITE },
  timeout: 20000
});

// data 是二进制字符串，不是 UTF-8 文本或 JSON
const firstByte = data.charCodeAt(0) & 0xff;
```

`$fetch.download()` 只在确实需要二进制内容时使用。不要对返回的 `data` 调用
`argsify()`、`JSON.parse()` 或 `cheerio.load()`；验证码图片过盾、签名校验、图片探测等
场景才考虑它。JSC 环境没有稳定的 `Buffer`，需要逐字节处理时使用 `charCodeAt()`。

---

## 辅助函数提取规则

默认不要把脚本写成通用工具库。只有满足下面任一条件时才提取 helper：

- 同一逻辑复用 2 次以上。
- 为了处理 JSC 兼容，如替代 `Buffer`、`atob`。
- 站点确实需要集中处理，如签名、加密、Cookie、复杂相对地址。

单次使用的 URL 拼接、简单正则、一次性解码优先内联。`createCheerio()` 和
`createCryptoJS()` 也按需初始化，`CryptoJS` 只在加解密、Base64、MD5 等场景使用。

---

## createCheerio() — HTML 解析

只有脚本实际解析 HTML 时才初始化。

```js
const cheerio = createCheerio();
const $ = cheerio.load(htmlData);

// 选择
const title = $('h1').text();
const link = $('a').attr('href');
const img = $('img').attr('src');

// 遍历
$('.item').each((i, el) => {
  const $el = $(el);
  const name = $el.find('h2').text().trim();
});

// 过滤
const items = $('article.bs');        // class 选择
const first = items.first();          // 第一个
const href = $el.find('a').first().attr('href');
```

---

## createCryptoJS() — 加密解密

只有脚本实际需要加解密、Base64、MD5 等能力时才初始化。

```js
const CryptoJS = createCryptoJS();

// Base64 解码（JSC 沙箱中必须用这个）
const decoded = CryptoJS.enc.Utf8.stringify(
  CryptoJS.enc.Base64.parse(base64Str)
);

// Base64 编码
const encoded = CryptoJS.enc.Base64.stringify(
  CryptoJS.enc.Utf8.parse(text)
);

// AES 解密
const decrypted = CryptoJS.AES.decrypt(encrypted, key)
  .toString(CryptoJS.enc.Utf8);
```

---

## Base64 函数（JSC 兼容）

```js
function base64Decode(str) {
  try {
    const CryptoJS = createCryptoJS();
    return CryptoJS.enc.Utf8.stringify(
      CryptoJS.enc.Base64.parse(str)
    );
  } catch (e) {
    return '';
  }
}
```

> 不要依赖 `Buffer` / `atob` / `btoa`。它们在 Node/浏览器里常见，但 XPTV 的 JavaScriptCore 沙箱中不可用或不稳定。

---

## URL 编解码

```js
const encoded = encodeURIComponent(text);
const decoded = decodeURIComponent(text);
```

---

## 缓存

```js
const v = $cache.get('key');
$cache.set('key', 'value');
$cache.del('key');
```

---

## 系统信息

```js
$utils.os()        // "tvOS/18.1"
$utils.app()       // "2.0"
$utils.toastInfo('提示信息')
$utils.toastError('错误信息')
$print('调试日志')  // 输出到 http://ip:8110/log
```

### openSafari `[实战补充]`

`$utils.openSafari(url, ua)` 的过盾口径只维护在 `xptv-anti-bot.md`。这里仅记录入口：

```js
$utils.openSafari(url, UA)
```

使用时按站点实际命中的标题、标记或错误码最小化内联判断；Cloudflare 默认验证页优先用
`String(data || "").includes("Just a moment...")`，并传当前请求地址。不要默认提取 helper，也不要
默认加入站点未命中的额外关键词。

---

## 请求头按需增强

```js
// 默认先用最小请求
const { data } = await $fetch.get(url, { timeout: 20000 });

// 403、空列表、防盗链或播放失败时再补必要请求头
const UA = 'Mozilla/5.0 (iPhone; CPU iPhone OS 26_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.0 Mobile/15E148 Safari/604.1';

const PC_UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36';

const headers = {
  'User-Agent': UA,
  'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
  'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8',
  'Referer': SITE + '/'
};
```

不要为新源默认写统一 headers 函数。只有同一组请求头复用 2 次以上，或站点确实要求
`Referer`/`Origin`/Cookie 时，再提取为常量或函数。

---

## getCards ext 解构参考

```js
async function getCards(ext) {
  ext = argsify(ext);
  const { page = 1, id, filters = {} } = ext;
  // id: 当前 tab/class 标识（来自 tabs[].ext.id）
  // page: 分页，默认 1
  // filters: 筛选参数字典（来自 filter[].key）
  //   例如: { "type": "all", "year": "2024" }
}
```

### Filter 协议速查

- `filter[].key` → 下次请求的 `ext.filters[key]`
- 请求缺少某个筛选键时，按该项 `init` 处理
- 非法值回退到 `init`
- 响应无 `filter` 字段 → 无筛选页面
- `filterList` 只作为脚本内部常量表；返回字段仍然叫 `filter`

```js
// 响应中定义筛选
return jsonify({
  list: [...],
  filter: [{
    key: 'type',        // → ext.filters.type
    name: '类型',
    init: 'all',        // 默认值
    value: [
      { n: '全部', v: 'all' },
      { n: '喜剧', v: '喜剧' }
    ]
  }]
});
```

```js
// 固定筛选较多时，可用 filterList 集中维护
const filterList = {
  "1": [{ key: "type", name: "类型", init: "", value: [{ n: "全部", v: "" }] }]
}

async function getCards(ext) {
  ext = argsify(ext)
  const filter = filterList[ext.id] || []
  return jsonify({ list: list, filter: filter })
}
```

### GET 高级参数
```js
// timeout: 请求超时（毫秒）
const { data } = await $fetch.get(url, { headers: { ... }, timeout: 20000 });

// respHeaders: 访问响应头
const resp = await $fetch.get(url, { headers: { ... } });
const setCookie = resp.headers['set-cookie'];   // 或 resp.respHeaders
const rawBody = resp.data;                       // 响应体
```

### DOWNLOAD 返回值 `[实战补充]`
```js
const resp = await $fetch.download(url, { headers: { ... }, timeout: 20000 });
const bin = resp.data;              // 二进制字符串
const byte0 = bin.charCodeAt(0) & 0xff;
// resp.headers / resp.respHeaders 同样可用于读取响应头
```

### POST 返回值
```js
const resp = await $fetch.post(url, body, { headers: { ... } });
const json = argsify(resp.data);
// resp.respHeaders — 部分环境使用 respHeaders 获取响应头
```

---

## 实战辅助（不覆盖开发者文档）

以下内容用于分析公开脚本包。生成正式 `.xptv.js` 时，先按开发者文档
文档和模板实现，再按需要参考这些观察。

### 公开实战脚本导入观察
```js
const $config = argsify($config_str)

tracks.push({ name: '第1集', ext: { url: playUrl } })

// 真实网盘 track：才设置 pan
tracks.push({ name: '链接详情', pan: panUrl, ext: {} })
```

- 远程订阅脚本可能没有 `getLocalInfo()`；这只用于样本分析，不改变本地 `.xptv.js` 的入口要求。
- 详细统计见 `xptv-realworld-scripts.md`。

### search 入参
```js
async function search(ext) {
  ext = argsify(ext);
  const { text, page = 1 } = ext;
  const keyword = text || '';
  // ...
}
```

### vod_duration 卡片附加信息
```js
// 卡片上显示额外信息（在线人数、主播名等）
list.push({
  vod_id: e.rid.toString(),
  vod_name: e.roomName,
  vod_pic: e.roomSrc,
  vod_duration: `🔥${e.hn} | ${e.nickname}`,  // 非标准但广泛使用
  ext: { id: e.rid.toString() }
});
```

### Cookie 手动管理（过盾场景）
```js
function createCookieJar() { return {}; }

function mergeSetCookie(jar, setCookieHeaders) {
  const values = Array.isArray(setCookieHeaders) ? setCookieHeaders : [setCookieHeaders];
  for (const raw of values) {
    const first = String(raw).split(';')[0];
    const idx = first.indexOf('=');
    if (idx <= 0) continue;
    jar[first.slice(0, idx).trim()] = first.slice(idx + 1).trim();
  }
}

function cookieHeaderStr(jar) {
  return Object.entries(jar).map(([k, v]) => `${k}=${v}`).join('; ');
}

// 使用: 从 resp.headers['set-cookie'] 提取, 拼接后作为 Cookie 头发送
mergeSetCookie(jar, resp.headers?.['set-cookie'] || []);
const cookie = cookieHeaderStr(jar);
```

### 全局 try-catch + 兜底返回
```js
async function getConfig() {
  try {
    // ... 正常逻辑
    return jsonify({ ver: 1, title: 'xxx', site: SITE, tabs: [...] });
  } catch (error) {
    $print('getConfig error: ' + (error.message || error));
    // 兜底：即使失败也返回有效结构，不返回空
    return jsonify({ ver: 1, title: 'xxx', site: SITE, tabs: [{ name: '全部', ext: { id: 'all' } }] });
  }
}
```

### CDN × 画质矩阵（直播源）
```js
// 先请求一次拿 CDN 列表 + 画质列表
const firstRes = await $fetch.post(url, toQS({...baseParams, rate: '0'}), { headers });
const { cdnsWithName, multirates } = argsify(firstRes.data).data;

// 双重循环：每条CDN × 每个画质
for (const cdn of cdnsWithName.slice(0, 3)) {
  for (const q of multirates.slice(0, 5)) {
    const res = await $fetch.post(url, toQS({...baseParams, rate: q.rate, cdn: cdn.cdn}), { headers });
    // 收集播放地址...
  }
}
```

### toQueryString 工具函数
```js
function toQueryString(obj) {
  return Object.keys(obj)
    .filter(k => obj[k] != null && obj[k] !== '')
    .map(k => `${k}=${obj[k]}`)
    .join('&');
}
```

### 随机设备 ID（防限连）
```js
function randHex(len) {
  return Array.from({ length: len }, () => Math.floor(Math.random() * 16).toString(16)).join('');
}
const did = randHex(32);

// 常见用法：作为 Cookie 或 API 参数
headers: { Cookie: `dy_did=${did}; acf_did=${did}` }
```
