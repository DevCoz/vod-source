# XPTV Harness Strict Validation Notes

Session-derived maintenance notes for improving and verifying `xptv_harness.js`.

## Durable changes worth preserving

- Add a `--strict` mode for final delivery checks, while keeping normal `smoke` mode permissive for early development.
- Strict mode should treat these as failures:
  - missing required interfaces
  - interface returns a raw object instead of a `jsonify()` JSON string
  - empty `tabs`, `list`, or `tracks` where the interface should produce usable content
  - schema mismatches such as non-array `urls`, missing `vod_name`, missing `ext`, or missing track `name`
- Normal mode may warn instead of failing for raw object returns so debugging remains convenient.

## Schema checks implemented in harness

- `getLocalInfo`: require `ver`, `name`, `api`; warn when `api` does not start with `csp_`; warn when `type` is not `3` or `4`.
- `getConfig`: require `ver`, `title`, `tabs[]`; validate `tabs[].name` and `tabs[].ext`.
- `getCards` / `search`: require `list[]`; validate each card has `vod_id`, `vod_name`, and object `ext`.
- `getTracks`: require `list[]`; validate each group has `title` and `tracks[]`; each track needs `name` plus either `pan` or object `ext`.
- `getPlayinfo`: require `urls[]`; if `headers` exists it must be an array; warn when `urls` is empty but `headers` is present.

## Important harness data-flow fix

When smoke-testing `getTracks`, pass the full first card `ext` through:

```js
const trackExt = JSON.stringify(cards.list[0].ext || {
  url: cards.list[0].vod_id,
  id: cards.list[0].vod_id,
})
```

Do not collapse it to `{ url: cards.list[0].ext?.url || vod_id }`, because real scripts often store extra fields in `ext` (`id`, `api`, `token`, etc.).

## Self-test fixture pattern

Keep a complete offline fixture such as `fixtures/mock_source.xptv.js` that implements all six interfaces and returns one valid card/track/play URL. Use it to test harness behavior independently from network sites and from the intentionally-empty base template.

Recommended verification after harness/toolkit edits:

```bash
node --check xptv_harness.js
node xptv_harness.js list templates/base.xptv.js
node xptv_harness.js smoke templates/base.xptv.js --keyword 测试
node xptv_harness.js smoke fixtures/mock_source.xptv.js --strict --keyword 测试
```

Expected durable signal: base template may skip downstream interfaces because it has empty cards; the mock fixture should pass all six interfaces in strict mode.
