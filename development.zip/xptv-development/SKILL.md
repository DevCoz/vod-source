---
name: xptv-development
description: "XPTV 脚本开发技能 — 创建、调试和维护 XPTV 本地 JavaScript 脚本（.xptv.js）。触发词：xptv, 写源, xptv脚本,.xptv.js"
---

# XPTV Script Development Skill

## When to Use
- 用户要求创建/编写 XPTV 源脚本
- 用户要求调试/修复已有 `.xptv.js` 脚本
- 用户询问 XPTV 脚本接口、数据格式或最佳实践
- 用户提供目标站点，希望制作 XPTV 源

## Quick Decision Tree

```
用户请求 → 确定操作类型：
  ├─ 脚本已混淆(jsjiami等) → 直接跳转「运行时调试」(knowledge/xptv-runtime-debug.md)
  ├─ 创建/修改正式脚本 → 先读开发者基线，再读 knowledge/xptv-dev-guide.md
  ├─ 调试正式脚本 → 先读开发者基线，再读 knowledge/xptv-debug-guide.md
  ├─ 分析/迁移公开实战脚本 → 先读开发者基线，再读 knowledge/xptv-realworld-scripts.md
  └─ 咨询接口/格式问题 → 查阅 knowledge/xptv-api-reference.md
```

## 执行模式

流程：识别类型 → 选模板 → 按场景实现入口与调用链 → 搭建测试 → 验证修复 → 交付成品。

**自动推进**：类型明确、模板匹配时直接执行，不中途确认。

**必须暂停确认**：
- 站点类型/API 结构不确定（呈现你的判断依据，问用户确认）
- 存在多种可行方案时（列出权衡，让用户选择）
- 目标站点完全无法访问
- 流地址获取需要特定账号/权限

**不要假设**：不确定时先确认，不要默默选一种解释然后执行。

## Source Priority

生成和修改正式 XPTV 脚本时，以开发者文档为准；实战样本只用于辅助排障和
理解公开样本，不作为兼容模板。开发者文档口径与实战样本冲突时，开发者文档优先。

默认加载顺序：

1. 开发者文档原文与开发者整理：`xptv-official-doc.md`、`xptv-api-reference.md`、`xptv-toolbox.md`
2. 开发者文档风格实现材料：`xptv-templates.md`（小模板索引）、`xptv-dev-guide.md`、`xptv-debug-guide.md`
3. 实战辅助材料：`xptv-realworld-scripts.md`、patterns、case studies，仅在公开样本分析或排障时加载

## Reference Documents

按需加载，不要一次性读完全部文档。根据场景只读相关文件：

**开发者基线**：
1. **开发者文档存档**: `knowledge/xptv-official-doc.md` — XPTV 开发者文档原文，不改写
2. **API 参考**: `knowledge/xptv-api-reference.md` — 按开发者文档口径整理接口、参数、返回格式
3. **工具箱**: `knowledge/xptv-toolbox.md` — 开发者运行时工具与最小辅助函数

**正式脚本开发/调试**：
4. **模板库索引**: `knowledge/xptv-templates.md` — 指向最小 HTML、JSON API、网盘、过盾片段、播放解密等小模板
5. **开发指南**: `knowledge/xptv-dev-guide.md` — 创建新源的完整执行步骤
6. **调试指南**: `knowledge/xptv-debug-guide.md` — 调试流程、故障排除、错误恢复

**实战辅助（不覆盖开发者文档）**：
7. **实战脚本样本**: `knowledge/xptv-realworld-scripts.md` — 公开脚本统计，用于样本分析和排障
8. **可复用模式**: `knowledge/xptv-patterns.md` — 实战模式，只在对应场景按需参考
9. **实战案例**: `knowledge/xptv-case-studies.md` — 站点逆向案例
10. **调试案例集**: `knowledge/xptv-debugging-case-studies.md` — 调试案例
11. **运行时调试**: `knowledge/xptv-runtime-debug.md` — Puppeteer hook 反混淆方法

**专项辅助**：
12. **反爬虫参考**: `knowledge/xptv-anti-bot.md` — GeeTest、rate limiting、strencode2
13. **常见问题**: `knowledge/xptv-troubleshooting.md` — 常见故障排查
14. **图片 CDN**: `knowledge/xptv-image-cdn-compatibility.md` — 已知 CDN 兼容性表
15. **Git 工作流**: `knowledge/xptv-pr-workflow.md` — PR 创建和代码同步

## Documentation Boundaries

`SKILL.md` 只保留总规则和加载顺序；接口细节看 `xptv-api-reference.md`，运行时工具看
`xptv-toolbox.md`，过盾只以 `xptv-anti-bot.md` 为主口径，模板从 `xptv-templates.md`
索引进入。公开样本只作为案例和排障线索，不进入默认模板。

## Core Architecture

### Six Interfaces

完整影视源通常包含以下六个接口。正式本地 `.xptv.js` 以开发者文档为准：
本地 JS 文件需要 `getLocalInfo()`；其余接口按 XPTV 的调用链返回对应数据。
公开仓库脚本、远程订阅脚本等差异只作为实战辅助判断，不改写正式脚本规范。

```
getLocalInfo()  → { ver, name, api, type? }    ← 元数据，本地源必须实现
getConfig()     → { ver, title, site, tabs[{name, ext}] }
getCards(ext)   → { list[{vod_id, vod_name, vod_pic, vod_remarks, ext}], filter? }
getTracks(ext)  → { list[{title, tracks[{name, pan?, ext}]}], info? }
getPlayinfo(ext)→ { urls[], headers?[] }
search(ext)     → { list[], page? }
```

> **getLocalInfo 说明**：本地 `.xptv.js` 文件**必须**实现，`api` 字段必须全局唯一（如 `csp_sitename`）。

### Data Flow
```
getLocalInfo()                         ← 独立调用，XPTV 用此识别和管理源
getConfig.tabs[].ext → getCards(ext)
getCards.list[].ext  → getTracks(ext)
getTracks.list[].tracks[].ext → getPlayinfo(ext)
```

### Cloud Drive (网盘) Pattern
```
getTracks: tracks[].pan = "https://pan.quark.cn/s/..."
getPlayinfo: return { urls: [] }  // 空 — 播放器直接处理 pan
```

开发者示例使用 `pan` 字段表达网盘线路。在线播放线路使用 `ext.url`；网盘线路使用
真实 `pan` 链接。

### Critical Rules
1. **开发者文档优先**：开发者文档与实战样本冲突时，生成正式脚本按开发者文档口径
2. **所有返回**：用 `jsonify()` 包装，永远不返回原始对象
3. **JSON 入参**：XPTV 传入的 `$config_str`、`ext` 等 JSON 字符串用 `argsify()` 解析后再使用
4. **$fetch.post()**：`$fetch.post(url, body, { headers: {...} })` — 三参数格式
5. **文件命名**：`[name].xptv.js`
6. **getPlayinfo 失败/网盘源**：返回 `{ urls: [] }`，不添加多余的 `headers: []`
7. **API 字段唯一**：`getLocalInfo` 的 `api: "csp_xxx"` 必须全局唯一
8. **筛选列表**：`filterList` 只作为脚本内部常量表；客户端返回字段仍为 `filter`，且只在站点筛选稳定或用户明确要求时添加
9. **辅助函数按需**：只有复用 2 次以上、处理 JSC 兼容、或站点确实需要的逻辑才提取辅助函数
10. **请求头按需**：列表/详情请求默认不写统一 headers；遇到 403、空列表、防盗链、播放失败时再补 `User-Agent`、`Referer`、`Origin` 等必要头
11. **过盾按命中点内联**：只有真实响应命中过盾页时才加；Cloudflare 默认页用 `String(data || "").includes("Just a moment...")` 配合 `$utils.openSafari(currentUrl, UA)`；当前响应可安全解析就继续，纯验证页才返回空结构；`$fetch.download()` 只用于验证码图片等二进制资源

## Anti-Patterns（优先避免的做法）

| ❌ 错误做法 | ✅ 正确做法 |
|------------|------------|
| 把缺失的非入口接口直接判定为错误 | 本地源必须有 `getLocalInfo()`；常规模板建议补齐调用链，精简脚本按实际调用实现 |
| `$fetch.post(url, {data, headers})` | `$fetch.post(url, body, {headers})` |
| 返回原始对象 | `jsonify()` 包装 |
| 把 XPTV 传入的 `ext` / `$config_str` 当普通字符串直接取字段 | `argsify(...)` 解析后使用 |
| 生产代码用 `console.log()` | `$print()` 调试，生产移除 |
| api 字段重复 | 全局唯一 |
| `{ urls: [], headers: [] }` | `{ urls: [] }` |
| 返回 `{ filterList: ... }` | 内部用 `filterList` 维护，`getCards()` 返回 `filter` |
| 为单次使用逻辑提取 helper | 直接内联；复用 2 次以上或 JSC 兼容需求再提取 |
| 新源默认写统一 headers 函数 | 先用最小 `$fetch.get(url, { timeout })`；请求失败或防盗链时再补必要头 |
| 老脚本 `$html` 直接照搬到新源 | 新源用开发者工具链；公开样本写法只用于问题定位 |
| 过盾后固定一种处理：总是提前返回，或总是当正常页解析 | 按响应内容决定；可安全解析就继续，纯验证页才返回空结果或提示处理 |
| 默认提取 `isVerifyPage()`、铺一组 Cloudflare 关键词或添加 `$fetch.download()` | 只写站点实际命中的判断；`download` 仅用于验证码图片、字体等二进制资源 |
| 网盘链接放 `ext.url` | 用 `pan` 参数 |
| 不确认就假设站点类型/API 结构 | 先分析再确认，呈现判断依据 |
| AES 解密后不 trim | `.trim()` 去除 CR/LF |
| 解密用 `md5X()` 占位符 | `CryptoJS.MD5()` |
| 重复解析逻辑复制粘贴 | 提取公共函数 |

## Quality Checklist (验证循环)

每项检查后运行 `xptv_harness.js smoke` 验证，失败则修复再重跑，直到全部通过。

**接口完整性**：
- [ ] 本地 `.xptv.js` 包含 `getLocalInfo()`
- [ ] 常规模板/完整影视源补齐 `getConfig()`、`getCards()`、`getTracks()`、`getPlayinfo()`、`search()`
- [ ] tab/category ID 与 `getCards()` 对应

**数据格式**：
- [ ] 所有返回 `jsonify()` 包装
- [ ] XPTV 传入的 `ext` / `$config_str` 用 `argsify()` 解析
- [ ] `search()` 返回标准卡片格式
- [ ] 如使用 `filterList`，只作为内部常量表，`getCards()` 返回 `filter`
- [ ] 横式图片加 `ui: 1`
- [ ] 辅助函数是否满足复用 2 次以上、JSC 兼容或站点必要性？

**逻辑正确**：
- [ ] `getTracks()` 至少一条有效线路
- [ ] 网盘源用 `pan`，`getPlayinfo()` 返回空
- [ ] `$fetch.post()` 三参数格式
- [ ] 请求头是否按需添加，而不是默认铺满？
- [ ] 过盾判断是否只在实际请求点内联，`openSafari()` 是否传当前请求地址？
- [ ] `CryptoJS.MD5()` 非 `md5X()` 占位符
- [ ] AES 解密后 `.trim()`
- [ ] 错误降级不抛异常

**交付前自检**：是否只做了用户要求的功能？有没有加未要求的"灵活性"？如果资深工程师看这代码，会觉得过度复杂吗？

## Quick Test (XPTV Harness)

独立的 CLI 测试工具，无需启动 Express 服务器即可测试脚本。

```bash
# 烟雾测试 — 自动跑可用接口与调用链
node xptv_harness.js smoke <script.xptv.js>

# 严格模式 — 校验 jsonify()、schema、空列表等
node xptv_harness.js smoke <script.xptv.js> --strict

# 指定搜索关键词
node xptv_harness.js smoke <script.xptv.js> --keyword 龙珠

# 单步执行 — 测试指定接口
node xptv_harness.js run <script.xptv.js> --fn getCards --ext '{"id":"1","page":1}'

# 列出脚本实现的接口
node xptv_harness.js list <script.xptv.js>

# 分析站点类型
node xptv_harness.js analyze <url>
```

## Tooling Maintenance Notes

When improving the toolkit itself, verify both documentation consistency and executable behavior:
- If `xptv_harness.js` loads user scripts, missing optional interfaces must not throw `ReferenceError`; use `typeof fnName !== 'undefined' ? fnName : undefined` so `list` can report absent functions cleanly.
- If the harness uses ES modules, provide a real `package.json` with `"type": "module"` and the required runtime deps (`axios`, `cheerio`, `crypto-js`), not only an alternate package manifest name.
- README directory trees must match files that actually ship with the skill; remove stale dev-server/rollup paths unless those files exist.
- 文档回扫用 `rg --glob '!**/node_modules/**' --glob '!package-lock.json'`，避免依赖目录噪音误导判断。
- After toolkit edits, run at least: `node xptv_harness.js list templates/base.xptv.js`, `node xptv_harness.js smoke templates/base.xptv.js --keyword 测试`, and `node xptv_harness.js smoke fixtures/mock_source.xptv.js --strict --keyword 测试`.
- For detailed strict-mode schema rules and the smoke-test data-flow pitfall, see `references/harness-strict-validation.md`.

`getConfig → getCards → getTracks → getPlayinfo`

**简洁优先**：能用模板解决的不手写，能 50 行搞定的不写 100 行。不加未要求的功能，不为不可能的场景做防御。

**精准修改**：调试时只改必须改的，不"顺手优化"其他逻辑。匹配脚本现有风格。
