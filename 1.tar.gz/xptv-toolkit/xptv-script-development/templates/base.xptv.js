const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36';
const SITE = 'https://example.com';

function base64Decode(str) {
  try {
    if (typeof Buffer !== 'undefined') {
      return Buffer.from(str, 'base64').toString();
    } else if (typeof atob !== 'undefined') {
      return atob(str);
    } else {
      const CryptoJS = createCryptoJS();
      return CryptoJS.enc.Utf8.stringify(CryptoJS.enc.Base64.parse(str));
    }
  } catch (e) {
    return '';
  }
}

async function getLocalInfo() {
  return jsonify({
    ver: 1,
    name: '示例源',
    api: 'csp_example',
    type: 3
  });
}

async function getConfig() {
  return jsonify({
    ver: 1,
    title: '示例源',
    site: SITE,
    tabs: [
      { name: '全部', ext: { id: 'all' } }
    ]
  });
}

async function getCards(ext) {
  ext = argsify(ext);
  const { id, page = 1 } = ext;
  const list = [];
  return jsonify({ list, page });
}

async function getTracks(ext) {
  ext = argsify(ext);
  const { id, url } = ext;
  return jsonify({
    list: [
      {
        title: '默认线路',
        tracks: []
      }
    ]
  });
}

async function getPlayinfo(ext) {
  try {
    ext = argsify(ext);
    const { url } = ext;
    return jsonify({
      urls: url ? [url] : [],
      headers: [{ 'User-Agent': UA, 'Referer': SITE + '/' }]
    });
  } catch (error) {
    console.error('getPlayinfo error:', error);
    return jsonify({ urls: [] });
  }
}

async function search(ext) {
  ext = argsify(ext);
  const { text, wd, page = 1 } = ext;
  const keyword = text || wd || '';
  const list = [];
  return jsonify({ list, page, keyword });
}
