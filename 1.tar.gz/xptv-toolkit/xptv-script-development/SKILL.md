---
name: xptv-script-development
description: "Develop XPTV local JavaScript source scripts (.xptv.js) that implement six required interfaces, return correct JSON payloads, and support MacCMS API, HTML-scraping, and netdisk (网盘) sites. Use when user mentions \"写源\", \"xptv源\", \"xptv脚本\", \"播放源\", \"视频源\", \"抓取\", \"maccms\", \"网盘源\", \"JSON源\"."
version: 1.3.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [xptv, javascript, scraping, video, maccms, html-parsing]
    related_skills: [systematic-debugging, writing-plans]
---

# XPTV Script Development

Use this skill when the user wants an `.xptv.js` script for XPTV, or wants help debugging / extending an existing XPTV local script.

## Goal

Produce a working local JavaScript script for XPTV that:
- follows XPTV's required interface contract
- uses `jsonify()` for all returns
- uses `argsify()` to parse incoming `ext`
- supports category browsing, detail pages, playback extraction, and search
- is easy to debug when the target site changes

## Required Interfaces

Every XPTV local script must implement these six async functions:

```javascript
async function getLocalInfo() { ... }
async function getConfig() { ... }
async function getCards(ext) { ... }
async function getTracks(ext) { ... }
async function getPlayinfo(ext) { ... }
async function search(ext) { ... }
```

Do not omit any of them.

## Core Rules

1. Always return with `jsonify(...)`.
2. Always parse `ext` with `argsify(ext)` in functions that receive arguments.
3. Keep data flowing through `ext` between interfaces.
4. Prefer stable IDs and URLs in `ext` so later stages do not need to re-derive them.
5. Add defensive parsing and graceful fallbacks for empty data.
6. Add `User-Agent` and usually `Referer` headers for site requests.
7. When scraping HTML, verify selectors against live page structure before finalizing.

## Data Flow Contract

Typical flow:

- `getConfig()` defines tabs with `tabs[].ext`
- `getCards(ext)` receives those values and returns `vod_id` + `ext`
- `getTracks(ext)` receives the card payload and returns episode `tracks[].ext`
- `getPlayinfo(ext)` receives the track payload and returns real media URLs
- `search(ext)` returns the same structure as `getCards(ext)`

Design `ext` so each stage has exactly what it needs.

Example:

```javascript
ext: {
  id: "123",
  url: "https://site/detail/123",
  tid: "anime"
}
```

## Development Workflow

### 0) Pre-analysis: Detect card image orientation (橫式/直式)

Before writing the script, sample 3-5 card images from the site to determine if they are horizontal (橫式) or vertical (直式). This affects how XPTV displays the cards.

**Why it matters:**
- If images are horizontal (widescreen, e.g. 16:9), add `ui: 1` to each tab in `getConfig()`
- This tells XPTV to display cards in landscape mode

**Detection method (using shell/Python during analysis phase):**

```bash
# Download first 8KB of image and parse dimensions
python3 -c "
import urllib.request, struct

def get_image_size(url):
    req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0', 'Range': 'bytes=0-8191'})
    data = urllib.request.urlopen(req).read()
    
    # JPEG: find SOF marker (ffc0-ffcf)
    if data[:2] == b'\xff\xd8':
        i = 2
        while i < len(data) - 9:
            if data[i] == 0xff and data[i+1] in [0xc0, 0xc1, 0xc2, 0xc3, 0xc5, 0xc6, 0xc7, 0xc9, 0xca, 0xcb]:
                h = struct.unpack('>H', data[i+5:i+7])[0]
                w = struct.unpack('>H', data[i+7:i+9])[0]
                return w, h
            i += 2
    
    # PNG: width/height at bytes 16-23
    elif data[:8] == b'\x89PNG\r\n\x1a\n':
        w = struct.unpack('>I', data[16:20])[0]
        h = struct.unpack('>I', data[20:24])[0]
        return w, h
    
    return None, None

# Test with sample image URLs from the site
urls = [
    'https://example.com/image1.jpg',
    'https://example.com/image2.jpg',
    'https://example.com/image3.jpg',
]

results = []
for url in urls:
    w, h = get_image_size(url)
    if w and h:
        orientation = 'horizontal' if w > h else 'vertical' if h > w else 'square'
        results.append(orientation)
        print(f'{w}x{h} -> {orientation}')

# Determine overall site orientation
if results:
    from collections import Counter
    most_common = Counter(results).most_common(1)[0][0]
    print(f'\\nSite images are mostly: {most_common}')
"
```

**Applying the result in `getConfig()`:**

```javascript
// If images are horizontal, add ui: 1 to each tab
async function getConfig() {
  return jsonify({
    ver: 1,
    title: '源名',
    site: SITE,
    tabs: [
      { name: '分類1', ext: { id: 'cat1' }, ui: 1 },  // ← 橫式圖片
      { name: '分類2', ext: { id: 'cat2' }, ui: 1 },
    ]
  });
}
```

**Strategy:**
- Sample 3-5 images from different categories
- If all/most are the same orientation, apply `ui: 1` (horizontal) or omit `ui` (vertical/default) to all tabs
- If mixed, either skip `ui` or apply based on majority
- For sites with video content (movies, dramas, adult), images are usually horizontal (16:9)
- For comic/manhua sites, images are often vertical/portrait

### 1) Identify site type

Choose one of these approaches first:

#### A. MacCMS API source
Use when the site exposes an API like:

```text
/api.php/provide/vod/at/xml
```

Typical pattern:
- list page via `?ac=list&pg=1&tid=...`
- detail via `?ac=detail&ids=...`
- search via `?ac=list&wd=关键词&pg=1`

#### B. HTML scraping source
Use when the site renders lists and detail pages directly in HTML.

Typical pattern:
- parse listing cards from category/search pages
- parse episode links from detail pages
- parse real player URL from iframe, inline JS, JSON-LD, or encrypted payloads

#### C. Download/cloud storage site (网盘源)
Use when the site provides cloud storage links (百度网盘/迅雷网盘/夸克网盘) or magnet links instead of streaming URLs. Common for resource/download sites.

**关键规则：网盘源使用 `pan` 参数，不要放进 `ext`**

`getTracks()` 中的 track 应使用 `pan` 参数传递网盘链接，XPTV 会自动调用对应网盘插件处理：

```javascript
// ✅ 正确：使用 pan 参数
tracks.push({
  name: 'S01E01.1080P',
  pan: 'https://pan.quark.cn/s/xxxxx',
  ext: {}
});

// ❌ 错误：不要把网盘链接放在 ext.url 里
tracks.push({
  name: 'S01E01',
  ext: { url: 'https://pan.quark.cn/s/xxxxx' }
});
```

`getPlayinfo()` 直接返回空即可，XPTV 不需要从网盘链接解析播放地址：

```javascript
async function getPlayinfo(ext) {
  return jsonify({ urls: [] });
}
```

**XPTV 支持的网盘：夸克、阿里、115、天翼。百度/迅雷/磁力不支持。**

```javascript
// ✅ 提取支持的网盘（夸克、阿里、115、天翼）
function detectPanType(href) {
  if (href.includes('pan.quark.cn')) return '夸克';
  if (href.includes('pan.aliyun.com') || href.includes('aliyundrive')) return '阿里';
  if (href.includes('115.com') || href.includes('115cdn')) return '115';
  if (href.includes('cloud.189.cn')) return '天翼';
  return '';
}

$section.find('a').each((i, a) => {
  const href = $(a).attr('href') || '';
  if (detectPanType(href) && !firstPan) {
    firstPan = href;
  }
});

// ❌ 不要提取不支持的网盘
if (href.includes('pan.baidu.com')) ...  // 不支持
if (href.includes('pan.xunlei.com')) ... // 不支持
if (href.startsWith('magnet:')) ...      // 不支持
```

无法按集解析时的兜底：提取所有支持的网盘链接：
```javascript
article.find('a').each((i, a) => {
  const href = $(a).attr('href') || '';
  const panType = detectPanType(href);
  if (panType && !seen.has(href)) {
    tracks.push({ name: $(a).text().trim() || panType + '网盘', pan: href, ext: {} });
  }
});
```

脚本头部应注明此限制：
```javascript
// 注意：此站提供网盘下载链接（夸克/阿里/115/天翼），
//       需要对应网盘 APP 或插件才能播放。
```

## Standard Script Skeleton

Start from this baseline and adapt it:

```javascript
const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36';
const SITE = 'https://example.com';

async function getLocalInfo() {
  return jsonify({
    ver: 1,
    name: '示例源',
    api: 'csp_example',
    type: 3
  });
}

async function getConfig() {
  return jsonify({
    ver: 1,
    title: '示例源',
    site: SITE,
    tabs: [
      { name: '全部', ext: { id: 'all' } }
    ]
  });
}

async function getCards(ext) {
  ext = argsify(ext);
  const { id, page = 1 } = ext;
  return jsonify({ list: [], page });
}

async function getTracks(ext) {
  ext = argsify(ext);
  const { id, url } = ext;
  return jsonify({ list: [] });
}

async function getPlayinfo(ext) {
  ext = argsify(ext);
  const { url } = ext;
  return jsonify({
    urls: [],
    headers: []
  });
}

async function search(ext) {
  ext = argsify(ext);
  const { text, wd, page = 1 } = ext;
  return jsonify({ list: [], page });
}
```

## Interface Requirements and Patterns

### 1. `getLocalInfo()`

Purpose: identify the source inside XPTV.

Required fields:

```javascript
{
  ver: 1,
  name: '源名称',
  api: 'csp_unique_id'
}
```

Common optional fields:

```javascript
{
  type: 3,
  categories: [
    { id: 'all', name: '全部' },
    { id: '1', name: '分类1' }
  ]
}
```

Guidelines:
- `ver` should be `1`
- `api` should be unique and stable
- use `type: 3` for typical VOD sources
- if category IDs are known and stable, you can expose them here too

### 2. `getConfig()`

Purpose: define visible tabs in XPTV.

Required shape:

```javascript
{
  ver: 1,
  title: '源标题',
  site: SITE,
  tabs: [
    { name: '最新', ext: { id: 'latest' } }
  ]
}
```

Guidelines:
- each tab's `ext` should include everything `getCards()` will need
- keep tab names user-friendly
- if pagination or special query params differ by tab, include them in `ext`

### 3. `getCards(ext)`

Purpose: return a page of video cards.

Input usually contains:

```javascript
{ id: '分类ID', page: 1 }
```

Output shape:

```javascript
{
  list: [
    {
      vod_id: '唯一ID',
      vod_name: '片名',
      vod_pic: '封面URL',
      vod_remarks: '更新信息',      // optional
      vod_duration: '片长',         // optional
      vod_pubdate: '上映日期',      // optional
      ext: {
        id: '123',
        url: 'https://example.com/detail/123'
      }
    }
  ],
  page: 1
}
```

Implementation checklist:
- parse `page` with a default of `1`
- normalize relative URLs into absolute URLs when needed
- ensure `vod_id` is stable and sufficient for detail lookup
- put future lookup data into `ext`
- return an empty list instead of throwing where possible

### 4. `getTracks(ext)`

Purpose: return playable lines and episode lists.

Typical output (在线播放源):

```javascript
{
  list: [
    {
      title: '默认线路',
      tracks: [
        {
          name: '第1集',
          ext: { url: 'https://example.com/play/ep1' }
        }
      ]
    }
  ]
}
```

Typical output (网盘源 — 百度/迅雷/夸克):

```javascript
{
  list: [
    {
      title: '夸克网盘',
      tracks: [
        {
          name: 'S01E01.1080P',
          pan: 'https://pan.quark.cn/s/xxxxx',  // ← 用 pan 参数
          ext: {}
        }
      ]
    },
    {
      title: '阿里网盘',
      tracks: [
        {
          name: 'S01E01.1080P',
          pan: 'https://www.aliyundrive.com/s/xxxxx',
          ext: {}
        }
      ]
    }
  ]
}
```

**网盘源 vs 在线源区别：**
- 在线播放源：播放链接放 `ext.url`，XPTV 调用 `getPlayinfo()` 解析真实播放地址
- 网盘源：播放链接放 `pan`，XPTV 直接调用网盘插件处理，`getPlayinfo()` 返回空 `urls: []`

Guidelines:
- preserve source-specific line names if they exist
- filter out malformed episodes
- if a detail page has no explicit episode list, provide one fallback track pointing to the page itself
- 网盘源使用 `pan` 参数，不要把网盘链接放在 `ext.url` 里

### 5. `getPlayinfo(ext)`

Purpose: convert a track entry into actual playable media URLs.

Typical output (在线播放源):

```javascript
{
  urls: ['https://example.com/video.m3u8'],
  headers: [
    {
      'User-Agent': UA,
      'Referer': SITE + '/'
    }
  ]
}
```

With external subtitles:

```javascript
{
  urls: ['https://example.com/video.m3u8'],
  headers: [
    {
      'User-Agent': UA,
      'Referer': SITE + '/'
    }
  ],
  subtitles: [
    { name: '中文字幕', url: 'https://xx.com/1.srt' },
    { name: 'English', url: 'https://xx.com/1.en.srt' }
  ]
}
```

Typical output (网盘源 — 无需解析，直接返回空):

```javascript
async function getPlayinfo(ext) {
  return jsonify({ urls: [] });
}
```

Guidelines:
- support multiple URLs when available
- return required request headers alongside the URLs
- **网盘源**：track 使用 `pan` 参数时，`getPlayinfo()` 直接返回空 `urls: []`，XPTV 会从 `pan` 参数调用网盘插件
- common extraction sources:
  - direct play URL already present in track `ext.url`
  - iframe `src`
  - JSON-LD `VideoObject.contentUrl`
  - base64 payloads
  - encrypted player config parsed with `createCryptoJS()`
- on failure, return `jsonify({ urls: [] })` rather than crashing

### 6. `search(ext)`

Purpose: search by keyword.

Inputs vary by site. Common fields:

```javascript
{ text: '关键词', wd: '关键词', page: 1 }
```

Guidelines:
- accept either `text` or `wd` when possible
- URL-encode the query with `encodeURIComponent(...)`
- return the same structure as `getCards()`
- match the site's actual search parameter name: `s`, `wd`, `keyword`, etc.

Recommended pattern:

```javascript
async function search(ext) {
  ext = argsify(ext);
  const { text, wd, page = 1 } = ext;
  const keyword = text || wd || '';
  return jsonify({ list: [], page });
}
```

## MacCMS API Recipe

Use when the site exposes a MacCMS XML API at `/api.php/provide/vod/at/xml`.

### Key endpoints

```
List:   ?ac=list&pg={page}&tid={categoryId}
Detail: ?ac=detail&ids={id}
Search: ?ac=list&wd={keyword}&pg={page}
```

### XML parsing key patterns

```javascript
const videoRegex = /<video>([\s\S]*?)<\/video>/g;
const idMatch = block.match(/<id>(\d+)<\/id>/);
const nameMatch = block.match(/<name><!\[CDATA\[(.*?)\]\]><\/name>/);
const picMatch = block.match(/<pic><!\[CDATA\[(.*?)\]\]><\/pic>/);
// Episode lines in <dd flag="播放源名"><![CDATA[剧集列表]]></dd>
const ddRegex = /<dd flag="([^"]+)"><!\[CDATA\[([\s\S]*?)\]\]><\/dd>/g;
// Episodes: name$url pairs joined by #
const items = episodes.split('#').filter(Boolean);
```

### Pitfalls
- CDATA is common; parse carefully with `<!\[CDATA\[(.*?)\]\]>`
- `dd` blocks define playback lines; each `dd` is a separate source/line
- Episodes are `name$url` pairs joined by `#` — split and filter defensively
- Pagination is `pg`, not `page`
- API may return empty XML on rate limit — check `data.length` before parsing
- `getPlayinfo()`: play pages often have direct m3u8 or iframe to player — check both
- `search()` reuses same XML parsing as `getCards()`

## HTML Scraping Recipe

Use this when the site has no reliable API.

### Fetch and parse

```javascript
const { data } = await $fetch.get(url, {
  headers: {
    'User-Agent': UA,
    'Referer': SITE + '/'
  }
});
const cheerio = createCheerio();
const $ = cheerio.load(data);
```

### Card extraction pattern

```javascript
const list = [];
$('article.bs').each((i, el) => {
  const $el = $(el);
  const vodUrl = $el.find('.bsx a').first().attr('href');
  const vodName = $el.find('h2').text().trim();
  if (vodUrl && vodName) {
    list.push({
      vod_id: vodUrl,
      vod_name: vodName,
      vod_pic: $el.find('img').attr('src') || '',
      vod_remarks: $el.find('.epx').first().text().trim() || '',
      ext: { url: vodUrl }
    });
  }
});
```

### WordPress site card pattern

Many resource sites use WordPress with `article.archive-list` class:

```javascript
$('article.archive-list').each((i, el) => {
  const $el = $(el);
  const $titleLink = $el.find('h2.entry-title a').first();
  const vodUrl = $titleLink.attr('href') || '';
  const vodName = $titleLink.text().trim() || '';
  const vodPic = $el.find('figure img').attr('src') || '';
  const remarksRaw = $el.find('.entry-meta').text().trim() || '';
  // Clean remarks: extract update info or category
  const match = remarksRaw.match(/更新至[：:]\\s*(\\S+)/);
  const updateInfo = match ? match[1].trim() : '';
  if (vodUrl && vodName) {
    list.push({
      vod_id: vodUrl,
      vod_name: vodName.replace(/ 迅雷下载$/, '').replace(/ 在线观看$/, ''),
      vod_pic: vodPic,
      vod_remarks: updateInfo,
      ext: { url: vodUrl, id: vodUrl }
    });
  }
});
```

> **封面注意**：列表页 `figure img` 可能来自外部 CDN（如 tututu.wujinyuzhou.top），某些地区/XPTV 版本可能无法加载。在 `getTracks` 中优先用详情页的 `og:image` 获取站内图片作为封面。

### Episode extraction pattern

```javascript
const tracks = [];
$('.eplister a').each((i, el) => {
  const $el = $(el);
  tracks.push({
    name: $el.text().trim(),
    ext: { url: $el.attr('href') }
  });
});
```

### Episode extraction by HTML split (SxxExx pattern)

When episodes are embedded inline in content paragraphs (e.g., "S01E01.1080P | 百度盘 | 迅雷盘"), split by episode marker:

```javascript
const contentHtml = article.html() || '';
const sections = contentHtml.split(/(?=S\d{2}E\d{2})/);

sections.forEach(section => {
  const epMatch = section.match(/(S\d{2}E\d{2})/);
  if (!epMatch) return;
  const epNum = epMatch[1];
  // Extract quality info (decode HTML entities & URL-encoded chars)
  const qualityMatch = section.match(/S\d{2}E\d{2}[.\s]*?([^\s<|]*?(?:P|p)\b|[^\s<|]*?字幕)/);
  const quality = qualityMatch
    ? qualityMatch[1].replace(/&amp.*/, '').replace(/&[^;]+;/, '')
    : '';
  const cleanQuality = quality
    ? '.' + decodeURIComponent(quality).replace(/\s+/g, '')
    : '';

  const $section = cheerio.load('<div>' + section + '</div>')('div');
  // Find download/play links within this section
  // ...

  tracks.push({
    name: epNum + cleanQuality,
    ext: { url: firstLink }
  });
});
```

### Playback extraction techniques

Try these in order:

1. direct playable URL already in `ext.url`
2. iframe `src` → fetch iframe → extract player variable
3. base64 value inside iframe query string
4. inline script JSON / player config
5. JSON-LD `VideoObject.contentUrl`

### Two-step iframe → external player → m3u8 extraction

Many Chinese video sites use this pattern: play page has an iframe pointing to an external player domain (e.g., `meizi.yongfan99.com/content.php?vid=XXX&type=dyttm3u8`), which contains a DPlayer with `var vid="https://...m3u8"`.

```javascript
// Step 1: Extract iframe src from play page
const iframeMatch = data.match(/<iframe[^>]+src=["']([^"']+)["']/i);
if (iframeMatch) {
  let iframeSrc = iframeMatch[1];
  if (iframeSrc.startsWith('/')) {
    iframeSrc = SITE + iframeSrc;
  }

  // Step 2: Fetch iframe content to get real m3u8
  const { data: iframeData } = await $fetch.get(iframeSrc, {
    headers: { 'User-Agent': UA, 'Referer': url }
  });

  // Step 3: Extract m3u8/mp4 from player variable
  const vidMatch = iframeData.match(/var\s+vid\s*=\s*["']([^"']+)["']/);
  if (vidMatch && vidMatch[1]) {
    return jsonify({
      urls: [vidMatch[1]],
      headers: [{ 'User-Agent': UA, 'Referer': iframeSrc }]
    });
  }
}
```

**Key points:**
- Set `Referer` to the play page URL when fetching iframe
- Set `Referer` to the iframe URL in the returned headers for actual playback
- The external player may use `var vid=`, `var url=`, or embed URL in DPlayer config — try all patterns
- Some players encrypt or base64-encode the vid value — decode if it doesn't look like a URL

Example iframe/base64 extraction:

```javascript
function base64Decode(str) {
  try {
    const CryptoJS = createCryptoJS();
    return CryptoJS.enc.Utf8.stringify(CryptoJS.enc.Base64.parse(str));
  } catch (e) {
    return '';
  }
}
```

```javascript
const iframeMatch = data.match(/<iframe[^>]+src=["']([^"']+)["']/i);
if (iframeMatch) {
  const iframeSrc = iframeMatch[1];
  if (iframeSrc.includes('url=')) {
    const encoded = iframeSrc.split('url=')[1].split('&')[0];
    const decoded = base64Decode(encoded);
  }
}
```

### SxxExx episode splitting for inline download pages

Many download sites list episodes inline like:
`S05E01.中英字幕.1080P | 百度盘 | 迅雷盘 | 夸克盘`

Split by episode marker and associate links:

```javascript
const contentHtml = article.html() || '';
const sections = contentHtml.split(/(?=S\d{2}E\d{2})/);

sections.forEach(section => {
  const epMatch = section.match(/(S\d{2}E\d{2})/);
  if (!epMatch) return;
  const epNum = epMatch[1];
  
  const qualityMatch = section.match(/S\d{2}E\d{2}[.\s]*?([^\s<|]*?(?:P|p)\b|[^\s<|]*?字幕)/);
  const quality = qualityMatch
    ? qualityMatch[1].replace(/&amp.*/, '').replace(/&[^;]+;/, '')
    : '';
  const cleanQuality = quality
    ? '.' + decodeURIComponent(quality).replace(/\s+/g, '')
    : '';

  const $section = cheerio.load('<div>' + section + '</div>')('div');
  let firstPan = '';
  
  $section.find('a').each((i, a) => {
    const href = $(a).attr('href') || '';
    if (detectPanType(href) && !firstPan) {
      firstPan = href;
    }
  });

  if (firstPan) {
    tracks.push({
      name: epNum + cleanQuality,
      pan: firstPan,
      ext: {}
    });
  }
});
```

## Debugging Workflow

When a script fails, debug in this order.

### 1. Verify network response

```javascript
console.log('Request URL:', url);
console.log('Response length:', data ? data.length : 0);
```

### 2. Verify selector / parser output

```javascript
console.log('Items found:', $('article.bs').length);
console.log('Episodes found:', $('.eplister a').length);
```

### 3. Return intermediate data temporarily

```javascript
return jsonify({ debug: data });
```

or

```javascript
return jsonify({ debug: parsedObject });
```

### 4. Add try/catch around fragile stages

```javascript
async function getPlayinfo(ext) {
  try {
    ext = argsify(ext);
    const { url } = ext;
    return jsonify({ urls: [url] });
  } catch (error) {
    console.error('getPlayinfo error:', error);
    return jsonify({ urls: [] });
  }
}
```

## XPTV Environment Constraints

XPTV runs in JavaScriptCore (JSC), NOT Node.js. This has critical implications:

### Available globals
XPTV provides these built-in helpers:
- `createCryptoJS()` - returns CryptoJS instance (MD5, AES, enc.Base64, etc.)
- `createCheerio()` - returns cheerio instance for HTML parsing
- `loadJSEncrypt()` - returns JSEncrypt instance for RSA encryption/decryption

```javascript
// RSA encryption example
const JSEncrypt = loadJSEncrypt();
const crypt = new JSEncrypt();
crypt.setPublicKey('-----BEGIN PUBLIC KEY-----\n...\n-----END PUBLIC KEY-----');
const encrypted = crypt.encrypt('plaintext');
```

### No Node.js built-ins

- **No `Buffer`** — use `CryptoJS.enc.Base64.parse(str)` for base64 decode
- **No `atob`/`btoa`** — use `CryptoJS.enc.Base64.stringify()` / `CryptoJS.enc.Base64.parse()`
- **No `require()`** — use global helpers above
- **No `new URL()` / `URLSearchParams`** — use regex string parsing for URL parameters

```javascript
// ❌ Node.js only
function base64Decode(str) {
    return Buffer.from(str, 'base64').toString('utf-8');
}

// ✅ XPTV compatible
function base64Decode(str) {
    const CryptoJS = createCryptoJS();
    return CryptoJS.enc.Utf8.stringify(CryptoJS.enc.Base64.parse(str));
}
```

```javascript
// ❌ Node.js / browser only
const u = new URL(urlStr);
const realUrl = u.searchParams.get('url');

// ✅ XPTV compatible — regex string parsing
function extractParam(urlStr, param) {
  const match = urlStr.match(new RegExp('[?&]' + param + '=([^&]+)'));
  if (match && match[1]) {
    try { return decodeURIComponent(match[1]); } catch (e) { return match[1]; }
  }
  return null;
}
const realUrl = extractParam(urlStr, 'url');
```

### Base64 payload with prefix/suffix

Some API responses wrap base64 JSON data with random prefix and suffix:

```javascript
// ❌ Fragile: substring by fixed offset
let payload = raw.substring(6, raw.length - 2);

// ✅ Robust: regex extract base64 JSON (starts with "ey")
const b64Match = raw.match(/(ey[A-Za-z0-9+/=]+)/);
if (b64Match) {
  const decoded = JSON.parse(base64Decode(b64Match[1]));
}
```

### MD5 for decryption
Many sites use MD5-based URL decryption. Use `CryptoJS.MD5()`:

```javascript
// ❌ Placeholder that doesn't work
function md5X(input) { return 'test'; }

// ✅ Correct
function md5X(input) {
    const CryptoJS = createCryptoJS();
    return CryptoJS.MD5(input).toString();
}
```

## $fetch.post() Parameter Format

**IMPORTANT:** XPTV's `$fetch.post()` takes `(url, body, options)` - 3 arguments.

```javascript
// ❌ WRONG - axios style with options.data
await $fetch.post(url, { data: 'body string', headers: {...} });

// ✅ CORRECT - body as 2nd arg, options as 3rd
await $fetch.post(url, 'body string', {
    headers: { 'Content-Type': 'application/x-www-form-urlencoded', ... }
});
```

When debugging \"parameter error\" or \"vid empty\", check if you used `options.data` format instead of passing body as 2nd argument.

### ✅ Harness Alignment
The xptv-debugger harness `$fetch.post(url, body, options)` now matches the real XPTV 3-parameter signature. Scripts that pass harness tests will behave the same in the real app.

## Custom Decryption Functions (Decode1/Decode2)

Some sites use custom URL encryption. Common pattern in TVBox scripts:

```javascript
// Decode2: character substitution with custom dictionary
function decode2(encoded) {
    const dictStr = 'PXhw7UT1B0a9kQDKZsjIASmOezxYG4CHo5Jyfg2b8FLpEvRr3WtVnlqMidu6cN';
    const lookup = {};
    for (let i = 0; i < dictStr.length; i++) {
        lookup[dictStr[i]] = dictStr[(i + 59) % dictStr.length];
    }
    const raw = base64Decode(encoded);
    let res = '';
    for (let i = 1; i < raw.length; i += 3) {
        res += (lookup[raw[i]] || raw[i]);
    }
    return res;
}

// Decode1: requires MD5 XOR key - use CryptoJS
function md5X(input) {
    const CryptoJS = createCryptoJS();
    return CryptoJS.MD5(input).toString();
}
```

**Pitfall:** Many copied TVBox scripts have placeholder `md5X()` returning `'test'`. Replace with real MD5.

## AES-CBC Encrypted Video URL Pattern

Some sites (especially Korean/Chinese drama sites) encrypt video URLs with AES-CBC and return base64-encoded ciphertext via an API endpoint. Common flow:

1. Detail page has episode IDs (e.g., from `onclick` handlers)
2. Fetch `/api?ud={episodeId}` → returns base64 AES-CBC ciphertext
3. Decrypt with site's static key → get m3u8/mp4 URL
4. Play directly (or pass through a proxy)

### Reverse-engineering the encryption

Use browser DevTools to find:
- The API endpoint (look for `fetch()` or `XMLHttpRequest` calls in the page's JS)
- The encryption key (search for string literals in the site's JS, often a fixed passphrase)
- The encryption mode (AES-CBC with IV embedded in the first 16 bytes of ciphertext is most common)

### AES-CBC decryption with CryptoJS

```javascript
const AES_KEY = 'site-specific-key-here';

async function decryptVideoUrl(encryptedBase64) {
  const CryptoJS = createCryptoJS();
  
  // Key: UTF-8 string padded/truncated to 32 bytes for AES-256
  const keyBytes = CryptoJS.enc.Utf8.parse(AES_KEY.slice(0, 32).padEnd(32, '\0'));
  
  // Ciphertext: base64-decoded, first 16 bytes = IV, rest = ciphertext
  const encryptedBytes = CryptoJS.enc.Base64.parse(encryptedBase64);
  const iv = CryptoJS.lib.WordArray.create(encryptedBytes.words.slice(0, 4), 16);
  const ciphertext = CryptoJS.lib.WordArray.create(
    encryptedBytes.words.slice(4),
    encryptedBytes.sigBytes - 16
  );
  
  const decrypted = CryptoJS.AES.decrypt(
    { ciphertext: ciphertext },
    keyBytes,
    { iv: iv, mode: CryptoJS.mode.CBC, padding: CryptoJS.pad.Pkcs7 }
  );
  
  return decrypted.toString(CryptoJS.enc.Utf8);
}
```

### ⚠️ Pitfall: Trim decrypted URLs

Decrypted URLs often contain trailing `\r\n` (CR/LF). Always trim before using:

```javascript
const cleanUrl = decryptedUrl.trim();  // ← essential!
return jsonify({ urls: [cleanUrl], headers: [...] });
```

Without `.trim()`, the URL may fail to load or trigger unexpected proxy behavior.

### Episode extraction from onclick handlers

Some sites use `onclick="func('id','title',event)"` instead of direct `<a href>` links:

```javascript
$('li a[onclick]').each((i, el) => {
  const $el = $(el);
  const onclick = $el.attr('onclick') || '';
  const name = $el.text().trim();
  const match = onclick.match(/funcName\(\s*['"]([^'"]+)['"]/);
  if (match && name) {
    tracks.push({
      name: name,
      ext: { epId: match[1] }  // extract the ID from onclick
    });
  }
});
```

## Inline Script JSON Extraction

When extracting JSON objects from inline `<script>` tags, don't use `lastIndexOf('}')` when multiple scripts exist:

```javascript
// ❌ BROKEN - picks up } from later scripts
const jsonStr = html.substring(startIdx, html.lastIndexOf('}'));

// ✅ CORRECT - brace counting
let depth = 0, braceEnd = -1;
for (let i = startIdx; i < html.length; i++) {
    if (html[i] === '{') depth++;
    if (html[i] === '}') depth--;
    if (depth === 0) { braceEnd = i; break; }
}
```

## Common Failure Modes

### Empty list from `getCards()`
Check:
- wrong CSS selector
- dynamic loading via API instead of HTML
- missing request headers
- relative URLs not normalized

### `getTracks()` returns nothing
Check:
- episode container selector changed
- detail page requires different headers
- source has only one play button, no episode list

### `getPlayinfo()` returns invalid URL
Check:
- iframe contains encoded payload
- missing `Referer` header
- JSON string needs decode / unescape
- player URL requires decrypting with `createCryptoJS()`
- **$fetch.post() body sent as `options.data` instead of 2nd argument**
- **Decryption function uses placeholder MD5 instead of `CryptoJS.MD5()`**

### `getPlayinfo()` returns "vid empty" or API error
This often means:
- `$fetch.post()` called with wrong signature (body in `options.data` instead of 2nd arg)
- Request headers missing from the POST call
- `encodeURIComponent()` not applied to vid parameter

### Search returns no results
Check:
- wrong query parameter (`s`, `wd`, `keyword`, `text`)
- forgot `encodeURIComponent`
- site uses POST instead of GET
- **Search page HTML differs from list page**: many sites render search results in a different layout than category lists (e.g., `ul.stui-vodlist__media li` for search vs `ul.stui-vodlist li .stui-vodlist__box` for lists). Always inspect the actual search result HTML separately and handle both layouts with a fallback pattern.
- **Site anti-bot protection**: some sites block POST/search from non-browser environments (XPTV JSC). If search works in browser but not in script, note it as a known limitation and return empty results gracefully. The user can still browse via categories.
- **Rate limiting**: some sites return a fake "empty results" page when rate-limited. This looks identical to a real empty result. **Pitfall**: rapid debugging test calls can trigger rate limits, leading to false diagnosis of headers/params issues. Test with ~30s intervals between search requests.

### Pagination broken
- parameter name is `pg`, `page`, or `paged`
- page number belongs in query string vs path

### Images extracted but don't display in XPTV app
If `vod_pic` URLs are correctly extracted (verified in harness) but images don't show in the XPTV app, the image CDN may be blocking requests from XPTV's WebView. Common causes:
- CDN checks `Referer` header and XPTV's image loader doesn't send one
- CDN uses hotlink protection that blocks non-browser user agents
- SSL/TLS certificate issues in XPTV's WebView

**Diagnostic**: Test image URL with `curl -sL -o /dev/null -w '%{http_code}' -H 'User-Agent: Mozilla/5.0' 'IMAGE_URL'`. If it returns 200 but XPTV still can't load it, try:
1. Different CDN from same site
2. Swapping `https` to `http`
3. Using detail page image (`config.video.pic` from DPlayer) as fallback

**Known case**: Some sites use WordPress lazy-loading — `src=\"javascript:;\"` is a placeholder, real image URL is in `data-src` or other lazy attributes. See \"WordPress Lazy-Load Image Extraction\" pattern below for fix.

**Known CDN limitations (tested across multiple sites):**
- `pic.cshsst.cn` (used by heiliao.com, chigua.com): Images return 200 OK from server with any User-Agent/Referer, but DO NOT display in XPTV. Root cause is unclear — not hotlink protection. Likely XPTV WebView SSL/TLS or image loader issue. No script-level fix exists.
- `pic.whlmnc.cn`: alternative CDN domain for some sites, same issues.

**Lesson**: If images work from curl/server but not in XPTV, the issue is XPTV platform-level (WebView image loader), not the script. Accept no thumbnails rather than spending hours debugging.

### Category/Sort URL from navigation returns 404
Some sites have navigation links that don't match actual working URLs — e.g., showing `hot_list-1.htm` in navigation but returning 404, while `list-{page}.htm?sort=hot` works.
**Diagnostic**: Always test category URLs with `curl -o /dev/null -w "%{http_code}"` before finalizing `getConfig()` tabs. If a nav link returns 404, check if the site uses query parameters (`?sort=hot`) or different path patterns instead.
**Pattern**: Many sites use the same list page with sort/filter query params rather than separate category pages. Check for `<a href="list-1.htm?sort=hot">` in the HTML.

## Debugging Nuxt.js / Vue SPA Sites

Many modern sites use Nuxt.js, Vue, React, or other SPA frameworks where content is rendered client-side. Cheerio only sees the server-rendered HTML skeleton, which may be missing actual content.

### Diagnostic checklist

1. Check if `__NUXT__` or `__INITIAL_STATE__` exists in HTML
2. Check if JSON-LD `<script type="application/ld+json">` has image/content data
3. Look for image CDN domains in raw HTML (not in img tags — in JSON, scripts, or inline data)
4. Check `og:image` and `twitter:image` meta tags for fallback images

### Debug script pattern: iterative image discovery

When images aren't displaying, create progressive debug scripts:

1. **v1**: List all `<img>` tag attributes (skip `/static/` placeholders)
2. **v2**: Search raw HTML for CDN domains (e.g., `images.example-cdn.com`)
3. **v3**: Extract JSON-LD `image` fields
4. **v4**: Show CDN domain distribution

### How to find real image CDN from SPA site

```javascript
const allImgs = data.match(/https?:\/\/[^\s"'<>]+\.(?:jpg|jpeg|png|webp)/gi) || [];
const domains = {};
allImgs.forEach(u => {
  const m = u.match(/^https?:\/\/([^/]+)/);
  if (m) domains[m[1]] = (domains[m[1]] || 0) + 1;
});
```

### Known image CDN hotlink issues

- Some CDN domains block XPTV image loader via Referer-based hotlink protection (unsolvable)
- If no alternative CDN exists, images won't display in XPTV


## Quality Checklist Before Shipping

Before finalizing an XPTV script, verify:

- all six interfaces exist
- every return is wrapped with `jsonify()`
- every `ext` input is parsed with `argsify()`
- tab/category IDs line up with `getCards()`
- **圖片方向**：抽樣檢測卡片圖片，若為橫式則在 `getConfig()` 的 tabs 中加入 `ui: 1`
- `getCards()` returns usable `vod_id` and `ext` (only `vod_id`, `vod_name`, `vod_pic` required; `vod_remarks`, `vod_duration`, `vod_pubdate` optional)
- `getTracks()` returns `{ list: [...] }` (no `info` field needed)
- `getTracks()` returns at least one valid line when playable content exists
- **网盘源**：`getTracks()` 使用 `pan` 参数，支持夸克/阿里/115/天翼
- **网盘源**：`getPlayinfo()` 返回空 `urls: []`
- **在线源**：`getPlayinfo()` 返回真实播放 URL、必要 headers，可选 subtitles
- `$fetch.post()` 使用 3 參數格式 `(url, body, {headers})`，不要用 axios 風格
- 解密函數使用 `CryptoJS.MD5()`，不要用 `md5X()` placeholder
- AES 解密後的 URL 有 `.trim()` 去除尾部 CR/LF
- `search()` returns the same card format as `getCards()`
- errors degrade to empty lists/URLs instead of throwing

## Reusable Implementation Template

Use this as a starting point and replace parsing logic per site:

```javascript
const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36';
const SITE = 'https://example.com';

function base64Decode(str) {
  try {
    const CryptoJS = createCryptoJS();
    return CryptoJS.enc.Utf8.stringify(CryptoJS.enc.Base64.parse(str));
  } catch (e) {
    return '';
  }
}

async function getLocalInfo() {
  return jsonify({
    ver: 1,
    name: '示例源',
    api: 'csp_example',
    type: 3
  });
}

async function getConfig() {
  return jsonify({
    ver: 1,
    title: '示例源',
    site: SITE,
    tabs: [
      { name: '全部', ext: { id: 'all' } }
    ]
  });
}

async function getCards(ext) {
  ext = argsify(ext);
  const { id, page = 1 } = ext;
  const list = [];
  return jsonify({ list, page });
}

async function getTracks(ext) {
  ext = argsify(ext);
  const { id, url } = ext;
  return jsonify({
    list: [
      { title: '默认线路', tracks: [] }
    ]
  });
}

async function getPlayinfo(ext) {
  try {
    ext = argsify(ext);
    const { url } = ext;
    return jsonify({
      urls: url ? [url] : [],
      headers: [{ 'User-Agent': UA, 'Referer': SITE + '/' }]
    });
  } catch (error) {
    console.error('getPlayinfo error:', error);
    return jsonify({ urls: [] });
  }
}

async function search(ext) {
  ext = argsify(ext);
  const { text, wd, page = 1 } = ext;
  const keyword = text || wd || '';
  const list = [];
  return jsonify({ list, page });
}
```

## What to do when asked to build a script

**⚠️ Step 0: Check xptv-extensions first!**
Before writing anything, check if an existing script already exists:
```bash
find ~/.xptv-debugger/xptv-extensions -name "*.xptv.js" | grep <source-name>
```
If found, use it as the base. Many scripts were previously written and may just need category/tabs updates. Modify the existing file and sync to `~/.xptv-scripts/`.

**Script storage locations:**
- `~/.xptv-scripts/` — active scripts for XPTV import
- `~/.xptv-debugger/xptv-extensions/` — git-tracked reference scripts (sync changes here too)

1. Inspect the target site and decide: MacCMS API, HTML scraping, or netdisk.
   **⏸ Checkpoint**: Confirm site type with user before proceeding.
2. Detect card image orientation (橫式/直式) — affects `ui: 1` in `getConfig()`.
3. Identify category endpoints or category pages.
4. **⏸ Checkpoint**: Show planned tabs/categories to user, confirm before coding.
5. Build `getLocalInfo()` and `getConfig()` first.
6. Implement `getCards()` → run debugger smoke test → verify cards appear.
7. Implement `getTracks()` → verify episode list populates.
8. Implement `getPlayinfo()` → verify actual playable URL returned.
9. Implement `search()` → verify search returns results (test with ~30s interval).
10. **⏸ Checkpoint**: Run full smoke test (`xptv-debugger smoke <script>`), show results to user for confirmation.
11. Run Quality Checklist (below) before finalizing.
12. Copy to `~/.xptv-scripts/` and sync to `~/.xptv-debugger/xptv-extensions/`.

## TVBox T4/VOD Source Conversion

When converting TVBox scripts to XPTV:

### ⚠️ Prefer iframe over TVBox's internal API resolution

TVBox scripts often do complex internal resolution: fetch player JS → parse API endpoint → POST with encrypted params → decrypt response. This chain frequently fails in XPTV's JSC environment because:
- TVBox uses Node.js APIs (axios, require, Buffer) that don't exist in JSC
- TVBox's API calls may return different responses from JSC (e.g., empty/padded responses)
- Encryption keys or formats may differ

**Better approach:** Extract the player config (e.g., `var player_aaaa={...}`), get the `vid` and `from` fields, then construct the iframe URL directly (e.g., `https://yun.92cj.com/yunbox/?type=vxdev&vid=XXX`). Let XPTV handle iframe playback resolution.

If the site uses encrypt='1' (URL decode) or encrypt='2' (base64 decode), handle those simple cases. But skip the complex multi-step API resolution chain — it's not worth porting.

When converting TVBox T4 (live sports/event) scripts to XPTV:

### Mapping TVBox T4 → XPTV

| TVBox (T4) | XPTV |
|---|---|
| `getClasses()` | `getConfig()` tabs |
| `getCategoryList()` | `getCards(ext)` |
| Detail page → play links | `getTracks(ext)` |
| Play handler (`?play=xxx`) | `getPlayinfo(ext)` |

### Key difference: no detail page for upcoming events

TVBox T4 sources scrape live event lists (sports, etc.). For events that haven't started, there's no playable link and no real detail page — the original TVBox script often sets `vid = siteHost` as fallback.

**Problem:** `getTracks()` receives `detail_url: "http://site.com"` (the homepage) and returns empty list. The smoke test fails with "getTracks returned no track groups".

**Solution — "event not started" fallback pattern:**

```javascript
// getCards: pass remark to ext so getTracks can check status
list.push({
  vod_id: `${vid}###${encodedName}`,
  vod_name: name,
  vod_pic: pic,
  vod_remarks: remark,
  ext: { detail_url: vid, name: name, remark: remark }
});

// getTracks: check if event has started
async function getTracks(ext) {
  ext = argsify(ext);
  const { detail_url, name = '赛事直播', remark } = ext;

  // 比賽尚未開始，沒有播放連結
  if (!detail_url || detail_url === SITE || remark === '暂无') {
    return jsonify({
      list: [{
        title: name,
        tracks: [{ name: '比賽尚未開始', ext: { wait: true } }]
      }]
    });
  }

  // ... normal detail page parsing for started events ...
}

// getPlayinfo: handle wait flag
async function getPlayinfo(ext) {
  ext = argsify(ext);
  const { url, wait = false } = ext;

  if (wait || !url) {
    return jsonify({ urls: [] });
  }

  // ... normal playback extraction ...
}
```

### TVBox base64 payload parsing

Many T4 sources return player data as base64 with front/back padding:

```javascript
// Original TVBox pattern
let data = response.data.data;
data = data.substring(6, data.length - 2);  // strip 6 chars front, 2 back
const decoded = JSON.parse(Buffer.from(data, 'base64').toString());

// XPTV version (no Buffer)
function base64Decode(str) {
  const CryptoJS = createCryptoJS();
  return CryptoJS.enc.Utf8.stringify(CryptoJS.enc.Base64.parse(str));
}
let data = response.data.data;
data = data.substring(6, data.length - 2);
const decoded = JSON.parse(base64Decode(data));
const links = decoded.links || [];
```

### Direct URL vs sniff mode (XPTV JSC — no `new URL()`)

T4 sources often classify links as "direct" (m3u8/flv/ts in URL) vs "sniff" (needs browser sniffing).

**⚠️ XPTV JSC 無 `new URL()` — 必須用正則字串解析：**

```javascript
function extractRealUrl(urlStr) {
  const match = urlStr.match(/[?&](?:url|liveUrl|m3u8)=([^&]+)/);
  if (match && match[1]) {
    try { return decodeURIComponent(match[1]); } catch (e) { return match[1]; }
  }
  return null;
}

const directLinks = [];
const sniffLinks = [];

links.forEach(it => {
  const realUrl = extractRealUrl(it.url);
  if (realUrl && /\.(m3u8|flv|ts)(\?|$)/.test(realUrl)) {
    directLinks.push({ name: it.name, url: realUrl });
  } else {
    sniffLinks.push(it);
  }
});
// Sort: direct first, sniff after
const sortedLinks = [...directLinks, ...sniffLinks];
```

### Filter pattern (對應 TVBox `getFilters()`)

XPTV 使用 `filterList` 常量 + `getCards()` 返回 filter 的方式，對應 TVBox 的 `getFilters()`：

```javascript
// 1. 定義篩選常量（tab id → 篩選陣列）
const filterList = {
  '1': [{ key: 'cateId', name: '類型', value: [
    { n: 'NBA', v: '1' }, { n: 'CBA', v: '2' }, { n: '籃球綜合', v: '4' }
  ]}],
  '8': [{ key: 'cateId', name: '聯賽', value: [
    { n: '英超', v: '8' }, { n: '西甲', v: '9' }, { n: '意甲', v: '10' }
  ]}]
  // id 沒有對應的 filter → 返回空陣列 []
};

// 2. getConfig: tabs 不包含 filter
async function getConfig() {
  return jsonify({
    ver: 1, title: '源標題', site: SITE,
    tabs: [
      { name: '全部', ext: { id: '' } },
      { name: '籃球', ext: { id: '1' } },
      { name: '足球', ext: { id: '8' } }
    ]
  });
}

// 3. getCards: 根據 tab id 返回對應的 filter，並支援使用者篩選
async function getCards(ext) {
  ext = argsify(ext);
  const { id = '' } = ext;
  const cateId = ext.filters?.cateId || id;

  // 用 cateId 構建請求 URL（篩選時覆蓋 tab id）
  const url = SITE + '/api/list?category=' + cateId;
  const { data } = await $fetch.get(url, { headers: HEADERS });
  // ... parse data into list ...

  // 返回 list + 該 tab 對應的 filter
  return jsonify({ list, filter: filterList[cateId] || [], page: 1 });
}
```

**實戰案例：** 體育直播源使用此 pattern，filterList 可包含多個聯賽/分類。getCards 同時接收 tab id 和 `ext.filters.cateId`，用 `cateId` 優先構建請求 URL。

**關鍵規則：**
- `filterList` 是獨立常量，定義在腳本頂部，不是嵌在 `getConfig()` 的 tab 裡
- `getConfig()` 返回純 tab `{ name, ext }`，不含 filter
- `getCards()` 根據 tab 的 `id` 從 `filterList[id]` 取對應的 filter 返回
- 使用者選擇篩選時，`ext.filters.cateId` 會被傳入 `getCards()`，用於覆蓋 tab id 構建請求 URL
- `ext.filters?.cateId || id`：有篩選用篩選值，沒有用 tab 預設 id
- 沒有對應 filter 的 tab（如「全部」）返回空陣列 `filterList[id] || []`

**輸入輸出流程：**
```
getConfig()  →  tabs: [{ name: '籃球', ext: { id: '1' } }]
getCards({id:'1'})  →  { list: [...], filter: filterList['1'] }
getCards({id:'1', filters:{cateId:'2'}})  →  用 cateId='2' 請求，返回 filterList['1']（跟著 tab）
```

## TVBox Pan Search + Douban API Source Conversion

When converting TVBox sources that use Douban API for categories + pan search API for content:

### Pattern: Douban MiniApp API as category source

The Douban MiniApp API (`frodo.douban.com/api/v2`) requires **specific headers** — without them it returns error 997:

```javascript
const DOUBAN_API = 'https://frodo.douban.com/api/v2';
const APIKEY = 'YOUR_DOUBAN_API_KEY_REDACTED';
const doubanHeaders = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/53.0.2785.143 Safari/537.36 MicroMessenger/7.0.9.501 NetType/WIFI MiniProgramEnv/Windows WindowsWechat',
    'Referer': 'https://servicewechat.com/wx2f9b06c1de1ccfca/84/page-frame.html',
    'Host': 'frodo.douban.com'
};
```

**Pitfall**: Standard browser UA returns `{"code": 997}`. Must use WeChat MiniApp UA.

**Verified working headers** (tested with Douban MiniApp API):
```javascript
const DOUBAN_HEADERS = {
  'User-Agent': 'Mozilla/5.0 (iPhone; CPU iPhone OS 16_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148 MicroMessenger/8.0.0(20422342) NetType/WIFI Language/zh_CN',
  'Referer': 'https://servicewechat.com/wx2f9b06c1de1ccfca/84/page-frame.html',
  'Accept': 'application/json'
};
```
This iPhone + WeChat UA works for all Douban endpoints. The simpler `'Host': 'frodo.douban.com'` header is NOT needed.

### Douban API endpoints

| Category | Endpoint | Response key |
|---|---|---|
| 熱門電影 | `/movie/hot_gaia?area=全部&sort=recommend&start=0&count=30` | `items` |
| 熱播劇集 | `/subject_collection/tv_hot/items?start=0&count=30` | `subject_collection_items` |
| 熱播綜藝 | `/subject_collection/show_hot/items?start=0&count=30` | `subject_collection_items` |
| 實時熱門 | `/subject_collection/subject_real_time_hotest/items?start=0&count=30` | `subject_collection_items` |
| 電影篩選 | `/movie/recommend?tags=喜劇,華語&sort=T&start=0&count=30` | `items` |
| 電視篩選 | `/tv/recommend?tags=劇情&sort=T&start=0&count=30` | `items` |
| 榜單 | `/subject_collection/movie_real_time_hotest/items` | `subject_collection_items` |

### Mapping TVBox → XPTV

| TVBox | XPTV |
|---|---|
| `class_name` / `class_url` | `getConfig()` tabs |
| `url` with `fyclass` + `fypage` | `getCards(ext)` using Douban API |
| `panDetailContent(vod, [input])` | `getTracks(ext)` — search pan API directly |
| `panPlay(input, flag)` | `getPlayinfo()` — returns `urls: []` |
| `searchUrl` | `search(ext)` — pan search API |

### Data flow

1. `getCards()` → fetch from Douban API → return cards with `ext: { title, type, douban_id }`
2. `getTracks(ext)` → use `ext.title` to search pan API → group by pan type → return with `pan` param
3. `getPlayinfo()` → return empty (netdisk source)
4. `search()` → search pan API directly → return cards

### Pan search API pattern

```javascript
const SEARCH_API = 'https://so.252035.xyz/api/search';
const url = `${SEARCH_API}?cloud_types=quark,uc,115,aliyun&kw=${encodeURIComponent(keyword)}`;
const { data } = await $fetch.get(url, { headers: { 'User-Agent': UA } });
const json = argsify(data);
// json.data.merged_by_type = { quark: [...], "115": [...], aliyun: [...] }
```

**Pitfall**: Search API `note`/`title` fields may contain HTML tags like `<span class='highlight-keyword'>`. Always strip with `.replace(/<[^>]+>/g, '').trim()`:

```javascript
// ❌ Name contains HTML tags: "1、<span class='highlight-keyword'>庆余年</span>2"
let name = link.note || link.title;

// ✅ Clean: "1、庆余年2"
let name = (link.note || link.title || '未知資源').replace(/<[^>]+>/g, '').replace(/\s+/g, ' ').trim();
```

### Group tracks by pan type for better UX

```javascript
const groups = {};
tracks.forEach(t => {
    const type = detectPanType(t.pan) || '其他';
    if (!groups[type]) groups[type] = [];
    groups[type].push(t);
});
const list = Object.keys(groups).map(type => ({
    title: type + '網盤',
    tracks: groups[type]
}));
```

## Output Expectations

When delivering a finished XPTV script to the user:
- use filename format `[source-name].xptv.js`
- include concise header comments with site URL and source type
- keep constants and helper functions near the top
- prefer readable parsing over overly clever regex chains
- mention any known limitations such as anti-bot protections or selectors likely to change

## Site-Specific Patterns (proven)

### Pattern: `var pp` JSON for multi-line m3u8 (小豬看看 xiaozhukankan)

Some sites embed all playback lines in a JavaScript variable on the detail page:

```javascript
// Detail page HTML contains:
// <script>var pp={"no":"...","la":[["lineId","线路名",1,0,"https://...m3u8"],...]}</script>

const ppMatch = data.match(/var\s+pp\s*=\s*(\{[^;]+\});/);
if (ppMatch) {
  const pp = JSON.parse(ppMatch[1]);
  pp.la.forEach(item => {
    if (Array.isArray(item) && item.length >= 5) {
      tracks.push({
        name: item[1],        // 線路名
        ext: { url: item[4] } // m3u8 URL
      });
    }
  });
}
```

**Key insight**: The `pp.la` array contains `[lineId, lineName, ?, ?, m3u8Url]` tuples. Each tuple is a separate playback line.

### Pattern: DPlayer `config` attribute extraction

Sites using DPlayer often embed the player config as a JSON string in a `config` attribute:

```javascript
// HTML: <div class='dplayer' config='{"video":{"url":"...m3u8...","pic":"...jpg","type":"hls"}}'>

const configRegex = /config='([^']+)'/g;
let match, idx = 1;
while ((match = configRegex.exec(data)) !== null) {
  try {
    const config = JSON.parse(match[1].replace(/\\\//g, '/'));
    const videoUrl = config.video?.url || '';
    if (videoUrl) {
      tracks.push({ name: `视频${idx}`, ext: { url: videoUrl } });
      idx++;
    }
  } catch (e) { }
}
```

**Note**: One article can have multiple DPlayer instances (multiple videos). The regex loop captures all of them.

### Pattern: `var player_aaaa={...}` iframe construction

Many Chinese VOD sites embed player config in a script tag as `var player_aaaa={...}`. Extract `vid`, `url`, `from` fields and construct the iframe URL directly — don't try to replicate TVBox's multi-step API resolution in XPTV.

```javascript
// HTML: <script>var player_aaaa={...}</script>
// or: <script>var player_aaaa={url:"...",from:"...",id:"...",sid:"...",nid:"..."}</script>

const playerMatch = data.match(/var\s+player_aaaa\s*=\s*(\{[^<]+?\})\s*;?\s*<\/script>/);
if (playerMatch) {
  try {
    const player = JSON.parse(playerMatch[1]);
    const vid = player.vid || player.url || '';
    const from = player.from || '';
    if (vid) {
      // Construct iframe URL based on known player domains
      // Common: yun.92cj.com, meizi.yongfan99.com, etc.
      // The site's play page typically has the iframe pattern already
      tracks.push({ name: '播放', ext: { url: playUrl } });
    }
  } catch (e) { }
}
```

**Key insight**: `var player_aaaa` is a TVBox/CatVod convention. In XPTV, the simplest approach is to use the detail page's play link directly (which triggers `getPlayinfo` → iframe resolution). Don't try to reconstruct the TVBox API call chain.

### Pattern: Lazy-loaded image extraction (loadImg)

Some sites use lazy loading with `onload="loadImg(this,'real_url')"`:

```javascript
const imgEl = $el.find('img[onload]');
const onload = imgEl.attr('onload') || '';
const imgMatch = onload.match(/loadImg\([^,]+,'([^']+)'/);
const img = imgMatch ? imgMatch[1] : '';
```

### Pattern: WordPress Lazy-Load Image Extraction

Many WordPress sites use lazy-loading plugins that set `src="javascript:;"` or `src="data:image/gif,..."` as placeholders. The real image URL is stored in other attributes. This causes `vod_pic` to be empty or show placeholder images.

**Problem**: `$('img').attr('src')` returns `javascript:;` — not the real URL.

**Solution**: Try attributes in priority order, skip invalid placeholders:

```javascript
function extractImg($el) {
  const $img = $el.find('img').first();
  if (!$img.length) return '';

  const attrs = [
    'data-lazy-src',   // WP Rocket, a3 Lazy Load
    'data-src',        // Lazy Load by WP Rocket, BJ Lazy Load
    'data-original',   // jQuery Lazy Load
    'data-lazy',       // WP Fastest Cache
    'data-bg',         // background-image lazy load
    'data-srcset',     // responsive lazy srcset
    'data-thumb',      // thumbnail lazy load
    'data-poster',     // video poster lazy load
    'data-image',      // generic
    'data-lazy-srcset',// WP native lazy
    'src'              // last resort
  ];

  for (const attr of attrs) {
    let val = $img.attr(attr) || '';
    if (!val || val === 'javascript:;' || val.startsWith('data:') ||
        val.includes('loading.gif') || val.length < 10) continue;
    // srcset format: "url1 1x, url2 2x" — take first URL
    if (attr.includes('srcset')) {
      val = val.split(',')[0].trim().split(/\s+/)[0];
    }
    if (val.startsWith('//')) val = 'https:' + val;
    if (val.startsWith('http') || val.startsWith('/')) return val;
  }

  // Fallback: extract from background-image style
  const $bg = $el.find('[style*="background"]').first();
  if ($bg.length) {
    const style = $bg.attr('style') || '';
    const m = style.match(/url\(['"]?([^'")\s]+)/);
    if (m && m[1] && !m[1].startsWith('data:')) {
      let url = m[1];
      if (url.startsWith('//')) url = 'https:' + url;
      return url;
    }
  }

  return '';
}
```

**How to detect lazy-load attributes**: If you can't access the site from the server (anti-bot), ask the user to:
1. Open a page in their browser
2. Long-press/right-click a thumbnail → "Copy image link"
3. If it returns `javascript:;`, the site uses lazy-loading
4. Then ask them to inspect the `<img>` tag to find which attribute holds the real URL

**Why priority order matters**: Different WP plugins use different attributes. `data-lazy-src` (WP Rocket) is most common, then `data-src`, then `data-original`. Always try the most common first.

### Pattern: Ad filtering on mixed content pages

Sites with ads mix real content and ad items in the same list. Filter ads by:
- Class: `tjtagmanager`, `ad_click`
- Attribute: `data-event="ad_click"`, `target="_blank"` (with external href)
- External URLs: href not matching internal pattern

```javascript
$('a.cursor-pointer').each((i, el) => {
  const $el = $(el);
  if ($el.hasClass('tjtagmanager') || $el.attr('target') === '_blank') return;
  const href = $el.attr('href') || '';
  if (!/\/archives\/\d+\//.test(href)) return;  // only internal article links
  // ... extract card data
});
```

### Pattern: Tag-based search fallback

When a site's search page requires JS rendering (SPA), use tag pages as fallback:

```javascript
// Search page is SPA (Vue/React) — results loaded via JS, not SSR
// But tag pages are SSR: /tag/{keyword}/ returns rendered HTML with same card structure

const url = `${SITE}/tag/${encodeURIComponent(keyword)}/`;
const { data } = await $fetch.get(url, { headers });
// Parse same way as category list
```

**When to use**: Check if `curl` returns search results. If the search page HTML has only hot searches/tags but no actual results, the search is JS-rendered. Look for tag pages (`/tag/xxx/`) as a server-rendered alternative.

### Pattern: SPA / SSR Framework Detection (Nuxt.js, Next.js, Vue SSR)

Some sites use SPA frameworks (Nuxt.js, Next.js, Vue SSR) where the initial HTML is a skeleton with placeholders — real content is loaded client-side via JavaScript. Cheerio only sees the skeleton, so `getCards()` returns empty or placeholder data.

**How to detect:**
1. Look for `nuxt-link`, `__nuxt`, `__next`, `data-v-` attributes in HTML
2. All `<img>` tags have `src="/static/..."` or `src="javascript:;"` placeholders
3. Page title and article links exist, but content data (images, descriptions) is missing
4. `window.__NUXT__` or `window.__NUXT_DATA__` may be embedded (but not always)

**Detection heuristic:**
```javascript
const isSPA = data.includes('nuxt-link') || data.includes('__NUXT__') || 
              data.includes('__NEXT_DATA__') || data.includes('data-v-');
const hasPlaceholders = (data.match(/src="\/static\//g) || []).length > 5;
```

**Resolution strategies (try in order):**

1. **Parse `__NUXT__` embedded data** — Some Nuxt SSR pages embed initial state:
```javascript
const nuxtMatch = data.match(/window\.__NUXT__\s*=\s*([\s\S]*?);?\s*<\/script>/);
if (nuxtMatch) { /* parse embedded article list, images */ }
```

2. **Find the API endpoint** — SPA apps fetch data from an API. Search for API patterns:
```javascript
const apiPaths = data.match(/['"](\/api\/[^'"]+)['"]/g) || [];
const fetchUrls = data.match(/fetch\(['"]([^'"]+)['"]/g) || [];
```
Then call the API directly from `getCards()`.

3. **Use tag pages as fallback** — Some sites have SSR-rendered tag pages (`/tag/keyword/`).

4. **Extract from detail page** — Even if list page is SPA, the detail page may have real data (og:image meta tags, DPlayer config). Use `getTracks()` to extract video URLs and `og:image` for thumbnails.

**Lesson**: Some sites serve different HTML from different domains — the main domain may be a redirect to a SPA shell, while a CDN domain serves SSR-rendered pages with real content. If the main domain returns empty, try finding the actual content-serving domain.

**Debug strategy for unknown SPA sites:**
Create a debug version of `getCards()` that outputs script tag analysis, API path scans, and img attribute dumps as `vod_name` so the user can see results directly in XPTV.

### SPA API Discovery Workflow (Systematic Debugging)

When a SPA site's `getCards()` returns empty, use this systematic approach to find the data source:

**Phase 1: Confirm SPA nature (debug v1–v3)**
1. Dump all `<img>` tag attributes — if all show `/static/` or `javascript:;`, it's a SPA
2. Search raw HTML for CDN domains — images may be in raw HTML but not in img tags
3. Check for `nuxt-link`, `__NUXT__`, `data-server-rendered` markers

**Phase 2: Find image sources (debug v4–v10)**
1. Search raw HTML for image URL patterns (`https?://...jpg`)
2. Count CDN domains to find the real image host
3. Test image URLs for hotlink protection (check if `og:image` loads but content images don't)

**Phase 3: Analyze page structure (debug v11–v15)**
1. Search for `__NUXT__`, `__INITIAL_STATE__`, `__NUXT_DATA__` in script tags
2. Count link href patterns — if only navigation links exist (no article links), data is loaded via API
3. Dump all `<a href>` values to confirm page structure

**Phase 4: Find API endpoint (debug v16–v18)**
1. Scan common REST API paths: `/api/v1/list`, `/api/v1/articles`, `/api/posts`, etc.
2. Test both GET and POST methods
3. Test with and without query parameters
4. Once found, analyze JSON response structure to extract article data

**Phase 5: Build production script**
Use the discovered API endpoint in `getCards()`. Parse the JSON response to extract article data (title, image, ID, URL). Use DPlayer/iframe extraction for `getTracks()`.

### Pattern: Sort via query parameter instead of separate category page

Some sites use the same list page with sort/filter query params:

```javascript
// ❌ hot_list-1.htm returns 404
// ✅ list-1.htm?sort=hot works

async function getCards(ext) {
  const { id, page = 1 } = ext;
  let url;
  if (id === 'hot') {
    url = `${SITE}/list-${page}.htm?sort=hot`;
  } else {
    url = `${SITE}/${id}-${page}.htm`;
  }
  // ...
}
```

**Diagnostic**: Always test category URLs with curl HTTP status check before finalizing. If a nav link returns 404, check for `?sort=` or `?filter=` query parameters in the page's tab links.

### Pattern: Images in JavaScript function calls

Some sites embed image URLs inside JavaScript function calls in inline `<script>` tags rather than in `<img>` tag attributes. Common functions include `loadBannerDirect()`, `loadBanner()`, `loadImage()`, `showPic()`, `setBackground()`, etc.

**Example (chigua.com):**
```html
<article>
  <a href="/archives/12345/">
    <div class="post-card">
      <script>loadBannerDirect('https://pic.cshsst.cn/upload_01/xiao/20260414/image.jpeg')</script>
    </div>
  </a>
</article>
```

**Extraction pattern:**
```javascript
function parseArticles(html) {
  const list = [];
  const seen = new Set();

  // Iterate <article> blocks to pair ID + image + title correctly
  const articleRegex = /<article[\s\S]*?<\/article>/gi;
  let match;
  while ((match = articleRegex.exec(html)) !== null) {
    const block = match[0];

    // ID from meta tag or archive link
    const idMatch = block.match(/content="\/archives\/(\d+)\//) ||
                    block.match(/href="\/archives\/(\d+)\//);
    if (!idMatch) continue;
    const vid = idMatch[1];
    if (seen.has(vid)) continue;
    seen.add(vid);

    // Image from JavaScript function call
    const imgMatch = block.match(/loadBannerDirect\(['"]([^'"]+)/);
    const img = imgMatch ? imgMatch[1] : '';

    // Title from heading element
    const hMatch = block.match(/<h[1-5][^>]*>([^<]{4,})<\/h[1-5]>/);
    const title = hMatch ? hMatch[1].trim() : '';

    if (title) {
      list.push({
        vod_id: vid,
        vod_name: title,
        vod_pic: img,
        ext: { url: `/archives/${vid}/` }
      });
    }
  }
  return list;
}
```

**Key insight**: The `<article>` container is essential for pairing — separate regex on `<meta>` tags and `loadBannerDirect()` calls won't match up correctly because navigation elements also have `<meta>` tags with archive IDs.

### Pattern: CDN domain differs from main domain

Some sites serve content through a CDN (CloudFront, Cloudflare, etc.) while the main domain is a redirect or SPA shell. The actual server-rendered content with articles and links is on the CDN domain.

**Example (heiliao.com → CloudFront):**
- Main domain: `https://heiliao.com` → returns SPA shell (Nuxt.js), no article data
- CDN domain: `https://d1bkj2yip30514.cloudfront.net` → returns SSR content with article links

**How to discover:** Ask the user for the actual site URL from their browser, check `link[rel="canonical"]`, or look for CDN URLs in the HTML.

**Solution**: Use the CDN domain as `SITE` instead of the main domain.

### Pattern: Anti-bot returning different HTML on subsequent requests

Some sites return different HTML based on request patterns — first request gets full content, subsequent requests get stripped/empty HTML. This is a form of rate limiting or anti-scraping.

**Symptoms:**
- First `$fetch.get()` returns rich HTML, second returns stripped HTML
- Debug script works once, then stops finding data

**Solution**: Include all standard browser headers:
```javascript
const headers = {
  'User-Agent': UA,
  'Referer': `${SITE}/`,
  'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
  'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8',
  'Accept-Encoding': 'identity',
};
```

## Audio/Radio Source Patterns

When writing XPTV scripts for audio-only platforms (podcasts, radio stations, FM apps), several unique challenges arise:

### API Hard Limits

Many audio APIs cap items per request (e.g., max 200 items). If the API doesn't support deeper pagination:

1. **Test all parameters**: Try `sort`, `lastId`, `maxId`, `endTime`, `phId` — most won't work, but occasionally one unlocks more data.
2. **Measure the real limit**: Request with large `c` values and increasing `i` offsets to find the exact ceiling.
3. **Accept the limit**: If truly hard-capped, document it and load the maximum possible per request (`c=200`).

### Historical Content via URL Construction

If audio URLs follow a predictable pattern (e.g., `https://cdn.com/code/YYYYMMDD/code_YYYYMMDD_suffix.m4a`), you can generate entries for dates the API doesn't return.

**Workflow:**
1. Extract the URL pattern from API-returned items
2. Verify the pattern by testing HEAD requests across different dates
3. **CDN retention varies by channel** — test broadly:
   - Some channels retain URLs for years (safe to generate 3 years back)
   - Others expire in ~3 weeks (only generate ~30 days)
4. Deduplicate: use a `seenIds` map to skip dates already returned by the API
5. Use channel-specific metadata (name, code, suffix, time) to construct URLs

```javascript
// Example: generate historical URLs for a channel with known pattern
const ch = CHANNELS.find(c => c.id === brandId);
const today = new Date();
const daysBack = ch.longRetention ? 1095 : 30; // years vs weeks
for (let d = 1; d <= daysBack; d++) {
  const dt = new Date(today);
  dt.setDate(dt.getDate() - d);
  const dateStr = dt.toISOString().slice(0, 10).replace(/-/g, '');
  const genId = ch.id + '_' + dateStr;
  if (seenIds[genId]) continue;
  const audioUrl = `https://cdn.com/c_${ch.code}/${dateStr}/${ch.code}_${dateStr}_${ch.suffix}.m4a`;
  list.push({
    vod_id: genId,
    vod_name: `${dateStr.slice(0,4)}-${dateStr.slice(4,6)}-${dateStr.slice(6,8)} ${ch.name}`,
    vod_pic: ch.icon || '',
    vod_remarks: `${dateStr.slice(0,4)}-${dateStr.slice(4,6)}-${dateStr.slice(6,8)}`,
    ext: { audioUrl, brandId }
  });
}
```

### Thumbnail Handling for Audio Sources

Audio sources have no video thumbnails. Options:

1. **Channel icon**: Use each channel's brand image — but resizing large photos to tiny thumbnails produces blur.
2. **Data URI solid color blocks**: Best option for clarity at any size. Generate small (12x12) PNGs as data URIs with distinct colors per channel:

```javascript
// Generate programmatically, then embed:
// Channel A: red (#ff6b6b), Channel B: teal (#4ecdc4), etc.
const CHANNELS = [
  { id: 'ch1', name: '频道A', icon: 'data:image/png;base64,iVBORw0KGgo...' },
  { id: 'ch2', name: '频道B', icon: 'data:image/png;base64,iVBORw0KGgo...' },
];
```

**Why data URIs work best:**
- Zero external HTTP requests
- Always sharp (solid colors at any scale)
- ~130 chars per icon (79 bytes PNG → ~130 chars base64)
- Universal compatibility (no CDN, no hotlink issues)

3. **Aliyun OSS processing**: If you must use real images, Aliyun OSS supports inline resize:
```
https://img.example.com/photo.jpg?x-oss-process=image/resize,w_25/format,webp
```
- `w_25/format,webp` → ~278 bytes, decent clarity at small sizes
- Below `w_25` images become too blurry for photos

### Pagination for Audio Sources

Audio platforms often have fewer items than video sites. Use larger page sizes:
- `pageSize = 100` instead of 20
- This loads more items per page, reducing pagination overhead
- Combine with URL generation on page 1 to maximize visible content

### Audio URL Verification

Before shipping, verify constructed URLs with HEAD requests:
```bash
curl -sI -H 'Referer: https://site.com/' 'https://cdn.com/c_CODE/20240101/...'
```
- 200 = accessible
- 403 = expired/retention-limited (don't generate for that date range)
- Track which date ranges work vs which don't per channel

### CDN Retention Testing Pattern (ajmide.com example)

When discovering URL patterns for historical content generation, test retention windows systematically:

1. **Sample broadly**: Test dates across years (2023-2026) with parallel HEAD requests
2. **Per-channel variation**: Different channels on the same platform may have completely different retention windows:
   - Channel A: 3+ years retention (generate full history)
   - Channel B: ~3 weeks retention (only generate recent)
3. **Test consecutive dates**: A channel that works for sampled monthly dates might also work for consecutive daily dates — verify with a full month test
4. **Thread pool for speed**: Use concurrent requests (20 workers) to test 50+ dates in seconds

```python
from concurrent.futures import ThreadPoolExecutor
def check_url(date_str):
    url = f'https://cdn.com/c_{code}/{date_str}/{code}_{date_str}_{suffix}.m4a'
    r = requests.head(url, headers=headers, timeout=5, allow_redirects=True)
    return (date_str, r.status_code)
with ThreadPoolExecutor(max_workers=20) as ex:
    results = list(ex.map(check_url, test_dates))
ok = [d for d, s in results if s == 200]
```

### XPTV Image Loading Limitations (critical finding)

Through extensive testing with audio source scripts, discovered that XPTV's image loader has strict format requirements:

**What DOESN'T work for `vod_pic`:**
- ❌ `data:image/png;base64,...` (base64 data URIs) — image won't display
- ❌ `data:image/svg+xml,...` (SVG data URIs) — image won't display
- ❌ Local file paths like `~/.xptv-scripts/icon.png` — image won't display (unless XPTV runs on the same machine and has filesystem access, which is unreliable)
- ❌ Very small images (w < 25px) from photo sources become too blurry to read

**What DOES work:**
- ✅ HTTP/HTTPS URLs to publicly accessible image files
- ✅ Aliyun OSS processing: `https://img.example.com/photo.jpg?x-oss-process=image/resize,w_25/format,webp`
- ✅ Empty string `vod_pic: ''` — XPTV shows a default placeholder

**Workaround for custom channel icons:**
If you need custom icons (e.g., for audio sources with no meaningful thumbnails):
1. Host PNG files on a public server/CDN and reference by URL
2. Or accept the default placeholder (`vod_pic: ''`)
3. Or use the original API images with OSS resize for acceptable small-size clarity
4. Aliyun OSS `w_25/format,webp` (~278 bytes) is the practical minimum for photo content to remain readable at thumbnail size

**Note**: This is a platform-level limitation of XPTV's WebView image loader, not a script issue. If images work from curl/server but not in XPTV, accept the limitation rather than spending hours debugging.

## Case Study: kisskh.do Angular SPA Reverse-Engineering via Archive.org

**Site:** https://kisskh.do (Korean drama / anime streaming)

**Challenge:** Site is behind Cloudflare protection — all API calls return 403 Forbidden from servers. SSL certificate errors prevent direct browser access. Multiple domain variants (kisskh.co, kisskh.org, kisskh.me, kisskh.vip) all resolve to the same proxy infrastructure (198.18.4.x range) with identical protection.

**Discovery process:**

1. **DNS investigation**: All kisskh domains resolve to 198.18.4.56-59 — same proxy cluster
2. **Archive.org fallback**: Used `https://web.archive.org/web/2025/https://kisskh.do/` to access cached site
3. **Framework detection**: Site is Angular SPA (main.c582432abad915cc.js, runtime, polyfills)
4. **JS bundle analysis**: Downloaded minified main.js (~1.2MB) from archive.org

**Extracting API endpoints from Angular bundle:**

```python
# Pattern: g.N.baseUrl + "DramaList/Show"
# g.N.baseUrl is defined as "/api/" in environment config

import re

# Find all methods using baseUrl
method_pattern = re.compile(
    r'\{key:"(\w+)",value:function[^{]*\{[^}]*this\.httpClient\.\w+\(g\.N\.baseUrl\+"([^"]+)"'
)
methods = method_pattern.findall(js)
# Returns: GetDramaShow -> DramaList/Show, GetDramaLastUpdate -> DramaList/LastUpdate?ispc=, etc.
```

**Discovered API endpoints (all under `/api/DramaList/`):**

| Method | Endpoint | Purpose |
|--------|----------|---------|
| `GetDramaShow` | `DramaList/Show` | Browse dramas |
| `GetDramaLastUpdate` | `DramaList/LastUpdate?ispc=` | Recently updated |
| `GetUpcomingDrama` | `DramaList/Upcoming?ispc=` | Upcoming releases |
| `GetMostSearch` | `DramaList/MostSearch?ispc=` | Popular searches |
| `GetTopRating` | `DramaList/TopRating?ispc=` | Top rated |
| `GetSearch` | `DramaList/Search?q={keyword}&type={type}` | Search |
| `GetDramaDetail` | `DramaList/Drama/{id}?isq={bool}` | Drama details + episodes |
| `GetEpisode` | `DramaList/Episode/{id}.png?err=&ts=&time=&kkey=` | Play URL (obfuscated) |
| `GetAnimate` | `DramaList/Animate?ispc=` | Anime list |
| `GetSub` | `Sub/{id}` | Subtitles |

**Key findings:**
- API base URL: `/api/` (relative to domain)
- Episode endpoint uses `.png` extension with query params for obfuscation
- `kkey` parameter suggests signed/encrypted requests needed
- Pagination via `?page={n}` query parameter
- `ispc` parameter appears to be a boolean flag (likely "is PC" vs mobile)

**Why direct API calls fail:**
- Cloudflare Turnstile challenge protection
- SSL certificate invalid (proxy intercepts HTTPS)
- API requires browser cookies/session from Cloudflare challenge

**Script approach:**
Since API is protected, wrote script with defensive multi-field parsing (handles various JSON key naming conventions) and graceful fallbacks. Script will work if user's XPTV app can bypass Cloudflare (e.g., shares browser cookies).

### Reusable Pattern: Archive.org + Angular Bundle Analysis

**When to use:** Site is behind anti-bot protection (Cloudflare, etc.) but has been archived.

**Steps:**
1. Check archive.org CDX API: `http://web.archive.org/cdx/search/cdx?url=DOMAIN/*&output=json&limit=100`
2. Find the main JS bundle URL in archived HTML (look for `main.*.js`)
3. Download bundle from `https://web.archive.org/web/TIMESTAMPjs_/https://DOMAIN/main.BUNDLE.js`
4. Search for API patterns:
   - Angular: `g.N.baseUrl + "Endpoint"` or `this.httpClient.get(baseUrl + "...")`
   - React: `fetch("/api/...")` or `axios.get("/api/...")`
   - Vue: `this.$http.get(...)` or `axios({url: "..."})`
5. Map methods to XPTV interfaces

**Regex patterns for common Angular HTTP calls:**
```python
# GET requests
get_pattern = r'this\.httpClient\.get\([^)]*baseUrl[^)]*"([^"]+)"'
# POST requests  
post_pattern = r'this\.httpClient\.post\([^)]*baseUrl[^)]*"([^"]+)"'
# Method name mapping
method_pattern = r'\{key:"(\w+)",value:function'
```

**Pitfalls:**
- Archive.org may return HTML wrapper instead of raw JS — use `js_` timestamp prefix
- Minified code has variable mangling — search for string literals, not variable names
- Some sites use dynamic API base URLs loaded from config endpoints — check environment files
- Cloudflare-protected sites may not work from XPTV even with correct API structure

---

## Case Study: radio.cn (雲聽) API Discovery

**Site:** https://www.radio.cn (中央广播电视总台 雲聽)

**Challenge:** The page uses dynamic JavaScript loading. The visible `tacc.radio.cn` API in the source code is commented out and inaccessible from servers (connection closed). Needed to find the actual working API endpoint.

**Discovery process:**

1. Navigated to the radio.cn channel page in browser (e.g., `zhibo_2.html?channelname=648&name=1453129`)
2. Found that recordings loaded via `getPageByColumn()` function calling an API object
3. Intercepted actual network requests using browser console:
```javascript
const allXhr = performance.getEntriesByType('resource').filter(r =>
  r.name.includes('radio.cn') && (r.name.includes('api') || r.name.includes('page') || r.name.includes('column'))
).map(r => r.name);
// Returns: https://ytmsout.radio.cn/web/appProgram/pageByColumn?pageNo=0&columnId=1453129&pageSize=20
```

**Working API:**
```
GET https://ytmsout.radio.cn/web/appProgram/pageByColumn?pageNo={page}&columnId={columnId}&pageSize={size}
```

- `columnId` = the `name` parameter from the radio.cn page URL (NOT `channelname`)
- `pageNo` = 0-indexed page number
- `pageSize` = items per page (20 standard)

**Response structure:**
```json
{
  "code": 0,
  "message": "SUCCESS",
  "data": {
    "pageNo": 0,
    "pageSize": 20,
    "totalNum": 336,
    "totalPage": 17,
    "data": [{
      "id": "978598414",
      "columnId": "1453129",
      "name": "笑声编辑部",
      "durationStr": "60:00",
      "programDate": 1776182400000,
      "playUrlHigh": "https://ytrecordbroadcast.radio.cn/echo/2/XXXX.m4a?e=0&ps=1&r=1",
      "playUrlLow": "https://ytrecordbroadcast.radio.cn/echo/2/XXXX.m4a?e=0&ps=1&r=3",
      "downloadUrl": "..."
    }]
  }
}
```

**Key fields for XPTV:**
- `playUrlHigh` = best quality audio URL (m4a format, direct play)
- `playUrlLow` = lower quality fallback
- `programDate` = timestamp (convert with `new Date(ts).toISOString().split('T')[0]`)
- `durationStr` = human-readable duration
- `name` = program name (same for all recordings in a channel)

**Known channels:**
| Channel | columnId | Program Name |
|---------|----------|-------------|
| 648 | 1453129 | 笑声编辑部 |
| 649 | 1396377 | 笑口常开 |

**URL pattern:** Pages use `zhibo_2.html?channelname={channelNum}&name={columnId}&title=radio`

**Headers:** Standard browser UA works. Referer: `https://www.radio.cn/`

**Note:** The `tacc.radio.cn` domain is inaccessible from most servers (connection closed). Only the `ytmsout.radio.cn` endpoint works. Audio is served from `ytrecordbroadcast.radio.cn` CDN.

---

## Case Study: kisskh.ws AES Token Encryption

**Site:** https://kisskh.ws (Korean drama / anime streaming)

**Challenge:** The site uses AES-128-CBC encrypted tokens for video playback API access. The token generation requires a specific hash function and encryption process.

**Discovery process:**

1. **Reference script analysis**: User provided Python decryption script with complete token generation logic
2. **Hash function porting**: JavaScript hash function must exactly match Python's 32-bit signed integer behavior
3. **AES encryption**: Token uses AES-128-CBC with PKCS7 padding, hex output

**Token generation algorithm:**

```javascript
// Constants
const VID_TOKEN = '62f176f3bb1b5b8e70e39932ad34a0c7';
const APP_ID = 'mg3c3b04ba';
const APP_VERSION = '2.8.10';
const AES_KEY = '4F6BDAA39E2F8CB07F5E722D9EDEF314';
const AES_IV = '01504AF356E619CF2E42BBA68C3F70F9';

// Hash function (must match Python exactly)
function hashFunc(str) {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    const charCode = str.charCodeAt(i);
    let int32Hash = hash & 0xFFFFFFFF;
    if (int32Hash > 0x7FFFFFFF) {
      int32Hash -= 0x100000000;
    }
    let shifted = (int32Hash << 5) & 0xFFFFFFFF;
    if (shifted > 0x7FFFFFFF) {
      shifted -= 0x100000000;
    }
    hash = shifted - hash + charCode;
  }
  return hash;
}

// Token generation
function generateToken(episodeId) {
  const CryptoJS = createCryptoJS();
  
  // Build payload array
  const payloadArr = ['', String(episodeId), '', APP_ID, APP_VERSION, VID_TOKEN, '4830201', 'kisskh', 'kisskh', 'kisskh', 'kisskh', 'kisskh', 'kisskh', '00', ''];
  
  // Join with | and hash
  const joined = payloadArr.join('|');
  const hashValue = hashFunc(joined);
  
  // Insert hash at position 1
  payloadArr.splice(1, 0, String(hashValue));
  const finalPayload = payloadArr.join('|');
  
  // AES-128-CBC encryption with PKCS7 padding
  const key = CryptoJS.enc.Hex.parse(AES_KEY);
  const iv = CryptoJS.enc.Hex.parse(AES_IV);
  const encrypted = CryptoJS.AES.encrypt(finalPayload, key, {
    iv: iv,
    mode: CryptoJS.mode.CBC,
    padding: CryptoJS.pad.Pkcs7
  });
  
  // Return hex uppercase token
  return encrypted.ciphertext.toString(CryptoJS.enc.Hex).toUpperCase();
}
```

**API endpoint with token:**
```javascript
// Episode playback URL
const url = `${API}/Episode/${epId}.png?err=false&ts=null&time=null&kkey=${token}`;
```

**Key findings:**
1. Hash function must exactly match Python's 32-bit signed integer behavior
2. API uses `ts=null&time=null` (not timestamps)
3. Token is AES-128-CBC encrypted, hex uppercase
4. Site is behind Cloudflare protection - may not be accessible from all networks

**Subtitle support:**
The site provides CC subtitles via a separate API endpoint that uses the SAME kkey token as the video API:

```javascript
// Subtitle API endpoint - uses same token as video API
const subUrl = `${API}/Sub/${epId}?kkey=${token}`;
```

**Key discovery (from browser DevTools):**
- Subtitle API format: `/api/Sub/{episodeId}?kkey={token}`
- Subtitle CDN: `sub.cdnvideo11.shop`
- Language code embedded in URL filename: `.en.srt`, `.zh.srt`, etc.

**Example subtitle URL:**
```
https://sub.cdnvideo11.shop/auto-upload/11923/1/2554402f9e051959cf0c643dfcf9a03b.en.srt?v=e76ca4d3-66e5-4d5f-8fcf-3c3b2c341171
```

**Complete getPlayinfo with subtitles:**
```javascript
async function getPlayinfo(ext) {
  ext = argsify(ext);
  const { epId } = ext;
  
  // Generate token (same for video and subtitles)
  const token = generateToken(epId);
  
  // Get video URL
  const videoUrl = `${API}/Episode/${epId}.png?err=false&ts=null&time=null&kkey=${token}`;
  // ... fetch and parse video URL ...
  
  // Get subtitles using SAME token
  let subtitles = [];
  try {
    const subUrl = `${API}/Sub/${epId}?kkey=${token}`;
    const { data: subData } = await $fetch.get(subUrl, { headers: HEADERS });
    const subResult = argsify(subData);
    
    // Subtitle API returns array of URL strings
    if (Array.isArray(subResult)) {
      subResult.forEach((sub, index) => {
        if (typeof sub === 'string' && sub) {
          // Extract language from URL filename (e.g., .en.srt -> EN)
          const langMatch = sub.match(/\.([a-z]{2})\.(srt|vtt)/i);
          const lang = langMatch ? langMatch[1].toUpperCase() : `字幕${index + 1}`;
          subtitles.push({ name: lang, url: sub });
        }
      });
    }
  } catch (e) {
    // Subtitle fetch failure doesn't affect playback
  }
  
  // Return video URL with optional subtitles
  if (videoUrl) {
    const response = {
      urls: [videoUrl],
      headers: [{ 'User-Agent': UA, 'Referer': SITE + '/' }]
    };
    if (subtitles.length > 0) {
      response.subtitles = subtitles;
    }
    return jsonify(response);
  }
}
```

**Pitfalls:**
- Initial hash function implementation gave wrong results - must match Python exactly
- Using timestamps instead of `null` for `ts` and `time` parameters
- VID_TOKEN constant must be complete, not truncated
- Cloudflare protection may block server-side requests but work from user's XPTV app
- Subtitle API is optional - script should work even if subtitles are unavailable

**Testing results:**
- Script structure is correct
- Site inaccessible from server due to Cloudflare
- Token generation verified to match Python reference
- Subtitle endpoint discovered: `/api/Sub/{episodeId}`

## Case Study: MacCMS CAPTCHA-Protected Search (lmm85.com)

**Site:** https://www.lmm85.com (路漫漫在線動漫, anime streaming)

**Challenge:** Search page is protected by MacCMS PHP session-based CAPTCHA. Category browsing works fine, but `/vod/search.html?wd=keyword` returns a verification page instead of results.

### MacCMS CAPTCHA verification mechanism

**Flow:**
1. GET `/index.php/verify/index.html?r={random}` → returns CAPTCHA image (PNG) + sets `PHPSESSID` cookie
2. User reads 4-digit number from image
3. POST `/index.php/ajax/verify_check?type=search&verify={code}` → returns `{code:1, msg:"验证通过"}` or `{code:1002, msg:"验证码错误"}`
4. On success, the session is marked verified; all subsequent requests with same `PHPSESSID` skip the CAPTCHA
5. Re-navigate to search page → results appear normally

**Key detail:** Verification is session-bound. Once verified, the `PHPSESSID` cookie carries the "verified" flag for the entire session lifetime. No re-verification needed for subsequent searches.

### CAPTCHA characteristics

- **Format:** 4-digit number (0-9), handwritten style with distortion
- **Image:** Indexed PNG (color_type=3, bit_depth=4), ~128x40 pixels, ~400-600 bytes
- **Palette:** 9 colors — background is light (RGB ~243,251,254), text uses multiple shades of red/dark color (RGB ~115,20,18 to ~195,164,165)
- **Anti-aliasing:** Multiple intermediate color shades between text and background make simple threshold-based detection unreliable

### Bypass attempts and findings

| Approach | Result | Why |
|----------|--------|-----|
| Vision AI (external) | ✅ Works (~80-90% accuracy) | Can read handwritten digits, but NOT available in XPTV JSC |
| Pixel analysis + segmentation | ⚠️ Partial | Can segment digit columns, but handwriting style + anti-aliasing makes template matching unreliable |
| MacCMS API fallback | ❌ Failed | `/api.php/provide/vod/*` returns "closed" (6 bytes). Site disabled all API endpoints. |
| AJAX search endpoint | ❌ Failed | `/index.php/ajax/search` returns 404. No alternative search API exists. |
| Browser automation (CDP) | ✅ Works | Can solve in browser, but XPTV scripts can't control browser |
| Session sharing (browser → XPTV) | ❌ Not feasible | XPTV's HTTP client doesn't share browser cookies |
| Brute force (10000 codes) | ❌ Impractical | Each wrong attempt requires new session; rate limiting blocks rapid attempts |

### Why pure algorithmic bypass fails in XPTV JSC

1. **No OCR capability** — JSC has no image processing, no template matching, no ML inference
2. **No vision API** — Can't call external vision services from within XPTV scripts
3. **No Buffer/atob** — Can't easily decode PNG pixel data (would need zlib decompression + palette lookup)
4. **Handwritten style** — Even with pixel data, template matching against hand-drawn digits is unreliable
5. **Session-bound** — Each CAPTCHA is tied to a unique PHPSESSID; can't pre-solve or cache

### Script implementation pattern

When a site has CAPTCHA-protected search, the script should:

```javascript
async function search(ext) {
  ext = argsify(ext);
  const { text, wd, page = 1 } = ext;
  const keyword = text || wd || '';

  if (!keyword) return jsonify({ list: [], page });

  const url = `${SITE}/vod/search.html?wd=${encodeURIComponent(keyword)}`;
  const { data } = await $fetch.get(url, { headers: HEADERS });

  // Detect CAPTCHA page — return gracefully
  if (data.includes('安全验证') || data.includes('请输入验证码')) {
    // Cannot bypass CAPTCHA in XPTV — return empty
    return jsonify({ list: [], page });
  }

  // Parse search results normally...
  const cheerio = createCheerio();
  const $ = cheerio.load(data);
  const list = [];
  // ... standard card extraction ...
  return jsonify({ list, page });
}
```

**User communication:** Document in script comments that search is limited due to anti-bot protection. Users can still browse via categories. If search is critical, suggest using the browser to verify once, then explain that XPTV doesn't share browser sessions.

### Detection heuristic for MacCMS CAPTCHA

When investigating a MacCMS-based site, check for CAPTCHA early:

```javascript
// In browser console or curl, check if search page has CAPTCHA
const isCaptchaProtected = pageHtml.includes('安全验证') ||
  pageHtml.includes('verify/index') ||
  pageHtml.includes('mac_verify');
```

Also check if the MacCMS API is open:
```bash
curl -s 'https://site.com/api.php/provide/vod/at/json?ac=list&wd=test' | head -c 50
# "closed" = API disabled, CAPTCHA likely active
# JSON data = API open, no CAPTCHA needed
```

### Related MacCMS patterns

- **`var maccms={"path":"","mid":"1","aid":"13"}`** — MacCMS site marker in inline script
- **`home.js`** — Standard MacCMS frontend JS, contains `MAC.Verify` object for CAPTCHA handling
- **`blueimp-md5`** — MD5 library loaded alongside (used for password hashing, not CAPTCHA)
- **`jsjiami.com.v7`** — Common obfuscator used on MacCMS custom scripts (makes reverse engineering harder)
- **`var player_aaaa={...}`** — MacCMS player config, extract `url` field (vid) for iframe playback

## Case Study: yun.92cj.com Multi-Type Player (lmm85.com)

**Site:** https://www.lmm85.com (路漫漫在線動漫, anime streaming)
**Player:** yun.92cj.com — common Chinese anime/movie player with multiple player types

### Discovery Method: Browser Network Monitoring

The correct API endpoints and iframe URLs were discovered by:
1. Loading the play page in a real browser
2. Using `performance.getEntriesByType('resource')` to capture actual iframe/XHR URLs
3. Inspecting the iframe's HTML to find `$.post("XXX.php", ...)` endpoint

**Key lesson:** Don't guess the iframe URL pattern — use the browser to find the real one. The player type determines the iframe URL format.

### Player Type Architecture

The `var player_aaaa` config on play pages has a `from` field that determines the player type:

| `from` value | iframe URL pattern | POST endpoint | Video CDN |
|---|---|---|---|
| `ykbox` | `yun.92cj.com/404.php?host=4khls&vid=...&referer=...` | `yunbox/ecvod.php` | oceanengine.com (ByteDance) |
| `vxdev` | `yun.92cj.com/yunbox/?type=vxdev&vid=...&referer=...` | `yunbox/vxdev.php` | groupvideo.photo.qq.com |
| `xgvxcd` | `yun.92cj.com/yunbox/?type=xgvxcd&vid=...&referer=...` | `yunbox/xgvxcd.php` | (varies) |
| `tudou` | N/A — vid IS the direct m3u8 URL | N/A | yun.92cj.com/video/... |

### Critical Implementation Details

**1. iframe URL construction differs per type:**

```javascript
// ykbox uses 404.php with host=4khls — NOT yunbox/?type=ykbox
if (from === 'ykbox') {
  const cleanVid = vid.split('&t=')[0];  // Strip &t=ecvod suffix
  iframeUrl = `https://yun.92cj.com/404.php?host=4khls&vid=${encodeURIComponent(cleanVid)}&t=ecvod&referer=${encodeURIComponent(playUrl)}`;
} else {
  // vxdev/xgvxcd use yunbox/?type=xxx
  iframeUrl = `https://yun.92cj.com/yunbox/?type=${from}&vid=${encodeURIComponent(vid)}&referer=${encodeURIComponent(playUrl)}`;
}
```

**2. POST endpoint must be extracted from iframe HTML (don't hardcode):**

```javascript
// The iframe's JS does: $.post("XXX.php", {...})
// Extract this dynamically to handle all player types
const postEndpointMatch = iframeHtml.match(/\$\.post\("([^"]+)"/);
const postEndpoint = postEndpointMatch ? postEndpointMatch[1] : 'ecvod.php';
const apiUrl = `https://yun.92cj.com/yunbox/${postEndpoint}`;
```

**3. ykbox vid must strip `&t=ecvod` suffix:**

The `player_aaaa.url` for `from=ykbox` contains `DOU_xxxxx=&t=ecvod`. The `&t=ecvod` part must be removed before putting it in the iframe URL, otherwise the vid parameter is malformed.

**4. `from=tudou` — vid IS the direct URL:**

```javascript
if (from === 'tudou') {
  // vid format: https://yun.92cj.com/video/xxx.m3u8&t=hls&ct=1
  const m3u8Url = vid.split('&t=')[0];
  return jsonify({ urls: [m3u8Url], headers: [{ 'User-Agent': UA, 'Referer': playUrl }] });
}
```

### AES Token Decryption (getc)

The iframe pages use `getc(token)` to decrypt a base64 token before POSTing. The decryption uses a pre-computed AES key:

```javascript
// Pre-compute AES key (only once at script load)
const _XOR_KEY = 'daolianlaopowanrenlun';
const _rk1 = _b64d('BlILGwo2OBoAATIXE1NXCwQALg0KE1xS');  // Step 1: base64 decode
let _rk2 = '';
for (let i = 0; i < _rk1.length; i++) {
  _rk2 += String.fromCharCode(_rk1.charCodeAt(i) ^ _XOR_KEY.charCodeAt(i % _XOR_KEY.length));
}  // Step 2: XOR with key
const _AES_KEY = [..._b64d(_rk2)].sort((a, b) => a.localeCompare(b, 'zh-CN')).join('');
// Step 3: base64 decode, then sort characters → "ejjooopppqqqrwww"
const _AES_IV = '1348987635684651';

function getc(encToken) {
  const CryptoJS = createCryptoJS();
  const keyParsed = CryptoJS.enc.Utf8.parse(_AES_KEY);
  const ivParsed = CryptoJS.enc.Utf8.parse(_AES_IV);
  const decrypted = CryptoJS.AES.decrypt(encToken, keyParsed, {
    iv: ivParsed,
    mode: CryptoJS.mode.CBC,
    padding: CryptoJS.pad.Pkcs7
  });
  return decrypted.toString(CryptoJS.enc.Utf8);
}
```

**Custom base64 decoder (XPTV JSC compatible — no Buffer/atob):**

```javascript
function _b64d(s) {
  const a = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=';
  const r = [];
  let i = 0;
  while (i < s.length) {
    const c1 = a.indexOf(s[i]);
    let c2 = (i + 1 < s.length) ? a.indexOf(s[i + 1]) : 0;
    let c3 = (i + 2 < s.length) ? a.indexOf(s[i + 2]) : 0;
    let c4 = (i + 3 < s.length) ? a.indexOf(s[i + 3]) : 0;
    if (c2 < 0) c2 = 0;
    if (c3 < 0) c3 = 0;
    if (c4 < 0) c4 = 0;
    const n = (c1 << 18) | (c2 << 12) | (c3 << 6) | c4;
    r.push(String.fromCharCode((n >> 16) & 255));
    if (c3 !== 64) r.push(String.fromCharCode((n >> 8) & 255));
    if (c4 !== 64) r.push(String.fromCharCode(n & 255));
    i += 4;
  }
  return r.join('');
}
```

**Pitfall:** `indexOf()` returns -1 for `=` (padding). Must NOT use -1 as a bit-shift operand — replace with 0 for c2/c3/c4, but preserve c1's -1 behavior (it becomes 0 in the bit operations anyway due to `<< 18` producing a large negative that gets masked).

### API Response Format

The API returns JSON:
```json
{
  "code": 200,
  "msg": "success",
  "ext": "mp4",
  "referer": "never",
  "url": "https://v9-cc.oceanengine.com/...mp4"
}
```

- `ext: "mp4"` — direct MP4 URL, play directly
- `ext: "link"` — embed URL, needs iframe (set `data.url` as iframe src)
- `referer: "never"` — don't set Referer header for playback (CDN doesn't need it)

### Troubleshooting

| Symptom | Cause | Fix |
|---|---|---|
| `token不能为空` | Decrypted token is empty string | Check getc() implementation; verify AES key computation |
| API returns `{"code":404}` | Wrong API endpoint URL | Extract `$.post("XXX.php")` from iframe HTML |
| API returns `token错误` | Token decryption wrong or token expired | Re-fetch iframe for fresh token; check base64 decoder |
| `from` type not handled | Unknown player type | Add to the `if (from === ...)` chain; check for site-specific player JS at `/static/player/{from}.js` |

### How to Find Player JS Files

Sites often have player-type-specific JS at `/static/player/{from}.js`:
```bash
curl -s 'https://www.lmm85.com/static/player/ykbox.js'
curl -s 'https://www.lmm85.com/static/player/vxdev.js'
```
These contain the iframe URL construction logic (usually ~600 bytes, very simple).

## Case Study: yun.92cj.com Multi-Type Player (lmm85.com)

**Site:** https://www.lmm85.com (路漫漫在線動漫, anime streaming)
**Player:** yun.92cj.com — common Chinese anime/movie player with multiple player types

### Discovery Method: Browser Network Monitoring

The correct API endpoints and iframe URLs were discovered by:
1. Loading the play page in a real browser
2. Using `performance.getEntriesByType('resource')` to capture actual iframe/XHR URLs
3. Inspecting the iframe's HTML to find `$.post("XXX.php", ...)` endpoint

**Key lesson:** Don't guess the iframe URL pattern — use the browser to find the real one. The player type determines the iframe URL format.

### Player Type Architecture

The `var player_aaaa` config on play pages has a `from` field that determines the player type:

| `from` value | iframe URL pattern | POST endpoint | Video CDN |
|---|---|---|---|
| `ykbox` | `yun.92cj.com/404.php?host=4khls&vid=...&referer=...` | `yunbox/ecvod.php` | oceanengine.com (ByteDance) |
| `vxdev` | `yun.92cj.com/yunbox/?type=vxdev&vid=...&referer=...` | `yunbox/vxdev.php` | groupvideo.photo.qq.com |
| `xgvxcd` | `yun.92cj.com/yunbox/?type=xgvxcd&vid=...&referer=...` | `yunbox/xgvxcd.php` | (varies) |
| `tudou` | N/A — vid IS the direct m3u8 URL | N/A | yun.92cj.com/video/... |

### Critical Implementation Details

**1. iframe URL construction differs per type:**
```javascript
// ykbox uses 404.php with host=4khls — NOT yunbox/?type=ykbox
if (from === 'ykbox') {
  const cleanVid = vid.split('&t=')[0];  // Strip &t=ecvod suffix
  iframeUrl = `https://yun.92cj.com/404.php?host=4khls&vid=${encodeURIComponent(cleanVid)}&t=ecvod&referer=${encodeURIComponent(playUrl)}`;
} else {
  // vxdev/xgvxcd use yunbox/?type=xxx
  iframeUrl = `https://yun.92cj.com/yunbox/?type=${from}&vid=${encodeURIComponent(vid)}&referer=${encodeURIComponent(playUrl)}`;
}
```

**2. POST endpoint must be extracted from iframe HTML (don't hardcode):**
```javascript
const postEndpointMatch = iframeHtml.match(/\$\.post\("([^"]+)"/);
const postEndpoint = postEndpointMatch ? postEndpointMatch[1] : 'ecvod.php';
const apiUrl = `https://yun.92cj.com/yunbox/${postEndpoint}`;
```

**3. ykbox vid must strip `&t=ecvod` suffix:**
The `player_aaaa.url` for `from=ykbox` contains `DOU_xxxxx=&t=ecvod`. The `&t=ecvod` part must be removed before putting it in the iframe URL.

**4. `from=tudou` — vid IS the direct URL:**
```javascript
if (from === 'tudou') {
  const m3u8Url = vid.split('&t=')[0];
  return jsonify({ urls: [m3u8Url], headers: [{ 'User-Agent': UA, 'Referer': playUrl }] });
}
```

### AES Token Decryption (getc)

The iframe pages use `getc(token)` to decrypt a base64 token. Pre-computed AES key:

```javascript
// AES Key derivation: XOR + base64 + sort
const _AES_KEY = 'ejjooopppqqqrwww';  // derived from gett('BlILGwo2OBoAATIXE1NXCwQALg0KE1xS')
const _AES_IV = '1348987635684651';

function getc(encToken) {
  const CryptoJS = createCryptoJS();
  const keyParsed = CryptoJS.enc.Utf8.parse(_AES_KEY);
  const ivParsed = CryptoJS.enc.Utf8.parse(_AES_IV);
  const decrypted = CryptoJS.AES.decrypt(encToken, keyParsed, {
    iv: ivParsed, mode: CryptoJS.mode.CBC, padding: CryptoJS.pad.Pkcs7
  });
  return decrypted.toString(CryptoJS.enc.Utf8);
}
```

### CAPTCHA Bypass: smart_verify

lmm85.com uses MacCMS CAPTCHA for search. The obfuscated `_0x_lmm_crypto.gen(ts)` was reverse-engineered (via decode-js `sojsonv7`) to reveal: `md5(ts + "MySecretlmm2026")`.

**Bypass flow:**
1. GET search page → server sets `PHPSESSID` cookie
2. POST `/index.php/ajax/smart_verify` with `smart_token=md5(ts+"MySecretlmm2026")&ts={timestamp}` (same PHPSESSID)
3. GET search page again (same PHPSESSID) → no CAPTCHA, results appear

**Critical:** `$fetch` must return `respHeaders` (not `headers`) to access `set-cookie` for session sharing. See xptv-script-debugging skill.

## Remember

A valid XPTV script is not just syntactically correct JavaScript. It must preserve XPTV's interface contract end-to-end:

`getConfig -> getCards -> getTracks -> getPlayinfo`

If that data flow is broken, the script is broken.
