#![no_std]

mod aes;

use aidoku::{
    alloc::{format, string::ToString, vec, String, Vec},
    imports::{
        html::Html,
        net::{Request, HttpMethod},
    },
    prelude::*,
    Chapter, ContentRating, DeepLinkHandler, DeepLinkResult, DynamicFilters, DynamicListings,
    DynamicSettings, Filter, FilterValue, Home, HomeComponent, HomeComponentValue, HomeLayout,
    ImageResponse, Listing, ListingKind, ListingProvider, Manga, MangaPageResult, MangaStatus,
    Page, PageContent, PageImageProcessor, Result, Source, Viewer,
};
use aidoku::imports::canvas::ImageRef;
use aidoku::imports::defaults::{defaults_get, defaults_set, DefaultValue};

const BASE_URL: &str = "https://manwa.me";
const AES_KEY: [u8; 16] = *b"my2ecret782ecret";
const AES_IV: [u8; 16] = *b"my2ecret782ecret";

struct Manwa;

impl Manwa {
    fn base_url(&self) -> String {
        let custom: Option<String> = defaults_get("custom_url");
        if let Some(url) = custom {
            if !url.is_empty() {
                return url.trim_end_matches('/').to_string();
            }
        }
        let mirror: Option<String> = defaults_get("mirror");
        if let Some(m) = mirror {
            if !m.is_empty() {
                return m.trim_end_matches('/').to_string();
            }
        }
        BASE_URL.to_string()
    }

    fn img_host(&self) -> String {
        let host: Option<String> = defaults_get("img_host");
        host.unwrap_or_default()
    }
}

impl Source for Manwa {
    fn new() -> Self {
        Self
    }

    fn get_search_manga_list(
        &self,
        query: Option<String>,
        page: i32,
        filters: Vec<FilterValue>,
    ) -> Result<MangaPageResult> {
        let base = self.base_url();
        let query_str = query.unwrap_or_default();

        let url = if !query_str.is_empty() && !query_str.contains('-') {
            if page > 1 {
                format!("{}/search?keyword={}&page={}", base, query_str, page)
            } else {
                format!("{}/search?keyword={}", base, query_str)
            }
        } else {
            let mut params = String::new();
            for filter in &filters {
                match filter {
                    FilterValue::Select { id, value } => {
                        if !value.is_empty() {
                            if !params.is_empty() {
                                params.push('&');
                            }
                            params = format!("{}{}={}", params, id, value);
                        }
                    }
                    FilterValue::MultiSelect { id, included, .. } => {
                        if !included.is_empty() && id == "tag" {
                            if !params.is_empty() {
                                params.push('&');
                            }
                            params = format!("{}tag={}", params, included.join(","));
                        }
                    }
                    _ => {}
                }
            }
            if page > 1 {
                if !params.is_empty() {
                    params.push('&');
                }
                params = format!("{}page={}", params, page);
            }
            if params.is_empty() {
                format!("{}/booklist", base)
            } else {
                format!("{}/booklist?{}", base, params)
            }
        };

        let document = Request::get(&url)?
            .header("User-Agent", "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120.0.0.0 Mobile Safari/537.36")
            .html()?;

        let mut entries = Vec::new();

        // Try booklist format first
        if let Some(items) = document.select("ul.book-list > li") {
            for item in items {
                let title = item
                    .select_first("p.book-list-info-title")
                    .and_then(|e| e.text())
                    .unwrap_or_default();
                let href = item
                    .select_first("a")
                    .and_then(|e| e.attr("abs:href"))
                    .unwrap_or_default();
                let cover = item
                    .select_first("img")
                    .and_then(|e| e.attr("data-original").or_else(|| e.attr("src")));
                entries.push(Manga {
                    key: href,
                    title,
                    cover,
                    ..Default::default()
                });
            }
        }

        // Try manga-list-2 format (category browse)
        if entries.is_empty() {
            if let Some(items) = document.select("ul.manga-list-2 > li") {
                for item in items {
                    let title = item
                        .select_first("p.manga-list-2-title")
                        .and_then(|e| e.text())
                        .unwrap_or_default();
                    let href = item
                        .select_first("a")
                        .and_then(|e| e.attr("abs:href"))
                        .unwrap_or_default();
                    let cover = item
                        .select_first("img")
                        .and_then(|e| e.attr("src"));
                    entries.push(Manga {
                        key: href,
                        title,
                        cover,
                        ..Default::default()
                    });
                }
            }
        }

        let has_next = document
            .select("ul.pagination2 > li")
            .and_then(|list| list.last())
            .and_then(|el| el.text())
            .map(|t| t.contains("下一页"))
            .unwrap_or(false);

        Ok(MangaPageResult {
            entries,
            has_next_page: has_next,
        })
    }

    fn get_manga_update(
        &self,
        mut manga: Manga,
        needs_details: bool,
        needs_chapters: bool,
    ) -> Result<Manga> {
        let base = self.base_url();
        let url = if manga.key.starts_with("http") {
            manga.key.clone()
        } else {
            format!("{}{}", base, manga.key)
        };

        let document = Request::get(&url)?
            .header("User-Agent", "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120.0.0.0 Mobile Safari/537.36")
            .html()?;

        if needs_details {
            manga.title = document
                .select_first(".detail-main-info-title")
                .and_then(|e| e.text())
                .unwrap_or(manga.title);

            manga.cover = document
                .select_first("div.detail-main-cover > img")
                .and_then(|e| e.attr("data-original").or_else(|| e.attr("src")));

            manga.authors = Some(
                document
                    .select("p.detail-main-info-author > span.detail-main-info-value > a")
                    .map(|list| list.filter_map(|e| e.text()).collect())
                    .unwrap_or_default(),
            );
            manga.artists = manga.authors.clone();

            manga.tags = document
                .select("div.detail-main-info-class > a.info-tag")
                .map(|list| list.filter_map(|e| e.text()).collect());

            manga.description = document
                .select_first("p.detail-desc")
                .and_then(|e| e.text());

            manga.status = document
                .select("p.detail-main-info-author")
                .map(|list| {
                    for el in list {
                        if let Some(label) = el.text() {
                            if label.contains("更新状态") {
                                if let Some(val) = el.select_first("span.detail-main-info-value") {
                                    if let Some(t) = val.text() {
                                        return match t.as_str() {
                                            "连载中" => MangaStatus::Ongoing,
                                            "已完结" => MangaStatus::Completed,
                                            _ => MangaStatus::Unknown,
                                        };
                                    }
                                }
                            }
                        }
                    }
                    MangaStatus::Unknown
                })
                .unwrap_or(MangaStatus::Unknown);

            manga.content_rating = ContentRating::Suggestive;
            manga.viewer = Viewer::Webtoon;
        }

        if needs_chapters {
            let mut chapters = Vec::new();
            if let Some(elements) = document.select("ul#detail-list-select > li > a") {
                for el in elements {
                    let href = el.attr("href").unwrap_or_default();
                    let name = el.text().unwrap_or_default();
                    chapters.push(Chapter {
                        key: href,
                        title: Some(name),
                        ..Default::default()
                    });
                }
            }
            chapters.reverse();
            manga.chapters = Some(chapters);
        }

        Ok(manga)
    }

    fn get_page_list(&self, _manga: Manga, chapter: Chapter) -> Result<Vec<Page>> {
        let base = self.base_url();
        let img_host = self.img_host();
        let url = if chapter.key.starts_with("http") {
            format!("{}{}", chapter.key, img_host)
        } else {
            format!("{}{}{}", base, chapter.key, img_host)
        };

        let document = Request::get(&url)?
            .header("User-Agent", "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120.0.0.0 Mobile Safari/537.36")
            .html()?;

        let mut pages = Vec::new();
        if let Some(images) = document.select("#cp_img > div.img-content > img[data-r-src]") {
            for (i, img) in images.into_iter().enumerate() {
                let src = img.attr("data-r-src").unwrap_or_default();
                if src.ends_with("?v=20220724") {
                    let mut ctx = aidoku::PageContext::new();
                    ctx.insert("encrypted".into(), "true".into());
                    pages.push(Page {
                        content: PageContent::url_context(src, ctx),
                        ..Default::default()
                    });
                } else {
                    pages.push(Page {
                        content: PageContent::url(src),
                        ..Default::default()
                    });
                }
                let _ = i;
            }
        }
        Ok(pages)
    }
}

// === Image Decryption ===

impl PageImageProcessor for Manwa {
    fn process_page_image(
        &self,
        response: ImageResponse,
        context: Option<aidoku::PageContext>,
    ) -> Result<ImageRef> {
        if let Some(ctx) = context {
            if ctx.get("encrypted").map(|v| v == "true").unwrap_or(false) {
                let data = response.image.data();
                let decrypted = aes::aes_128_cbc_decrypt(&data, &AES_KEY, &AES_IV);
                return Ok(ImageRef::new(&decrypted));
            }
        }
        Ok(response.image)
    }
}

// === Listings ===

impl DynamicListings for Manwa {
    fn get_dynamic_listings(&self) -> Result<Vec<Listing>> {
        Ok(vec![
            Listing {
                id: "popular".into(),
                name: "排行榜".into(),
                kind: ListingKind::List,
            },
            Listing {
                id: "latest".into(),
                name: "最新更新".into(),
                kind: ListingKind::Default,
            },
        ])
    }
}

impl ListingProvider for Manwa {
    fn get_manga_list(&self, listing: Listing, page: i32) -> Result<MangaPageResult> {
        let base = self.base_url();
        match listing.id.as_str() {
            "popular" => {
                let url = format!("{}/rank", base);
                let document = Request::get(&url)?
                    .header("User-Agent", "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120.0.0.0 Mobile Safari/537.36")
                    .html()?;

                let mut entries = Vec::new();
                if let Some(items) = document.select("#rankList_2 > a") {
                    for item in items {
                        let title = item.attr("title").unwrap_or_default();
                        let href = item.attr("abs:href").unwrap_or_default();
                        let cover = item
                            .select_first("img")
                            .and_then(|e| e.attr("data-original").or_else(|| e.attr("src")));
                        entries.push(Manga {
                            key: href,
                            title,
                            cover,
                            ..Default::default()
                        });
                    }
                }
                Ok(MangaPageResult {
                    entries,
                    has_next_page: false,
                })
            }
            "latest" => {
                let offset = (page - 1) * 15;
                let url = format!("{}/getUpdate?page={}&date=", base, offset);
                let text = Request::get(&url)?
                    .header("User-Agent", "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120.0.0.0 Mobile Safari/537.36")
                    .string()?;

                let mut entries = Vec::new();
                let mut has_next = false;

                if let Ok(json) = aidoku::imports::json::parse(&text) {
                    if let Some(obj) = json.as_object() {
                        if let Some(books) = obj.get("books").and_then(|b| b.as_array()) {
                            let img_host_url = format!("{}/update{}", base, self.img_host());
                            let img_prefix = Request::get(&img_host_url)
                                .ok()
                                .and_then(|req| req.html().ok())
                                .and_then(|doc| {
                                    doc.select_first(".manga-list-2-cover-img")
                                        .and_then(|e| e.attr(":src"))
                                        .map(|s| {
                                            s.trim_start_matches('\'')
                                                .trim_start_matches('"')
                                                .split('\'')
                                                .next()
                                                .unwrap_or("")
                                                .to_string()
                                        })
                                })
                                .unwrap_or_default();

                            for book in books {
                                if let Some(obj) = book.as_object() {
                                    let id = obj
                                        .get("id")
                                        .and_then(|v| v.as_string())
                                        .unwrap_or_default();
                                    let name = obj
                                        .get("book_name")
                                        .and_then(|v| v.as_string())
                                        .unwrap_or_default();
                                    let cover_path = obj
                                        .get("cover_url")
                                        .and_then(|v| v.as_string())
                                        .unwrap_or_default();
                                    entries.push(Manga {
                                        key: format!("/book/{}", id),
                                        title: name,
                                        cover: if !img_prefix.is_empty() && !cover_path.is_empty() {
                                            Some(format!("{}{}", img_prefix, cover_path))
                                        } else {
                                            None
                                        },
                                        ..Default::default()
                                    });
                                }
                            }

                            if let Some(total) =
                                obj.get("total").and_then(|v| v.as_int())
                            {
                                has_next = total > (offset + 15) as i64;
                            }
                        }
                    }
                }

                Ok(MangaPageResult {
                    entries,
                    has_next_page: has_next,
                })
            }
            _ => bail!("Unknown listing"),
        }
    }
}

// === Filters ===

impl DynamicFilters for Manwa {
    fn get_dynamic_filters(&self) -> Result<Vec<Filter>> {
        Ok(vec![
            Filter::select(
                "end",
                "状态",
                vec![
                    vec!["全部".into(), "".into()],
                    vec!["连载中".into(), "2".into()],
                    vec!["完结".into(), "1".into()],
                ],
                Some(0),
            ),
            Filter::select(
                "gender",
                "类型",
                vec![
                    vec!["全部".into(), "-1".into()],
                    vec!["一般向".into(), "2".into()],
                    vec!["BL向".into(), "0".into()],
                    vec!["禁漫".into(), "1".into()],
                    vec!["TL向".into(), "3".into()],
                ],
                Some(0),
            ),
            Filter::select(
                "area",
                "地区",
                vec![
                    vec!["全部".into(), "".into()],
                    vec!["韩国".into(), "2".into()],
                    vec!["日漫".into(), "3".into()],
                    vec!["国漫".into(), "4".into()],
                    vec!["台漫".into(), "5".into()],
                    vec!["其他".into(), "6".into()],
                    vec!["未分类".into(), "1".into()],
                ],
                Some(0),
            ),
            Filter::select(
                "sort",
                "排序",
                vec![
                    vec!["最新".into(), "-1".into()],
                    vec!["最旧".into(), "0".into()],
                    vec!["收藏".into(), "1".into()],
                    vec!["新漫".into(), "2".into()],
                ],
                Some(0),
            ),
            Filter::note("标签分类请在搜索中使用关键词筛选"),
        ])
    }
}

// === Home Layout ===

impl Home for Manwa {
    fn get_home(&self) -> Result<HomeLayout> {
        let base = self.base_url();
        let document = Request::get(&base)?
            .header("User-Agent", "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120.0.0.0 Mobile Safari/537.36")
            .html()?;

        let mut featured = Vec::new();
        if let Some(items) = document.select("#rankList_2 > a") {
            for item in items.take(10) {
                let title = item.attr("title").unwrap_or_default();
                let href = item.attr("abs:href").unwrap_or_default();
                let cover = item
                    .select_first("img")
                    .and_then(|e| e.attr("data-original").or_else(|| e.attr("src")));
                featured.push(Manga {
                    key: href,
                    title,
                    cover,
                    ..Default::default()
                });
            }
        }

        Ok(HomeLayout {
            components: vec![
                HomeComponent {
                    title: Some("排行榜".into()),
                    value: if !featured.is_empty() {
                        HomeComponentValue::BigScroller {
                            entries: featured.clone(),
                            auto_scroll_interval: Some(5.0),
                        }
                    } else {
                        HomeComponentValue::MangaList {
                            ranking: true,
                            page_size: Some(10),
                            entries: featured.clone().into_iter().map(|m| m.into()).collect(),
                            listing: Some(Listing {
                                id: "popular".into(),
                                name: "排行榜".into(),
                                kind: ListingKind::List,
                            }),
                        }
                    },
                    ..Default::default()
                },
                HomeComponent {
                    title: Some("最新更新".into()),
                    value: HomeComponentValue::MangaList {
                        ranking: false,
                        page_size: None,
                        entries: vec![],
                        listing: Some(Listing {
                            id: "latest".into(),
                            name: "最新更新".into(),
                            kind: ListingKind::Default,
                        }),
                    },
                    ..Default::default()
                },
                HomeComponent {
                    title: Some("分类".into()),
                    value: HomeComponentValue::Filters(vec![
                        "一般向".into(),
                        "BL向".into(),
                        "TL向".into(),
                        "国漫".into(),
                        "日漫".into(),
                        "韩漫".into(),
                    ]),
                    ..Default::default()
                },
                HomeComponent {
                    title: Some("链接".into()),
                    value: HomeComponentValue::Links(vec![
                        aidoku::Link {
                            title: "漫蛙官网".into(),
                            subtitle: None,
                            image_url: None,
                            value: Some(aidoku::LinkValue::Url(base)),
                        },
                    ]),
                    ..Default::default()
                },
            ],
        })
    }
}

// === Deep Links ===

impl DeepLinkHandler for Manwa {
    fn handle_deep_link(&self, url: String) -> Result<Option<DeepLinkResult>> {
        if url.contains("/book/") {
            Ok(Some(DeepLinkResult::Manga { key: url }))
        } else if url.contains("/chapter/") || url.contains("/read/") {
            let parts: Vec<&str> = url.rsplitn(3, '/').collect();
            if parts.len() >= 2 {
                let manga_key = format!("/book/{}", parts.last().unwrap_or(&""));
                Ok(Some(DeepLinkResult::Chapter {
                    manga_key,
                    key: url,
                }))
            } else {
                Ok(None)
            }
        } else {
            Ok(None)
        }
    }
}

// === Settings ===

impl DynamicSettings for Manwa {
    fn get_dynamic_settings(&self) -> Result<Vec<aidoku::Setting>> {
        Ok(vec![
            aidoku::EditTextSetting {
                key: "custom_url".into(),
                title: "自定义URL".into(),
                subtitle: Some("指定访问的目标URL，优先级高于镜像URL".into()),
                placeholder: Some("https://manwa.me".into()),
                ..Default::default()
            }
            .into(),
            aidoku::EditTextSetting {
                key: "mirror".into(),
                title: "镜像URL".into(),
                subtitle: Some("可选: manwa.me / manwass.cc / manwatg.cc / manwast.cc / manwasy.cc".into()),
                placeholder: Some("https://manwa.me".into()),
                ..Default::default()
            }
            .into(),
            aidoku::EditTextSetting {
                key: "img_host".into(),
                title: "图源参数".into(),
                subtitle: Some("切换图源可优化图片加载".into()),
                placeholder: Some("留空使用默认".into()),
                ..Default::default()
            }
            .into(),
        ])
    }
}

register_source!(Manwa, PageImageProcessor, ListingProvider, Home, DeepLinkHandler, DynamicFilters, DynamicSettings);
