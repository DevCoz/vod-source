#!/usr/bin/env bash
# Build Aidoku source to .aix package
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PROJECT_NAME="manwa"
TARGET="wasm32-unknown-unknown"
BUILD_DIR="${SCRIPT_DIR}/build"
AIX_FILE="${BUILD_DIR}/${PROJECT_NAME}.aix"

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

info()  { echo -e "${GREEN}[INFO]${NC} $*"; }
warn()  { echo -e "${YELLOW}[WARN]${NC} $*"; }
error() { echo -e "${RED}[ERROR]${NC} $*"; exit 1; }

check_deps() {
    if ! command -v rustc &>/dev/null; then
        error "rustc not found. Install Rust: https://rustup.rs"
    fi
    if ! command -v cargo &>/dev/null; then
        error "cargo not found. Install Rust: https://rustup.rs"
    fi
    if ! rustup target list --installed 2>/dev/null | grep -q "$TARGET"; then
        warn "Target $TARGET not installed. Adding..."
        rustup target add "$TARGET" || error "Failed to add wasm target"
    fi
}

build_wasm() {
    info "Building ${PROJECT_NAME} for ${TARGET}..."
    cd "$SCRIPT_DIR"

    cargo build --release --target "$TARGET" 2>&1 || error "Cargo build failed"

    local wasm_file="${SCRIPT_DIR}/target/${TARGET}/release/${PROJECT_NAME}.wasm"
    if [[ ! -f "$wasm_file" ]]; then
        error "Wasm file not found: $wasm_file"
    fi
    info "Wasm built: $(wc -c < "$wasm_file") bytes"
    echo "$wasm_file"
}

package_aix() {
    local wasm_file="$1"
    mkdir -p "$BUILD_DIR"

    info "Packaging .aix..."
    cp "$wasm_file" "${BUILD_DIR}/"

    cd "$BUILD_DIR"
    rm -f "$AIX_FILE"
    zip -j "$AIX_FILE" "${SCRIPT_DIR}/manifest.json" "$(basename "$wasm_file")" 2>/dev/null \
        || error "Failed to create .aix package"

    rm -f "$(basename "$wasm_file")"
    info "Package created: ${AIX_FILE} ($(wc -c < "$AIX_FILE") bytes)"
}

run_tests() {
    info "Running tests..."
    cd "$SCRIPT_DIR"
    cargo test 2>&1 || warn "Tests failed (non-fatal for wasm build)"
}

main() {
    local action="${1:-build}"

    case "$action" in
        build)
            check_deps
            wasm_file=$(build_wasm)
            package_aix "$wasm_file"
            info "Done! Import ${AIX_FILE} into Aidoku."
            ;;
        test)
            check_deps
            run_tests
            ;;
        clean)
            info "Cleaning..."
            cd "$SCRIPT_DIR"
            cargo clean 2>/dev/null || true
            rm -rf "$BUILD_DIR"
            info "Cleaned."
            ;;
        check)
            check_deps
            info "Checking project..."
            cd "$SCRIPT_DIR"
            cargo check --target "$TARGET" 2>&1 || error "Check failed"
            info "Check passed."
            ;;
        *)
            echo "Usage: $0 {build|test|clean|check}"
            echo ""
            echo "  build  - Build wasm and package .aix (default)"
            echo "  test   - Run tests"
            echo "  clean  - Clean build artifacts"
            echo "  check  - Check code without building"
            exit 1
            ;;
    esac
}

main "$@"
