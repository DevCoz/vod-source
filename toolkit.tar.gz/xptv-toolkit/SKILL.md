---
name: xptv
description: "XPTV 脚本开发技能 — 创建、调试和维护 XPTV 本地 JavaScript 脚本（.xptv.js）。覆盖六大接口、MacCMS API、HTML 爬取、网盘源、筛选、搜索、直播源、iframe 嵌套播放器、Smart Play API、AES/DES 解密、过盾反爬、TVBox 转换。触发词：xptv, 写源, xptv脚本, 视频源, 播放源, 写爬虫, 抓取视频, source script, .xptv.js, maccms, 网盘源, JSON源, 直播源, TVBox, 过盾, 解密"
version: 2.2.0
---

# XPTV Script Development Skill

## When to Use
- 用户要求创建/编写 XPTV 源脚本
- 用户要求调试/修复已有 `.xptv.js` 脚本
- 用户询问 XPTV 脚本接口、数据格式或最佳实践
- 用户提供目标站点，希望制作 XPTV 源

## Quick Decision Tree

```
用户请求 → 确定操作类型：
  ├─ 脚本已混淆(jsjiami等) → 直接跳转「运行时调试」(knowledge/xptv-runtime-debug.md)
  ├─ 创建新源 → 读取 knowledge/xptv-dev-guide.md
  ├─ 调试已有脚本 → 读取 knowledge/xptv-debug-guide.md
  └─ 咨询接口/格式问题 → 查阅 knowledge/xptv-api-reference.md
```

## 执行模式

流程：识别类型 → 选模板 → 实现6接口 → 搭建测试 → 验证修复 → 交付成品。

**自动推进**：类型明确、模板匹配时直接执行，不中途确认。

**必须暂停确认**：
- 站点类型/API 结构不确定（呈现你的判断依据，问用户确认）
- 存在多种可行方案时（列出权衡，让用户选择）
- 目标站点完全无法访问
- 流地址获取需要特定账号/权限

**不要假设**：不确定时先确认，不要默默选一种解释然后执行。

## Reference Documents

按需加载，不要一次性读完全部文档。根据场景只读相关文件：

**必读**（每次）：
1. **API 参考**: `knowledge/xptv-api-reference.md` — 六大接口、参数、返回格式
2. **工具箱**: `knowledge/xptv-toolbox.md` — `$fetch`, `createCheerio()`, `createCryptoJS()`, 工具函数

**按场景加载**：
3. **模板库**: `knowledge/xptv-templates.md` — MacCMS API、HTML 爬取、网盘、直播、iframe 播放器等 9 个模板
4. **开发指南**: `knowledge/xptv-dev-guide.md` — 创建新源的完整执行步骤
5. **调试指南**: `knowledge/xptv-debug-guide.md` — 调试流程、故障排除、错误恢复
6. **实战案例**: `knowledge/xptv-case-studies.md` — kisskh、radio.cn、lmm85、yun.92cj、斗鱼、LIBVIO 等站点逆向案例
7. **可复用模式**: `knowledge/xptv-patterns.md` — 27 种代码模式（SxxExx、WordPress 懒加载、SPA 检测等）
8. **运行时调试**: `knowledge/xptv-runtime-debug.md` — Puppeteer hook 反混淆方法
9. **调试案例集**: `knowledge/xptv-debugging-case-studies.md` — CupFox、91porn、heiliao、haijiao 等调试实战
10. **官方文档存档**: `knowledge/xptv-official-doc.md` — XPTV 官方开发文档原文

**辅助文档**：
11. **反爬虫参考**: `knowledge/xptv-anti-bot.md` — GeeTest、rate limiting、strencode2
12. **常见问题**: `knowledge/xptv-troubleshooting.md` — 20 种常见故障排查
13. **图片 CDN**: `knowledge/xptv-image-cdn-compatibility.md` — 已知 CDN 兼容性表
14. **Git 工作流**: `knowledge/xptv-pr-workflow.md` — PR 创建和代码同步

## Core Architecture

### Six Interfaces
```
getLocalInfo()  → { ver, name, api, type? }    ← 元数据，本地源必须实现
getConfig()     → { ver, title, site, tabs[{name, ext}] }
getCards(ext)   → { list[{vod_id, vod_name, vod_pic, vod_remarks, ext}], filter? }
getTracks(ext)  → { list[{title, tracks[{name, pan?, ext}]}], info? }
getPlayinfo(ext)→ { urls[], headers?[] }
search(ext)     → { list[], page? }
```

> **getLocalInfo 说明**：本地 `.xptv.js` 文件**必须**实现。远程订阅源可省略。`api` 字段必须全局唯一（如 `csp_sitename`）。

### Data Flow
```
getLocalInfo()                         ← 独立调用，XPTV 用此识别和管理源
getConfig.tabs[].ext → getCards(ext)
getCards.list[].ext  → getTracks(ext)
getTracks.list[].tracks[].ext → getPlayinfo(ext)
```

### Cloud Drive (网盘) Pattern
```
getTracks: tracks[].pan = "https://pan.quark.cn/s/..."
getPlayinfo: return { urls: [] }  // 空 — 播放器直接处理 pan
```

### Critical Rules
1. **所有返回**：用 `jsonify()` 包装，永远不返回原始对象
2. **所有入参**：用 `argsify(ext)` 解析，永远不把 ext 当字符串用
3. **$fetch.post()**：`$fetch.post(url, body, { headers: {...} })` — 三参数格式
4. **Base64**：使用 `createCryptoJS()` — JSC 沙箱中没有 `Buffer` 和 `atob`
5. **文件命名**：`[name].xptv.js`
6. **getPlayinfo 失败**：返回 `{ urls: [] }`，不添加多余的 `headers: []`
7. **API 字段唯一**：`getLocalInfo` 的 `api: "csp_xxx"` 必须全局唯一

## Anti-Patterns（绝对不要做的事）

| ❌ 错误做法 | ✅ 正确做法 |
|------------|------------|
| 跳过 6 个接口中的任何一个 | 全部实现，网盘源 getPlayinfo 返回空 |
| `Buffer.from()` / `atob()` 做 Base64 | `createCryptoJS()` |
| `$fetch.post(url, {data, headers})` | `$fetch.post(url, body, {headers})` |
| 返回原始对象 | `jsonify()` 包装 |
| 入参不解析 | `argsify(ext)` |
| 生产代码用 `console.log()` | `$print()` 调试，生产移除 |
| api 字段重复 | 全局唯一 |
| `{ urls: [], headers: [] }` | `{ urls: [] }` |
| 网盘链接放 `ext.url` | 用 `pan` 参数 |
| 不确认就假设站点类型/API 结构 | 先分析再确认，呈现判断依据 |
| AES 解密后不 trim | `.trim()` 去除 CR/LF |
| 解密用 `md5X()` 占位符 | `CryptoJS.MD5()` |
| 重复解析逻辑复制粘贴 | 提取公共函数 |

## Quality Checklist (验证循环)

每项检查后运行 `xptv_harness.js smoke` 验证，失败则修复再重跑，直到全部通过。

**接口完整性**：
- [ ] 六个接口全部存在 (`xptv_harness.js list`)
- [ ] tab/category ID 与 `getCards()` 对应

**数据格式**：
- [ ] 所有返回 `jsonify()` 包装
- [ ] 所有入参 `argsify()` 解析
- [ ] `search()` 返回标准卡片格式
- [ ] 横式图片加 `ui: 1`

**逻辑正确**：
- [ ] `getTracks()` 至少一条有效线路
- [ ] 网盘源用 `pan`，`getPlayinfo()` 返回空
- [ ] `$fetch.post()` 三参数格式
- [ ] `CryptoJS.MD5()` 非 `md5X()` 占位符
- [ ] AES 解密后 `.trim()`
- [ ] 错误降级不抛异常

**交付前自检**：是否只做了用户要求的功能？有没有加未要求的"灵活性"？如果资深工程师看这代码，会觉得过度复杂吗？

## Quick Test (XPTV Harness)

独立的 CLI 测试工具，无需启动 Express 服务器即可测试脚本。

```bash
# 烟雾测试 — 自动跑全部 6 个接口
node xptv_harness.js smoke <script.xptv.js>

# 指定搜索关键词
node xptv_harness.js smoke <script.xptv.js> --keyword 龙珠

# 单步执行 — 测试指定接口
node xptv_harness.js run <script.xptv.js> --fn getCards --ext '{"id":"1","page":1}'

# 列出脚本实现的接口
node xptv_harness.js list <script.xptv.js>

# 分析站点类型
node xptv_harness.js analyze <url>
```

## Remember

有效 XPTV 脚本必须端到端保持接口契约：
`getConfig → getCards → getTracks → getPlayinfo`

**简洁优先**：能用模板解决的不手写，能 50 行搞定的不写 100 行。不加未要求的功能，不为不可能的场景做防御。

**精准修改**：调试时只改必须改的，不"顺手优化"其他逻辑。匹配脚本现有风格。

**`new URL()` vs 正则**：JSC 沙箱对 `URL`/`URLSearchParams` 支持不稳定，优先用正则——但如果脚本已用 `new URL()` 且能正常工作，不要改它。
