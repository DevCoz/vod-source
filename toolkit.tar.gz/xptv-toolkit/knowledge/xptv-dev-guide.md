# XPTV 脚本开发指南 — 创建新源

## 执行步骤

### Step 0: 检查现有脚本（先查再写！）

**⚠️ 写新脚本前，先检查是否已有现成脚本：**

```bash
# 在 xptv-extensions 中搜索
find ~/.xptv-debugger/xptv-extensions -name "*.xptv.js" | grep <source-name>
# 或在 xptv-scripts 中搜索
find ~/.xptv-scripts -name "*.xptv.js" | grep <source-name>
```

如果找到了，直接用它作为基础修改，而不是从零开始。很多脚本之前已经写过，可能只需要更新分类/tabs。

**脚本存放位置**：
- `~/.xptv-scripts/` — 活跃脚本，供 XPTV 导入
- `~/.xptv-debugger/xptv-extensions/` — git 跟踪的参考脚本（修复后也要同步到这里）


### Step 1: 识别 API 类型

要求用户提供目标站点URL。
如果用户未提供URL，询问：
  - 站点地址是什么？
  - 你希望抓取什么内容（电影/电视剧/动漫/直播）？

根据以下信号判断 API 类型：

| 信号                              | 类型         | 模板     |
|-----------------------------------|-------------|----------|
| URL 含 /api.php/provide/vod/      | MacCMS      | T1 或 T4  |
| 网页有视频列表 DOM                | HTML 爬取   | T2       |
| 数据来自网盘分享链接              | 网盘源       | T3       |
| Cloudflare / 人机验证             | HTML+过盾   | T5       |
| 实时流、多 CDN                    | 直播源       | T6       |
| 播放页有 player_aaaa 变量        | 多层加密     | T7       |
| 播放页加载 iframe + POST API      | iframe嵌套播放器 | T8       |
| Smart Play API + execB 解密       | Smart Play  | T9       |

**🔎 Checkpoint 1 — API 类型自判断**
自动识别 API 类型并继续，仅在无法判断时暂停询问用户。

### Step 2: 获取目标站点信息

根据模板类型，需要从用户获取：
- MacCMS: API地址（完整URL）
- HTML爬取: 目标页面URL，确认DOM结构（选择器）
- 网盘: 数据来源URL，网盘类型（夸克/阿里/115/天翼）
- 直播: 站点URL，是否需要签名认证
- 多层加密: 播放页URL，已知的加密方式

如果无法直接获取，使用 web_fetch 抓取目标页面分析结构。

### Step 3: 实现六个接口

按模板实现，严格遵循以下清单：

- [x] `getLocalInfo()` — api字段全局唯一（如 `csp_sitename`）
- [x] `getConfig()` — 返回 tabs 列表，每个 tab 带 ext 参数
- [x] `getCards(ext)` — 解析 ext 获取 id/page，用 `argsify()`
- [x] `getTracks(ext)` — 解析视频详情页，提取播放线路
- [x] `getPlayinfo(ext)` — 提取实际播放地址，必须 try-catch
- [x] `search(ext)` — 实现搜索功能

每个接口必须：
- 入参用 `argsify(ext)` 解析
- 返回用 `jsonify()` 包装
- `getPlayinfo` 外包 try-catch，失败返回 `{ urls: [] }`

**🔎 Checkpoint 2 — 自动代码审查**
六个接口写完后自动执行以下检查，发现问题直接修复：
- [ ] 所有 6 个接口都实现了？
- [ ] 所有返回都用 `jsonify()` 包装？
- [ ] 所有入参都用 `argsify()` 解析？
- [ ] `getPlayinfo` 外包 try-catch，失败返回 `{ urls: [] }`？
- [ ] `$fetch.post()` 使用三参数格式？
- [ ] Base64 使用 CryptoJS 而非 Buffer/atob？
- [ ] `getLocalInfo` 的 api 字段唯一？
- [ ] 请求头包含 User-Agent 和 Referer？
- [ ] 无 `createCheerio()`/`createCryptoJS()` 残留？
- [ ] 密钥集中在顶部常量区？

### Step 4: 测试验证（必须执行）

**⚠️ 每个源写完后必须跑完整测试，不跳过。**

#### 方法一：Harness 快速测试

```bash
node xptv_harness.js smoke my_source.xptv.js
node xptv_harness.js smoke my_source.xptv.js --keyword 龙珠
```

#### 方法二：dev-toolkit 服务器测试

```bash
mkdir -p {name}-devtoolkit/src {name}-devtoolkit/server {name}-devtoolkit/utils
cp skills/xptv/dev-toolkit/utils/utils.js {name}-devtoolkit/utils/
cp skills/xptv/dev-toolkit/server/server.js {name}-devtoolkit/server/
cp skills/xptv/dev-toolkit/package.json {name}-devtoolkit/
echo "import { \$fetch, jsonify, argsify } from '../utils/utils.js'" > {name}-devtoolkit/src/debug.js
echo "import * as cheerio from 'cheerio'" >> {name}-devtoolkit/src/debug.js
sed 's/^const cheerio = createCheerio();//' {name}.xptv.js | \
  sed 's/^const CryptoJS = createCryptoJS()/import CryptoJS from "crypto-js"/' | \
  sed '/\/\/ const cheerio = createCheerio()/d' >> {name}-devtoolkit/src/debug.js
echo "export { getLocalInfo, getConfig, getCards, getTracks, getPlayinfo, search }" >> {name}-devtoolkit/src/debug.js
cd {name}-devtoolkit && npm install && node server/server.js &
```

#### 测试检查表（逐接口）

```bash
curl -s http://localhost:3000/getLocalInfo          # 验证 ver, name, api
curl -s http://localhost:3000/getConfig              # 验证 tabs
curl -s -X POST http://localhost:3000/getCards -H "Content-Type: text/plain" -d '{"page":1}'
curl -s -X POST http://localhost:3000/getTracks -H "Content-Type: text/plain" -d '{"id":"ID"}'
curl -s -X POST http://localhost:3000/getPlayinfo -H "Content-Type: text/plain" -d '{"url":"URL"}'
curl -s -X POST http://localhost:3000/search -H "Content-Type: text/plain" -d '{"text":"测试"}'
```

#### 清理

```bash
kill $(lsof -t -i:3000) 2>/dev/null; rm -rf {name}-devtoolkit
```

**🔎 Checkpoint 3 — 自动测试 + 交付**
搭建 dev-toolkit 测试环境，跑 6 接口测试。失败项自动修复后重测，通过后直接交付脚本。

### Step 5: 交付与存档

- 保存脚本为 `[name].xptv.js`
- 说明使用方法和导入步骤
- 如有 dev-toolkit，说明本地调试方式

## Pre-Analysis: 图片方向检测

编写脚本前，抽样 3-5 张卡片图片判断方向：
- 横式（宽屏 16:9）→ `getConfig()` tabs 加 `ui: 1`
- 直式（竖屏）→ 省略 `ui`（默认）

> 详细检测代码见 `knowledge/xptv-patterns.md` → Pattern 1

## 创建新源的完整流程

```bash
# 1. 从模板开始
cp templates/base.xptv.js my_source.xptv.js

# 2. 编辑脚本（修改 SITE、API、选择器等）
vim my_source.xptv.js

# 3. 快速测试
node xptv_harness.js smoke my_source.xptv.js

# 4. 单步调试问题接口
node xptv_harness.js run my_source.xptv.js --fn getPlayinfo --ext '{"url":"..."}'

# 5. （可选）启动 dev-server 做联调
cd dev-toolkit && npm install && npm start
# curl http://localhost:3000/test

# 6. rollup 打包
cd dev-toolkit && npm run build
# → dist/output.xptv.js
```

## Fallback Strategies

### API 类型误判
MacCMS XML 失败 → JSON (T4) | HTML 爬取失败 → JS渲染检查 | 播放地址失败 → iframe 递归

### 请求失败
$fetch.get 403 → 更换 UA → Referer → Cookie → 报告失败 | POST 参数错误 → form-urlencoded → JSON → 无 Content-Type

### 解析失败
XML → JSON → cheerio | 选择器空 → 输出 500 字符分析 → 备选 | 加密失败 → 输出原始值 → 提示逆向 | jsjiami → 运行时调试

### getPlayinfo 返回空
1. iframe？→ 提取 src 重新请求
2. player_aaaa？→ 正则/大括号计数法
3. POST 端点？→ vid/t/token 后 POST
4. 网盘？→ `{ urls: [] }`，播放器处理 pan
5. 都失败 → `{ urls: [] }` + `$print` 错误

### 搜索被验证码拦截
1. 检测验证码页关键词：`安全验证`、`请输入验证码`、`verifyBox`
2. smart_verify → POST `/index.php/ajax/smart_verify`，body: `smart_token=MD5(ts+secret)&ts={timestamp}`
3. secret 在前端 JS 中搜索 `smart_verify`、`MySecret` 关键词
4. 首次 GET 获取 PHPSESSID → POST 验证 → 带 cookie 重新搜索
5. 无解时：返回 `{list:[], page}` 并提示用户「该站搜索需要人机验证，建议用浏览器搜索后手动导入」
