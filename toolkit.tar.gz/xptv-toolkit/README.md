# XPTV 开发工具包 (XPTV Development Toolkit)

整合版开发工具包，用于创建、调试和维护 XPTV 本地脚本（`.xptv.js`）。

## 包含内容

### 核心 Skill
- **SKILL.md** — 主入口，包含快速决策树、核心架构、反模式清单

### 知识库 (`knowledge/`)
| 文件 | 内容 |
|------|------|
| `xptv-api-reference.md` | 六大接口参考、参数、返回格式、JSC 环境约束 |
| `xptv-toolbox.md` | `$fetch`、`createCheerio()`、`createCryptoJS()` 等工具函数 |
| `xptv-templates.md` | 9 个模板（MacCMS/HTML/网盘/JSON/直播/iframe/Smart Play） |
| `xptv-dev-guide.md` | 创建新源的完整执行步骤 |
| `xptv-debug-guide.md` | 调试流程、故障排除、错误恢复 |
| `xptv-patterns.md` | 27 种可复用代码模式 |
| `xptv-case-studies.md` | 实战逆向案例（kisskh/radio.cn/lmm85/斗鱼/LIBVIO 等） |
| `xptv-debugging-case-studies.md` | 调试案例（CupFox/91porn/heiliao/haijiao 等） |
| `xptv-troubleshooting.md` | 20 种常见故障排查 |
| `xptv-runtime-debug.md` | Puppeteer hook 反混淆方法 |
| `xptv-anti-bot.md` | GeeTest、rate limiting、strencode2 |
| `xptv-image-cdn-compatibility.md` | 图片 CDN 兼容性表 |
| `xptv-pr-workflow.md` | Git/PR 工作流 |
| `xptv-official-doc.md` | XPTV 官方开发文档原文 |

### 工具
| 工具 | 说明 |
|------|------|
| `xptv_harness.js` | CLI 测试工具（smoke test、单步执行、站点分析） |
| `templates/base.xptv.js` | 基础脚本模板 |
| `decode-js/` | JavaScript 反混淆工具（jsjiami/obfuscator/jjencode/AWSC） |

## 快速开始

### 写一个新源

```bash
# 1. 从模板开始
cp templates/base.xptv.js my_source.xptv.js

# 2. 编辑脚本
vim my_source.xptv.js

# 3. 测试
node xptv_harness.js smoke my_source.xptv.js --keyword 测试
```

### 调试已有脚本

```bash
# 烟雾测试
node xptv_harness.js smoke ~/.xptv-scripts/my_script.xptv.js --keyword 测试

# 单步执行
node xptv_harness.js run ~/.xptv-scripts/my_script.xptv.js --fn getPlayinfo --ext '{"url":"..."}'
```

### 反混淆 JS

```bash
# jsjiami.com v6
decode-js -t sojson -i obfuscated.js -o decoded.js

# javascript-obfuscator
decode-js -t obfuscator -i obfuscated.js -o decoded.js
```

## 环境需求

### XPTV 脚本开发
- XPTV App（执行 `.xptv.js` 脚本）
- 无需额外安装 — 脚本在 XPTV 的 JavaScriptCore 环境中执行

### XPTV 脚本调试
- Node.js 22+
- xptv_harness.js（已包含在本包中）

### decode-js
- Node.js 22+
- decode-js 工具（已包含在本包中）

## 目录结构

```
xptv-toolkit/
├── SKILL.md                              # 主入口
├── README.md                             # 本文件
├── xptv_harness.js                       # CLI 测试工具
├── harness-package.json                  # harness 依赖配置
├── templates/
│   └── base.xptv.js                      # 基础脚本模板
├── knowledge/
│   ├── xptv-api-reference.md             # 六大接口参考
│   ├── xptv-toolbox.md                   # 工具函数库
│   ├── xptv-templates.md                 # 9 个模板
│   ├── xptv-dev-guide.md                 # 创建新源步骤
│   ├── xptv-debug-guide.md               # 调试流程
│   ├── xptv-patterns.md                  # 27 种代码模式
│   ├── xptv-case-studies.md              # 实战逆向案例
│   ├── xptv-debugging-case-studies.md    # 调试案例
│   ├── xptv-troubleshooting.md           # 常见问题排查
│   ├── xptv-runtime-debug.md             # Puppeteer hook 反混淆
│   ├── xptv-anti-bot.md                  # 反爬虫参考
│   ├── xptv-image-cdn-compatibility.md   # 图片 CDN 兼容性
│   ├── xptv-pr-workflow.md               # Git/PR 工作流
│   └── xptv-official-doc.md              # 官方文档存档
│   ├── server/server.js                  # Express 测试服务器
│   ├── utils/utils.js                    # $fetch / jsonify / argsify 模拟
│   ├── src/debug.js                      # 源码编辑区
│   ├── rollup.config.js                  # ES module → XPTV 格式转换
│   └── package.json
└── decode-js/
    ├── SKILL.md                          # JS 反混淆指南
    ├── src/main.js                       # 主入口
    ├── src/plugin/                       # 各混淆器插件
    └── package.json
```

## License

MIT
