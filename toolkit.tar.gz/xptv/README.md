# XPTV 開發工具包 (XPTV Development Toolkit)

三個 Hermes Agent Skill 的整合包，用於開發、除錯和分析 XPTV 本地腳本（`.xptv.js`）。

## 包含的 Skill

### 1. xptv-script-development
XPTV 本地腳本開發指南。涵蓋：
- 六個必要介面（`getLocalInfo`, `getConfig`, `getCards`, `getTracks`, `getPlayinfo`, `search`）
- MacCMS API 源、HTML 抓取源、網盤源 三種類型
- AES-CBC 解密、base64 處理、player_aaaa 解析
- TVBox 腳本轉換、Douban API、體育直播 filter
- SPA/SSR 網站處理、圖片 CDN 相容性
- 大量實戰案例和可複用的 pattern

### 2. xptv-script-debugging
XPTV 腳本除錯工具指南。涵蓋：
- 本地 Node.js harness 測試（smoke test、單步執行）
- 六步煙霧測試流程
- 常見錯誤診斷樹
- GeeTest CAPTCHA、rate limiting、obfuscated code 處理
- 案例研究：91porn、heiliao、radio.cn、kisskh、lmm85 等

### 3. decode-js
JavaScript 反混淆工具指南。支援：
- jsjiami.com v6/v7 (`sojson` / `sojsonv7`)
- javascript-obfuscator (`obfuscator`)
- JJEncode (`jjencode`)
- 阿里雲 AWSC (`awsc`)
- 通用局部混淆 (`common`)

## 環境需求

### XPTV 腳本開發
- XPTV App（執行 `.xptv.js` 腳本）
- 無需額外安裝 — 腳本在 XPTV 的 JavaScriptCore 環境中執行

### XPTV 腳本除錯
- Node.js 22+
- xptv-debugger harness（`xptv_harness.js`）
- 腳本存放目錄（預設 `~/.xptv-scripts/`）

### decode-js
- Node.js 22+
- decode-js 工具（需另行安裝）

## 快速開始

### 寫一個新源

1. 閱讀 `xptv-script-development/SKILL.md` 了解介面規範
2. 從 `xptv-script-development/templates/base.xptv.js` 開始
3. 根據目標站點類型（MacCMS / HTML 抓取 / 網盤）選擇對應 recipe
4. 實作六個介面，確保每個都用 `jsonify()` 包裹

### 除錯腳本

```bash
# 煙霧測試
node xptv_harness.js smoke ~/.xptv-scripts/my_script.xptv.js --keyword 測試

# 單步執行
node xptv_harness.js run ~/.xptv-scripts/my_script.xptv.js --fn getPlayinfo --ext '{"url":"..."}'
```

### 反混淆 JS

```bash
# jsjiami.com v6
decode-js -t sojson -i obfuscated.js -o decoded.js

# javascript-obfuscator
decode-js -t obfuscator -i obfuscated.js -o decoded.js
```

## 目錄結構

```
xptv-toolkit/
├── README.md
├── xptv-script-development/
│   ├── SKILL.md                          # 主開發指南（含所有 pattern 和案例）
│   ├── templates/
│   │   └── base.xptv.js                  # 基礎腳本模板
│   └── references/
│       └── image-cdn-compatibility.md    # 圖片 CDN 相容性表
├── xptv-script-debugging/
│   ├── SKILL.md                          # 除錯指南
│   └── references/
│       ├── case-studies.md               # 各站點實戰案例
│       ├── anti-bot.md                   # 反爬蟲和 CAPTCHA 處理
│       └── pr-workflow.md                # Git/PR 工作流
└── decode-js/
    └── SKILL.md                          # JS 反混淆指南
```

## License

MIT
