---
name: xptv
description: "XPTV 脚本开发技能 — 创建、调试和维护 XPTV 本地 JavaScript 脚本（.xptv.js）。覆盖六大接口、MacCMS API、HTML 爬取、网盘源、筛选、搜索、直播源、iframe 嵌套播放器、Smart Play API、AES/DES 解密、过盾反爬、TVBox 转换。触发词：xptv, 写源, xptv脚本, 视频源, 播放源, 写爬虫, 抓取视频, source script, .xptv.js, maccms, 网盘源, JSON源, 直播源, TVBox, 过盾, 解密"
version: 2.0.0
---

# XPTV Script Development Skill

## When to Use
- 用户要求创建/编写 XPTV 源脚本
- 用户要求调试/修复已有 `.xptv.js` 脚本
- 用户询问 XPTV 脚本接口、数据格式或最佳实践
- 用户提供目标站点，希望制作 XPTV 源

## Quick Decision Tree

```
用户请求 → 确定操作类型：
  ├─ 脚本已混淆(jsjiami等) → 直接跳转「运行时调试」(knowledge/xptv-runtime-debug.md)
  ├─ 创建新源 → Step 1: 识别API类型
  ├─ 调试已有脚本 → 直接跳转「调试流程」
  └─ 咨询接口/格式问题 → 查阅 knowledge/ 回答
```

## 自动化模式

默认全自动执行，跳过中间确认点。流程：识别类型 → 选模板 → 实现6接口 → 搭建测试 → 自动修复 → 直接交付成品。

仅在以下情况暂停：
- 目标站点完全无法访问
- API 类型无法判断（需用户提供额外信息）
- 流地址获取需要特定账号/权限

## Reference Documents

在编写任何脚本前，先阅读以下文件：

1. **API 参考**: `knowledge/xptv-api-reference.md` — 六大接口、参数、返回格式
2. **工具箱**: `knowledge/xptv-toolbox.md` — `$fetch`, `createCheerio()`, `createCryptoJS()`, 工具函数
3. **模板库**: `knowledge/xptv-templates.md` — MacCMS API、HTML 爬取、网盘、直播、iframe 播放器等 9 个模板
4. **故障排除**: `knowledge/xptv-troubleshooting.md` — 常见错误及修复
5. **运行时调试**: `knowledge/xptv-runtime-debug.md` — Puppeteer hook 反混淆方法
6. **实战案例**: `knowledge/xptv-case-studies.md` — kisskh、radio.cn、lmm85、yun.92cj 等站点逆向案例
7. **可复用模式**: `knowledge/xptv-patterns.md` — 21 种代码模式（SxxExx、WordPress 懒加载、SPA 检测等）

## Core Architecture

### Six Interfaces
```
getLocalInfo()  → { ver, name, api, type? }    ← 元数据，本地源必须实现
getConfig()     → { ver, title, site, tabs[{name, ext}] }
getCards(ext)   → { list[{vod_id, vod_name, vod_pic, vod_remarks, ext}], filter? }
getTracks(ext)  → { list[{title, tracks[{name, pan?, ext}]}], info? }
getPlayinfo(ext)→ { urls[], headers?[] }
search(ext)     → { list[], page? }
```

> **getLocalInfo 说明**：本地 `.xptv.js` 文件**必须**实现。远程订阅源可省略。`api` 字段必须全局唯一（如 `csp_sitename`）。

### Data Flow
```
getLocalInfo()                         ← 独立调用，XPTV 用此识别和管理源
getConfig.tabs[].ext → getCards(ext)
getCards.list[].ext  → getTracks(ext)
getTracks.list[].tracks[].ext → getPlayinfo(ext)
```

### Cloud Drive (网盘) Pattern
```
getTracks: tracks[].pan = "https://pan.quark.cn/s/..."
getPlayinfo: return { urls: [] }  // 空 — 播放器直接处理 pan
```

### Critical Rules
1. **所有返回**：用 `jsonify()` 包装，永远不返回原始对象
2. **所有入参**：用 `argsify(ext)` 解析，永远不把 ext 当字符串用
3. **$fetch.post()**：`$fetch.post(url, body, { headers: {...} })` — 三参数格式
4. **Base64**：使用 `createCryptoJS()` — JSC 沙箱中没有 `Buffer` 和 `atob`
5. **文件命名**：`[name].xptv.js`
6. **getPlayinfo 失败**：返回 `{ urls: [] }`，不添加多余的 `headers: []`
7. **API 字段唯一**：`getLocalInfo` 的 `api: "csp_xxx"` 必须全局唯一

## Execution Steps（创建新源）

### Step 1: 识别 API 类型
```
要求用户提供目标站点URL。
如果用户未提供URL，询问：
  - 站点地址是什么？
  - 你希望抓取什么内容（电影/电视剧/动漫/直播）？

根据以下信号判断 API 类型：
| 信号                              | 类型         | 模板     |
|-----------------------------------|-------------|----------|
| URL 含 /api.php/provide/vod/      | MacCMS      | T1 或 T4  |
| 网页有视频列表 DOM                | HTML 爬取   | T2       |
| 数据来自网盘分享链接              | 网盘源       | T3       |
| Cloudflare / 人机验证             | HTML+过盾   | T5       |
| 实时流、多 CDN                    | 直播源       | T6       |
| 播放页有 player_aaaa 变量        | 多层加密     | T7       |
| 播放页加载 iframe + POST API      | iframe嵌套播放器 | T8       |
| Smart Play API + execB 解密       | Smart Play  | T9       |
```

**🔎 Checkpoint 1 — API 类型自判断**
自动识别 API 类型并继续，仅在无法判断时暂停询问用户。

### Step 2: 获取目标站点信息
```
根据模板类型，需要从用户获取：
- MacCMS: API地址（完整URL）
- HTML爬取: 目标页面URL，确认DOM结构（选择器）
- 网盘: 数据来源URL，网盘类型（夸克/阿里/115/天翼）
- 直播: 站点URL，是否需要签名认证
- 多层加密: 播放页URL，已知的加密方式

如果无法直接获取，使用 web_fetch 抓取目标页面分析结构。
```

### Step 3: 实现六个接口
```
按模板实现，严格遵循以下清单：

□ getLocalInfo() — api字段全局唯一（如 csp_sitename）
□ getConfig()    — 返回 tabs 列表，每个 tab 带 ext 参数
□ getCards(ext)  — 解析 ext 获取 id/page，用 argsify()
□ getTracks(ext) — 解析视频详情页，提取播放线路
□ getPlayinfo(ext) — 提取实际播放地址，必须 try-catch
□ search(ext)    — 实现搜索功能

每个接口必须：
- 入参用 argsify(ext) 解析
- 返回用 jsonify() 包装
- getPlayinfo 外包 try-catch，失败返回 { urls: [] }
```

**🔎 Checkpoint 2 — 自动代码审查**
六个接口写完后自动执行以下检查，发现问题直接修复：
- [ ] 所有 6 个接口都实现了？
- [ ] 所有返回都用 jsonify() 包装？
- [ ] 所有入参都用 argsify() 解析？
- [ ] getPlayinfo 外包 try-catch，失败返回 `{ urls: [] }`？
- [ ] `$fetch.post()` 使用三参数格式？
- [ ] Base64 使用 CryptoJS 而非 Buffer/atob？
- [ ] getLocalInfo 的 api 字段唯一？
- [ ] 请求头包含 User-Agent 和 Referer？
- [ ] 无 createCheerio()/createCryptoJS() 残留？
- [ ] 密钥集中在顶部常量区？

### Step 4: 测试验证（必须执行）

**⚠️ 每个源写完后必须跑完整测试，不跳过。**

#### 搭建测试环境
```bash
mkdir -p {name}-devtoolkit/src {name}-devtoolkit/server {name}-devtoolkit/utils
cp skills/xptv/dev-toolkit/utils/utils.js {name}-devtoolkit/utils/
cp skills/xptv/dev-toolkit/server/server.js {name}-devtoolkit/server/
cp skills/xptv/dev-toolkit/package.json {name}-devtoolkit/
echo "import { \$fetch, jsonify, argsify } from '../utils/utils.js'" > {name}-devtoolkit/src/debug.js
echo "import * as cheerio from 'cheerio'" >> {name}-devtoolkit/src/debug.js
sed 's/^const cheerio = createCheerio();//' {name}.xptv.js | \
  sed 's/^const CryptoJS = createCryptoJS()/import CryptoJS from "crypto-js"/' | \
  sed '/\/\/ const cheerio = createCheerio()/d' >> {name}-devtoolkit/src/debug.js
echo "export { getLocalInfo, getConfig, getCards, getTracks, getPlayinfo, search }" >> {name}-devtoolkit/src/debug.js
cd {name}-devtoolkit && npm install && node server/server.js &
```

#### 测试检查表（逐接口）
```bash
curl -s http://localhost:3000/getLocalInfo          # 验证 ver, name, api
curl -s http://localhost:3000/getConfig              # 验证 tabs
curl -s -X POST http://localhost:3000/getCards -H "Content-Type: text/plain" -d '{"page":1}'
curl -s -X POST http://localhost:3000/getTracks -H "Content-Type: text/plain" -d '{"id":"ID"}'
curl -s -X POST http://localhost:3000/getPlayinfo -H "Content-Type: text/plain" -d '{"url":"URL"}'
curl -s -X POST http://localhost:3000/search -H "Content-Type: text/plain" -d '{"text":"测试"}'
```

#### 清理
```bash
kill $(lsof -t -i:3000) 2>/dev/null; rm -rf {name}-devtoolkit
```

**🔎 Checkpoint 3 — 自动测试 + 交付**
搭建 dev-toolkit 测试环境，跑 6 接口测试。失败项自动修复后重测，通过后直接交付脚本。

### Step 5: 交付与存档
- 保存脚本为 `[name].xptv.js`
- 说明使用方法和导入步骤
- 如有 dev-toolkit，说明本地调试方式

## 调试流程（Fix Existing Script）

### D1: 收集信息
- 脚本内容
- 错误症状（列表为空？无法播放？搜索无结果？）
- 目标站点 URL

### D2: 定位问题

**当用户报告症状时，先收集信息（D1），再按症状匹配排查路径：**

| 症状                          | 优先检查                                     | 自动触发 |
|-------------------------------|---------------------------------------------|---------|
| 列表为空                       | 选择器、请求头、动态加载、编码               | 要求用户提供脚本+URL |
| 无法播放                       | getPlayinfo URL、Referer、加密               | 要求提供脚本+播放页URL |
| $fetch.post 异常               | 参数格式（三参数 vs 两参数）                 | 检查代码中 post() 调用 |
| Base64 失败                    | 用 CryptoJS，不用 Buffer/atob                | 搜索脚本中 Buffer/atob |
| 分页不工作                     | 参数名(page/pg/paged)、起始值                | 要求提供列表页URL |
| 搜索无结果                     | 参数名(wd/text/q)、编码                      | 要求提供搜索URL |
| 中文乱码                       | CDATA解析、URL编码                           | 要求提供原始响应 |
| 搜索被验证码拦截                | smart_verify、PHPSESSID cookie               | 检查响应含「安全验证」 |
| iframe 播放器无结果            | iframe src、POST 端点、token 解密            | 要求提供播放页URL+player_aaaa |
| SPA 站点列表为空               | 检测 __NUXT__/__NEXT_DATA__、找 API endpoint | web_fetch 分析页面 |
| 图片 CDN 不加载                | Referer/UA 热链接保护、XPTV WebView 限制     | 检查 image-cdn-compatibility |
| execB 解密失败                 | jsjiami 混淆 → 运行时 hook                   | grep jsjiami 标识 |

**🔎 自动修复**
定位到问题根因后直接修复，修复后重测验证。

### D3: 修复并验证
修复后再次执行 Step 4 检查清单。

## Anti-Patterns（绝对不要做的事）

| ❌ 错误做法 | ✅ 正确做法 |
|------------|------------|
| 跳过 6 个接口中的任何一个 | 全部实现，网盘源 getPlayinfo 返回空 |
| `Buffer.from()` / `atob()` 做 Base64 | `createCryptoJS()` |
| `$fetch.post(url, {data, headers})` | `$fetch.post(url, body, {headers})` |
| 返回原始对象 | `jsonify()` 包装 |
| 入参不解析 | `argsify(ext)` |
| 生产代码用 `console.log()` | `$print()` 调试，生产移除 |
| api 字段重复 | 全局唯一 |
| `{ urls: [], headers: [] }` | `{ urls: [] }` |
| 网盘链接放 `ext.url` | 用 `pan` 参数 |
| `new URL()` / `URLSearchParams` | 正则字符串解析 |
| AES 解密后不 trim | `.trim()` 去除 CR/LF |
| 解密用 `md5X()` 占位符 | `CryptoJS.MD5()` |
| 重复解析逻辑复制粘贴 | 提取公共函数 |

## Fallback Strategies

### API 类型误判
MacCMS XML 失败 → JSON (T4) | HTML 爬取失败 → JS渲染检查 | 播放地址失败 → iframe 递归

### 请求失败
$fetch.get 403 → 更换 UA → Referer → Cookie → 报告失败 | POST 参数错误 → form-urlencoded → JSON → 无 Content-Type

### 解析失败
XML → JSON → cheerio | 选择器空 → 输出 500 字符分析 → 备选 | 加密失败 → 输出原始值 → 提示逆向 | jsjiami → 运行时调试

### getPlayinfo 返回空
1. iframe？→ 提取 src 重新请求
2. player_aaaa？→ 正则/大括号计数法
3. POST 端点？→ vid/t/token 后 POST
4. 网盘？→ `{ urls: [] }`，播放器处理 pan
5. 都失败 → `{ urls: [] }` + `$print` 错误

### 搜索被验证码拦截
1. 检测验证码页关键词：`安全验证`、`请输入验证码`、`verifyBox`
2. smart_verify → POST `/index.php/ajax/smart_verify`，body: `smart_token=MD5(ts+secret)&ts={timestamp}`
3. secret 在前端 JS 中搜索 `smart_verify`、`MySecret` 关键词
4. 首次 GET 获取 PHPSESSID → POST 验证 → 带 cookie 重新搜索
5. 无解时：返回 `{list:[], page}` 并提示用户「该站搜索需要人机验证，建议用浏览器搜索后手动导入」

## Error Recovery

| 场景 | 处理 |
|------|------|
| 站点无法访问 | 检查 URL、UA、备用方案；尝试 HTTP 降级 |
| API 格式不符 | 打印前 500 字符分析；XML→JSON→HTML fallback |
| 加密未知 | 提供前端 JS 逆向；jsjiami → runtime-debug.md |
| 选择器不匹配 | web_fetch 分析 DOM；尝试 3+ 备选选择器 |
| SPA 无数据 | __NUXT__ 解析 / API endpoint / tag 页兜底 |
| 图片 CDN 不显示 | 平台限制，确保播放正常；检查 image-cdn-compatibility |
| getCards 空列表 | 确认站点存活(curl)；检查分页参数(page/pg/paged)；检查 UA/Referer |
| getTracks 空剧集 | 给兜底 track `{name:'播放', ext:{url}}`；检查详情页选择器 |
| 网络超时 | 设置 timeout 20s；重试 1 次；仍失败报告用户 |
| 搜索被 CAPTCHA 拦截 | 检测 smart_verify → POST 获取 token；无解则返回空+提示用户 |
| 分类 URL 404 | 检查 ?sort= / ?filter= 查询参数；对比导航与实际可访问 URL |
| $fetch 无法获取 cookie | 用 respHeaders（非 headers）取 Set-Cookie；手动拼接 Cookie 头 |
| 中文乱码 | XML 用 CDATA 正则；URL 用 encodeURIComponent |
| 同一站点多播放器类型 | 按 player_aaaa.from 分支处理（ykbox/vxdev/tudou/直接m3u8） |

## Pre-Analysis: 图片方向检测

编写脚本前，抽样 3-5 张卡片图片判断方向：
- 横式（宽屏 16:9）→ `getConfig()` tabs 加 `ui: 1`
- 直式（竖屏）→ 省略 `ui`（默认）

> 详细检测代码见 `knowledge/xptv-patterns.md` → Pattern 1

## Quality Checklist Before Shipping

- 六个接口全部存在
- 所有返回 `jsonify()` 包装
- 所有入参 `argsify()` 解析
- tab/category ID 与 `getCards()` 对应
- 横式图片加 `ui: 1`
- `getTracks()` 至少一条有效线路
- 网盘源用 `pan`，`getPlayinfo()` 返回空
- `$fetch.post()` 三参数格式
- `CryptoJS.MD5()` 非 `md5X()` 占位符
- AES 解密后 `.trim()`
- `search()` 返回标准卡片格式
- 错误降级不抛异常

## Local Development Toolkit

复杂脚本用 dev-toolkit 本地开发：
- ES module 编写（`src/debug.js`）
- Express 服务器测试（`npm run dev` → localhost:3000）
- rollup 打包（`npm run build` → `dist/output.xptv.js`）
- 自动替换 import → XPTV 内置函数

参见 `dev-toolkit/README.md`。

## Remember

有效 XPTV 脚本必须端到端保持接口契约：
`getConfig → getCards → getTracks → getPlayinfo`
数据流断裂，脚本就废了。

---

## 快速测试 (XPTV Harness)

独立的 CLI 测试工具，无需启动 Express 服务器即可测试脚本。

### 用法

```bash
# 烟雾测试 — 自动跑全部 6 个接口
node xptv_harness.js smoke <script.xptv.js>

# 指定搜索关键词
node xptv_harness.js smoke <script.xptv.js> --keyword 龍珠

# 单步执行 — 测试指定接口
node xptv_harness.js run <script.xptv.js> --fn getCards --ext '{"id":"1","page":1}'
node xptv_harness.js run <script.xptv.js> --fn getPlayinfo --ext '{"url":"/play/xxx-1-1.html"}'

# 列出脚本实现的接口
node xptv_harness.js list <script.xptv.js>
```

### smoke 测试流程

```
1. getLocalInfo()           → 验证 ver, name, api
2. getConfig()              → 获取 tabs
3. getCards(tab[0].ext)     → 用第一个 tab 测试
4. getTracks(cards[0].ext)  → 用第一个卡片测试
5. getPlayinfo(tracks[0])   → 用第一个 track 测试
6. search({text: keyword})  → 搜索测试
```

每个接口自动计时，输出 `✅/❌/⏭️` 状态和摘要。

### Harness vs dev-toolkit

| 场景 | Harness | dev-toolkit |
|------|---------|-------------|
| 快速验证 | ✅ `smoke` 一条命令 | ❌ 需要 npm install + 启动服务器 |
| 单步调试 | ✅ `run --fn --ext` | ✅ curl 到 localhost:3000 |
| 集成测试 | ❌ 无 HTTP 端点 | ✅ 外部程序可调用 |
| 依赖 | axios, cheerio, crypto-js | 同左 + express |

**建议**：开发阶段用 harness（快），联调阶段用 dev-toolkit（可被其他程序调用）。

---

## 创建新源的完整流程

```bash
# 1. 从模板开始
cp templates/base.xptv.js my_source.xptv.js

# 2. 编辑脚本（修改 SITE、API、选择器等）
vim my_source.xptv.js

# 3. 快速测试
node xptv_harness.js smoke my_source.xptv.js

# 4. 单步调试问题接口
node xptv_harness.js run my_source.xptv.js --fn getPlayinfo --ext '{"url":"..."}'

# 5. （可选）启动 dev-server 做联调
cd dev-toolkit && npm install && npm start
# curl http://localhost:3000/test

# 6. rollup 打包
cd dev-toolkit && npm run build
# → dist/output.xptv.js
```
