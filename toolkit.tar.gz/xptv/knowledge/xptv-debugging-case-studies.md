# XPTV Debugger — Case Studies

Site-specific debugging sessions documenting real problems and solutions.

## Table of Contents

- [$fetch.post() Parameter Format](#fetchpost-parameter-format)
- [player_aaaa JSON Extraction](#player_aaaa-json-extraction)
- [Hardcoded Placeholder Functions](#hardcoded-placeholder-functions)
- [Browser vs Node.js Page Differences](#browser-vs-nodejs-page-differences)
- [CupFox (茶杯狐)](#cupfox-茶杯狐)
- [avdb.js Upload18.org](#avdbjs-upload18org)
- [91porn.com — strencode2](#91porncom--strencode2)
- [$config_str / Token-Based Sources](#config_str--token-based-sources)
- [symx.js (山有木兮)](#symxjs-山有木兮)
- [heiliao.com — Nuxt.js SSR](#heiliacom--nuxtjs-ssr)
- [radio.cn (雲聽) — API Discovery](#radiocn-雲聽--api-discovery)
- [jqqzx.cc — JSON-Escaped HTML](#jqqzxcc--json-escaped-html)
- [haijiao.com — Preview vs Full Video](#haijiaocom--preview-vs-full-video)
- [English-Only Title Translation](#english-only-title-translation)
- [HTTP → HTTPS Conversion](#http--https-conversion)
- [Diagnosing "Can't Import" Failures](#diagnosing-cant-import-failures)

---

## $fetch.post() Parameter Format

**Signature:** `$fetch.post(url, body, options)` — 3 arguments, body as 2nd arg.

```javascript
// ❌ WRONG - body in options.data (axios style)
await $fetch.post(url, { data: 'key=value', headers: {...} });

// ✅ CORRECT - body as 2nd arg
await $fetch.post(url, 'key=value', { headers: {...} });
await $fetch.post(url, jsonify({ wd: keyword }), { headers: {...} });
```

**Symptoms:** API returns "parameter error", "vid empty", or empty search results.

---

## player_aaaa JSON Extraction

**Problem:** `JSON.parse()` fails with "Unexpected non-whitespace character after JSON" when extracting `player_aaaa` from inline script.

**Cause:** `lastIndexOf('}')` picks up `}` from later `<script>` tags. Regex with lazy `*?` stops at first `}` which may be inside a URL string.

**Solution — brace counting:**
```javascript
const idx = html.indexOf('player_aaaa');
const braceStart = html.indexOf('{', idx);
if (braceStart > -1) {
    let depth = 0, braceEnd = -1;
    for (let i = braceStart; i < html.length && i < braceStart + 5000; i++) {
        if (html[i] === '{') depth++;
        if (html[i] === '}') depth--;
        if (depth === 0) { braceEnd = i; break; }
    }
    if (braceEnd > braceStart) {
        const obj = JSON.parse(html.substring(braceStart, braceEnd + 1));
    }
}
```

**Alternative regex** (when `</script>` follows immediately):
```javascript
const match = data.match(/var\s+player_aaaa\s*=\s*(\{[^<]+\})\s*;?\s*<\/script>/);
```

---

## Hardcoded Placeholder Functions

**Problem:** `md5X()` returns fixed string `'test'` instead of actual MD5 hash.

```javascript
// ❌ Placeholder
function md5X(input) { return 'test'; }

// ✅ Fix
function md5X(input) {
    const CryptoJS = createCryptoJS();
    return CryptoJS.MD5(input).toString();
}
```

**Symptoms:** Decrypted URL is garbage, not starting with `http`.

---

## Browser vs Node.js Page Differences

**Observation:** Play page returns different `player_aaaa` content:
- Browser: `url` field is full base64 string (~1200+ chars)
- Node.js fetch: `url` field is path format (~200-400 chars)

Both work with the API. **Always test with the actual harness** (Node.js), not browser DevTools.

---

## CupFox (茶杯狐)

**Site:** https://www.cupfox.ai

**Issues found:**

| # | Bug | Fix |
|---|-----|-----|
| 1 | `md5X()` hardcoded 'test' | Use `CryptoJS.MD5(input).toString()` |
| 2 | `$fetch.post(url, body, headers)` wrong format | Use 3-param: `post(url, body, {headers})` |
| 3 | `lastIndexOf('}')` for JSON | Use brace counting algorithm |

**Play flow:** page → `player_aaaa` JSON → encrypted url → POST `foxplay/api.php` → decrypt with `Decode1.sign()` (mode 1) or `decode2()` (mode 2) → m3u8.

---

## avdb.js Upload18.org

**Problem:** Script used `playerInstance.setup()` regex but site uses `jwplayer().setup()`. `file` field was a variable reference, not direct URL.

**Fix:** Multi-pattern fallback:
1. Extract from `window.PLAYER_CONFIG.m3u8` (most reliable)
2. Fall back to `setup()` object if `file` is a direct URL string
3. Handle relative paths: prepend `new URL(url).origin`

---

## 91porn.com — strencode2

**Site:** https://91porn.com

**Problem:** Video keeps spinning, never plays. The visible `<source src="https://ccm.91p52.com/...mp4">` is **commented out** (`<!-- -->`) and points to a dead CDN.

**Real URL** is encoded in `document.write(strencode2("..."))` — URL-encoded hex that decodes to `https://la.btc620.com/...mp4`.

**3-layer extraction (JSC-safe):**
```javascript
// Method 1: Direct pattern in encoded string (NO decodeURIComponent needed)
const encodeMatch = data.match(/strencode2\(\"([^\"]+)\"\)/);
if (encodeMatch) {
    const mp4Match = encodeMatch[1].match(/https?%3a%2f%2f[^\"'\s%]+\.mp4[^\"'\s%]*/i);
    if (mp4Match) {
        videoUrl = mp4Match[0]
            .replace(/%3a/gi, ':').replace(/%2f/gi, '/')
            .replace(/%3f/gi, '?').replace(/%3d/gi, '=')
            .replace(/%26/gi, '&').replace(/%2b/gi, '+');
    }
}
// Method 2: Full decodeURIComponent (fallback if available)
// Method 3: Fallback to non-commented source tag
```

**Fix double-slash:** `videoUrl.replace(/([^:]\/)\/+/g, '$1')`

**Chinese titles:** Add `Cookie: language=cn_CN` to all requests.

---

## $config_str / Token-Based Sources

**Affected:** `91_vod_xptv.js`, `one.js`, `xh_vod_xptv.js`, `douyu.js`, `jpyy.js`, `alist_tvbox.js`

**Symptom:** `$config_str is not defined`

**Fix (harness already patched):** Sandbox provides `$config_str: JSON.stringify({ token: '' })`. Override with `--config '{"token":"xxx"}'`.

**Without valid token:** API calls return 404. You can only verify syntax/load and `getPlayinfo` passthrough.

---

## symx.js (山有木兮)

**Site:** https://film.symx.club

**What works:** getConfig, getCards, getTracks (no auth needed)
**What fails:** getPlayinfo, search → HTTP 401 (GeeTest v4 required)

**GeeTest v4 cannot be bypassed with pure JS** — requires browser CDP for trusted mouse events. This is a server-side limitation.

---

## heiliao.com — Nuxt.js SSR

**Site:** https://heiliao.com (吃瓜爆料)

**Architecture:** Nuxt.js SSR. Content in Nuxt payload, NOT standard DOM.

**Key findings:**
1. Standard selectors (`.video-item`) don't work → use `a[href*="/archives/"]`
2. Images on `pic.cshsst.cn` CDN (not heiliao.com)
3. CDN has hotlink protection — images won't display in XPTV (platform limitation)
4. Video uses DPlayer with `config='...'` attribute → extract via JSON.parse

**Debug approach for unknown SSR sites:**
1. Check for `data-server-rendered`, `__nuxt` markers
2. Search for `window.__NUXT__` payload
3. Find article link patterns (`a[href*="/archives/"]`, etc.)
4. Map image CDN domains with frequency analysis

---

## radio.cn (雲聽) — API Discovery

**Site:** https://www.radio.cn

**Challenge:** Site loads content via JS. Standard curl gets empty HTML.

**Discovery:** Use `performance.getEntriesByType('resource')` in browser console to find API.

**API:**
```
GET https://ytmsout.radio.cn/web/appProgram/pageByColumn?pageNo={page}&columnId={id}&pageSize={count}
```

**Known channels:**
- 笑声编辑部: columnId=1453129
- 笑口不断: columnId=1396377

**Key fields:** `playUrlHigh` (m4a), `name`, `programDate`, `durationStr`

---

## jqqzx.cc — JSON-Escaped HTML

**Site:** https://www.jqqzx.cc (剧圈圈)

**Problem:** cheerio returns empty results despite HTTP 200.

**Cause:** Server returns HTML wrapped as JSON string literal. First char is `"` (charCode 34).

**Fix — `unescapeHtml()` helper:**
```javascript
function unescapeHtml(data) {
  if (data.charCodeAt(0) === 34) {
    try { return JSON.parse(data); } catch (e) {}
  }
  return data;
}
// Apply to ALL HTML fetches:
var { data } = await $fetch.get(url, { headers });
data = unescapeHtml(data);
var $ = createCheerio().load(data);
```

**Key lesson:** If cheerio returns empty on a site that works in browser, check `data.charCodeAt(0) === 34`.

---

## haijiao.com — Preview vs Full Video

**Site:** https://haijiao.com (海角社區)

**Problem:** Videos only ~30 seconds long.

**Cause:** API returns `_preview.m3u8` with 1-2 segments. Full video exists as individual `.ts` files.

**CDN behavior (April 2026):**
- Default: 1 segment (~1.25s)
- Adding `?t=timestamp`: 25 segments (~31s) — max for free tier
- Full video requires paid membership

**Fix:** `videoUrl += '?t=' + Date.now();`

**Show duration:** `name: '視頻' + (a.video_time_length ? ' (' + Math.round(a.video_time_length/60) + '分鐘)' : '')`

---

## English-Only Title Translation

**Pattern:** Dictionary-based keyword replacement:
```javascript
const TITLE_MAP = {
  'married woman': '已婚少妇',
  'girlfriend': '女友',
  'original': '原创',
};
function translateTitle(en) {
  let title = en;
  for (const [k, v] of Object.entries(TITLE_MAP)) {
    title = title.replace(new RegExp(k, 'gi'), v);
  }
  return title;
}
```

**Limitation:** Only translates known keywords.

---

## HTTP → HTTPS Conversion

**Problem:** Video URL works from server but fails on Android XPTV app.

**Cause:** Android 9+ blocks cleartext HTTP by default.

**Fix:** `if (url.startsWith('http://')) url = url.replace('http://', 'https://');`

**Test both versions first** — some CDNs don't support HTTPS.

---

## Diagnosing "Can't Import" Failures

Script format is wrong. Compare with reference scripts in `~/.xptv-debugger/xptv-extensions/js/`.

**Common mistakes:**
- Using `function home(page)` instead of `getLocalInfo/getConfig/getCards`
- Using `function play(url)` returning `{ url }` instead of getTracks→getPlayinfo chain
- Missing `jsonify()` wrapper
- Tabs in comment metadata instead of `getConfig()` return

---

## Correct cheerio usage

```javascript
// ✅ createCheerio() returns module, .load(data) parses HTML
var $ = createCheerio().load(data);

// ❌ createCheerio(data) does NOT load HTML
```

## Scripts Storage

- **Primary:** `~/.xptv-scripts/` (synced to user device)
- **Reference:** `~/.xptv-debugger/xptv-extensions/js/` (repo scripts)
- **Sync after fix:** `cp ~/.xptv-scripts/X.xptv.js ~/.xptv-debugger/xptv-extensions/js/X.xptv.js`

## Example known-good script

```
~/.xptv-debugger/examples/static-demo.xptv.js
```

## Debugging scripts on inaccessible servers

1. `curl -sI URL` — verify accessibility
2. Use XPTV app as debugger with analysis scripts
3. Iterative refinement (broad → narrow)
4. Ask user for browser-side inspection
5. Compare with existing scripts in xptv-extensions repo
