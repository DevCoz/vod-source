# XPTV Script Templates

## Template 1: MacCMS API (XML)

适用于提供 MacCMS XML API 的站点

\`\`\`js
/**
 * [源名] XPTV 脚本
 * 站点: https://example.com
 * 类型: MacCMS API (XML)
 */

const UA = 'Mozilla/5.0 (iPhone; CPU iPhone OS 16_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.0 Mobile/15E148 Safari/604.1';
const SITE = 'https://example.com';
const API = \`\${SITE}/api.php/provide/vod/at/xml\`;

function parseXML(data) {
  const list = [];
  const videoRegex = /<video>([\\s\\S]*?)<\\/video>/g;
  let m;
  while ((m = videoRegex.exec(data)) !== null) {
    const c = m[1];
    const id = (c.match(/<id>(\\d+)<\\/id>/) || [])[1];
    const name = (c.match(/<name><!\\[CDATA\\[(.*?)\\]\\]><\\/name>/) || [])[1];
    const pic = (c.match(/<pic><!\\[CDATA\\[(.*?)\\]\\]><\\/pic>/) || [])[1] || '';
    if (id && name) {
      list.push({
        vod_id: id,
        vod_name: name,
        vod_pic: pic,
        ext: { id }
      });
    }
  }
  return list;
}

async function getLocalInfo() {
  return jsonify({ ver: 1, name: '源名', api: 'csp_xxx', type: 3 });
}

async function getConfig() {
  return jsonify({
    ver: 1, title: '源名', site: SITE,
    tabs: [
      { name: '全部', ext: { id: 'all' } },
      { name: '电影', ext: { id: '1' } },
      { name: '电视剧', ext: { id: '2' } }
    ]
  });
}

async function getCards(ext) {
  ext = argsify(ext);
  const { id, page = 1 } = ext;
  let url = \`\${API}?ac=list&pg=\${page}\`;
  if (id !== 'all') url += \`&tid=\${id}\`;
  const { data } = await $fetch.get(url, { headers: { 'User-Agent': UA, Referer: SITE + '/' } });
  return jsonify({ list: parseXML(data), page });
}

async function getTracks(ext) {
  ext = argsify(ext);
  const { id } = ext;
  const { data } = await $fetch.get(\`\${API}?ac=detail&ids=\${id}\`, { headers: { 'User-Agent': UA } });
  const tracksList = [];
  const ddRegex = /<dd flag="([^"]+)"><!\\[CDATA\\[([\\s\\S]*?)\\]\\]><\\/dd>/g;
  let dm;
  while ((dm = ddRegex.exec(data)) !== null) {
    const flag = dm[1];
    const tracks = dm[2].split('#').filter(e => e.trim()).map(ep => {
      const p = ep.split('$');
      return p.length >= 2 ? { name: p[0], ext: { url: p[1] } } : null;
    }).filter(Boolean);
    tracksList.push({ title: flag, tracks });
  }
  return jsonify({ list: tracksList });
}

async function getPlayinfo(ext) {
  ext = argsify(ext);
  return jsonify({ urls: [ext.url], headers: [{ 'User-Agent': UA }] });
}

async function search(ext) {
  ext = argsify(ext);
  const { wd, page = 1 } = ext;
  const { data } = await $fetch.get(\`\${API}?ac=list&wd=\${encodeURIComponent(wd)}&pg=\${page}\`, { headers: { 'User-Agent': UA } });
  return jsonify({ list: parseXML(data), page });
}
\`\`\`

---

## Template 2: HTML 爬取

适用于无 API、需解析 HTML 的站点

\`\`\`js
/**
 * [源名] XPTV 脚本
 * 站点: https://example.com
 * 类型: HTML 爬取
 */

const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36';
const SITE = 'https://example.com';

async function getLocalInfo() {
  return jsonify({ ver: 1, name: '源名', api: 'csp_xxx' });
}

async function getConfig() {
  return jsonify({
    ver: 1, title: '源名', site: SITE,
    tabs: [{ name: '首页', ext: { id: 'home' } }]
  });
}

async function getCards(ext) {
  ext = argsify(ext);
  const { id, page = 1 } = ext;
  let url = SITE + '/';
  if (page > 1) url += \`?page=\${page}\`;

  const { data } = await $fetch.get(url, { headers: { 'User-Agent': UA } });
  const cheerio = createCheerio();
  const $ = cheerio.load(data);
  const list = [];

  $('article.bs').each((i, el) => {
    const $el = $(el);
    const href = $el.find('.bsx a').first().attr('href');
    const name = $el.find('h2').text().trim();
    if (href && name) {
      list.push({
        vod_id: href,
        vod_name: name,
        vod_pic: $el.find('img').attr('src') || '',
        vod_remarks: $el.find('.epx').first().text().trim() || '',
        ext: { url: href }
      });
    }
  });

  return jsonify({ list });
}

async function getTracks(ext) {
  ext = argsify(ext);
  const { url } = ext;
  const { data } = await $fetch.get(url);
  const cheerio = createCheerio();
  const $ = cheerio.load(data);
  const tracks = [];

  $('.eplister a').each((i, el) => {
    const $el = $(el);
    tracks.push({ name: $el.text().trim(), ext: { url: $el.attr('href') } });
  });

  if (!tracks.length) tracks.push({ name: '播放', ext: { url } });
  return jsonify({ list: [{ title: '默认线路', tracks }] });
}

async function getPlayinfo(ext) {
  ext = argsify(ext);
  const { url } = ext;
  const { data } = await $fetch.get(url);
  let playUrl = '';

  // 提取 iframe 中 base64 编码的播放地址
  const iframeMatch = data.match(/<iframe[^>]+src=["']([^"']+)["']/i);
  if (iframeMatch && iframeMatch[1].includes('url=')) {
    const b64 = iframeMatch[1].split('url=')[1].split('&')[0];
    const CryptoJS = createCryptoJS();
    playUrl = CryptoJS.enc.Utf8.stringify(CryptoJS.enc.Base64.parse(b64));
  }

  return jsonify({ urls: playUrl ? [playUrl] : [], headers: [{ Referer: url }] });
}

async function search(ext) {
  ext = argsify(ext);
  const { text, page = 1 } = ext;
  const { data } = await $fetch.get(\`\${SITE}/?s=\${encodeURIComponent(text)}&paged=\${page}\`);
  const cheerio = createCheerio();
  const $ = cheerio.load(data);
  const list = [];

  $('article.bs').each((i, el) => {
    const $el = $(el);
    const href = $el.find('.bsx a').first().attr('href');
    const name = $el.find('h2').text().trim();
    if (href && name) {
      list.push({
        vod_id: href, vod_name: name,
        vod_pic: $el.find('img').attr('src') || '',
        ext: { url: href }
      });
    }
  });

  return jsonify({ list });
}
\`\`\`

---

## Template 3: 网盘源 (Cloud Drive)

适用于网盘分享链接聚合

\`\`\`js
/**
 * [源名] XPTV 网盘脚本
 * 类型: 网盘源 (夸克/阿里/115/天翼)
 */

const UA = 'Mozilla/5.0 (iPhone; CPU iPhone OS 16_0 like Mac OS X) AppleWebKit/605.1.15';

function detectPanType(url) {
  if (url.includes('quark.cn')) return 'quark';
  if (url.includes('alipan.com') || url.includes('aliyundrive.com')) return 'ali';
  if (url.includes('115.com')) return '115';
  if (url.includes('189.cn')) return 'tianyi';
  return 'unknown';
}

async function getLocalInfo() {
  return jsonify({ ver: 1, name: '网盘源名', api: 'csp_pan_xxx' });
}

async function getConfig() {
  return jsonify({
    ver: 1, title: '网盘源名', site: '',
    tabs: [{ name: '全部', ext: { id: 'all' } }]
  });
}

async function getCards(ext) {
  ext = argsify(ext);
  const { data } = await $fetch.get('https://api.example.com/list', { headers: { 'User-Agent': UA } });
  const json = argsify(data);
  const list = json.items.map(item => ({
    vod_id: item.id,
    vod_name: item.title,
    vod_pic: item.cover || '',
    vod_remarks: item.size || '',
    ext: { id: item.id }
  }));
  return jsonify({ list });
}

async function getTracks(ext) {
  ext = argsify(ext);
  const { id } = ext;
  const { data } = await $fetch.get(\`https://api.example.com/detail?id=\${id}\`);
  const json = argsify(data);

  const tracks = json.links.map((link, i) => ({
    name: \`第\${i + 1}集\`,
    pan: link.url,
    ext: {}
  }));

  return jsonify({
    list: [{ title: '网盘线路', tracks }],
    info: { vod_desc: json.desc || '' }
  });
}

async function getPlayinfo(ext) {
  return jsonify({ urls: [] });
}

async function search(ext) {
  ext = argsify(ext);
  const { text } = ext;
  const { data } = await $fetch.get(\`https://api.example.com/search?kw=\${encodeURIComponent(text)}\`);
  const json = argsify(data);
  const list = json.results.map(item => ({
    vod_id: item.id,
    vod_name: item.title,
    vod_pic: item.cover || '',
    ext: { id: item.id }
  }));
  return jsonify({ list });
}
\`\`\`

---

## Template 4: JSON API

适用于返回 JSON 数据的 API 站点

\`\`\`js
/**
 * [源名] XPTV 脚本
 * 站点: https://api.example.com
 * 类型: JSON API
 */

const SITE = 'https://api.example.com';
const UA = 'Mozilla/5.0 (iPhone; CPU iPhone OS 16_0 like Mac OS X) AppleWebKit/605.1.15';

async function getLocalInfo() {
  return jsonify({ ver: 1, name: '源名', api: 'csp_json_xxx', type: 3 });
}

async function getConfig() {
  return jsonify({
    ver: 1, title: '源名', site: SITE,
    tabs: [
      { name: '全部', ext: { id: 'all' } },
      { name: '电影', ext: { id: '1' } },
      { name: '电视剧', ext: { id: '2' } }
    ]
  });
}

async function getCards(ext) {
  ext = argsify(ext);
  const { id, page = 1 } = ext;
  let url = \`\${SITE}/videos?page=\${page}\`;
  if (id !== 'all') url += \`&category=\${id}\`;
  const { data } = await $fetch.get(url, { headers: { 'User-Agent': UA } });
  const json = argsify(data);
  const list = json.data.map(item => ({
    vod_id: String(item.id),
    vod_name: item.title,
    vod_pic: item.thumbnail || '',
    vod_remarks: item.episode_count ? \`全\${item.episode_count}集\` : '',
    ext: { id: String(item.id) }
  }));
  return jsonify({ list, page });
}

async function getTracks(ext) {
  ext = argsify(ext);
  const { id } = ext;
  const { data } = await $fetch.get(\`\${SITE}/videos/\${id}\`, { headers: { 'User-Agent': UA } });
  const json = argsify(data);
  const tracks = (json.episodes || []).map((ep, i) => ({
    name: ep.title || \`第\${i + 1}集\`,
    ext: { url: ep.url || ep.play_url }
  }));
  if (!tracks.length) tracks.push({ name: '播放', ext: { url: json.play_url || '' } });
  return jsonify({
    list: [{ title: '默认线路', tracks }],
    info: { vod_pic: json.cover || '', vod_desc: json.description || '' }
  });
}

async function getPlayinfo(ext) {
  ext = argsify(ext);
  const { url } = ext;
  if (!url) return jsonify({ urls: [] });
  const { data } = await $fetch.get(url, { headers: { 'User-Agent': UA } });
  const json = argsify(data);
  return jsonify({
    urls: json.urls || [json.url] || [],
    headers: json.headers || [{ 'User-Agent': UA }]
  });
}

async function search(ext) {
  ext = argsify(ext);
  const { text, page = 1 } = ext;
  const { data } = await $fetch.get(\`\${SITE}/search?keyword=\${encodeURIComponent(text)}&page=\${page}\`, {
    headers: { 'User-Agent': UA }
  });
  const json = argsify(data);
  const list = (json.data || json.results || []).map(item => ({
    vod_id: String(item.id),
    vod_name: item.title,
    vod_pic: item.thumbnail || item.cover || '',
    vod_remarks: item.episode_count ? \`全\${item.episode_count}集\` : '',
    ext: { id: String(item.id) }
  }));
  return jsonify({ list, page });
}
\`\`\`

---

## Template 5: HTML 爬取 + 防火墙过盾 (Anti-bot Bypass)

适用于有 Cloudflare / 自定义人机验证的站点。核心思路：首次请求检测验证页 → 提取 token → 自定义加密 → POST 验证接口 → 带 cookie 重试。

\`\`\`js
/**
 * [源名] XPTV 脚本 — 带防火墙过盾
 * 站点: https://example.com
 * 类型: HTML 爬取 + 自定义反爬
 */

const CryptoJS = createCryptoJS();
const cheerio = createCheerio();
const UA = 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_0 like Mac OS X) AppleWebKit/605.1.15';
const SITE = 'https://example.com';

// ===== Cookie Jar（手动管理 Set-Cookie）=====
function createCookieJar() { return {}; }

function mergeSetCookie(jar, setCookieHeaders) {
  const values = Array.isArray(setCookieHeaders) ? setCookieHeaders : [setCookieHeaders];
  for (const raw of values) {
    const first = String(raw).split(';')[0];
    const idx = first.indexOf('=');
    if (idx <= 0) continue;
    jar[first.slice(0, idx).trim()] = first.slice(idx + 1).trim();
  }
}

function cookieStr(jar) {
  return Object.entries(jar).map(([k, v]) => \`\${k}=\${v}\`).join('; ');
}

// ===== 自定义加密（示例：字符位移 + Base64）=====
function firewallEncrypt(input) {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  let result = '';
  for (const ch of String(input)) {
    const idx = chars.indexOf(ch);
    result += idx === -1 ? ch : chars[(idx + 3) % 62];
  }
  return CryptoJS.enc.Base64.stringify(CryptoJS.enc.Utf8.parse(result));
}

// ===== 带防火墙检测的请求 =====
async function requestWithBypass(url) {
  const headers = {
    'User-Agent': UA,
    Referer: SITE + '/',
    Accept: 'text/html,*/*',
  };

  const resp = await $fetch.get(url, { headers, timeout: 20000 });
  let text = resp.data || '';

  // 检测是否命中验证页（根据实际站点调整关键词）
  if (!/verifyBox|人机验证|challenge-form/.test(text)) {
    return text;
  }

  // 提取验证 token（根据实际 HTML 调整正则）
  const tokenMatch = text.match(/var\\s+token\\s*=\\s*encrypt\\("([^"]+)"\\)/i);
  if (!tokenMatch) return text;

  const jar = createCookieJar();
  mergeSetCookie(jar, resp.headers?.['set-cookie'] || []);

  // 构造验证请求
  const value = firewallEncrypt(url);
  const token = firewallEncrypt(tokenMatch[1]);

  const verifyResp = await $fetch.post(\`\${SITE}/verify.php\`, 
    \`value=\${encodeURIComponent(value)}&token=\${encodeURIComponent(token)}\`, {
    headers: {
      Referer: url, Origin: SITE,
      'Content-Type': 'application/x-www-form-urlencoded',
      'User-Agent': UA,
      ...(cookieStr(jar) ? { Cookie: cookieStr(jar) } : {}),
    },
  });

  mergeSetCookie(jar, verifyResp.respHeaders?.['set-cookie'] || []);

  // 带 cookie 二次请求
  const solved = cookieStr(jar);
  const retry = await $fetch.get(url, {
    headers: { ...headers, ...(solved ? { Cookie: solved } : {}) },
  });
  return retry.data || '';
}

// ===== 六个接口（使用 requestWithBypass 替代直接 $fetch）=====
async function getLocalInfo() {
  return jsonify({ ver: 1, name: '源名', api: 'csp_xxx' });
}

async function getConfig() {
  const html = await requestWithBypass(SITE);
  const $ = cheerio.load(html);
  const tabs = [];
  $('nav a').each((_, el) => {
    const href = $(el).attr('href') || '';
    const m = href.match(/\\/type\\/(\\d+)\\.html/);
    if (m) tabs.push({ name: $(el).text().trim(), ext: { id: m[1] } });
  });
  if (!tabs.length) tabs.push({ name: '全部', ext: { id: 'all' } });
  return jsonify({ ver: 1, title: '源名', site: SITE, tabs });
}

async function getCards(ext) {
  ext = argsify(ext);
  const { id, page = 1 } = ext;
  const url = \`\${SITE}/type/\${id}-\${page}.html\`;
  const html = await requestWithBypass(url);
  const $ = cheerio.load(html);
  const list = [];

  $('.movie-item').each((_, el) => {
    const $el = $(el);
    const $a = $el.find('a').first();
    const href = $a.attr('href');
    const name = $a.attr('title') || $a.text().trim();
    if (href && name) {
      list.push({
        vod_id: href, vod_name: name,
        vod_pic: $el.find('img').attr('data-original') || '',
        vod_remarks: $el.find('.note').text().trim(),
        ext: { url: href },
      });
    }
  });
  return jsonify({ list, page });
}

// getTracks / getPlayinfo / search 同 HTML 爬取模板，请求函数改用 requestWithBypass
async function getTracks(ext) { /* ...同模板2，用 requestWithBypass ... */ }
async function getPlayinfo(ext) { /* ... */ }
async function search(ext) { /* ... */ }
\`\`\`

### 关键点

| 技术 | 说明 |
|------|------|
| Cookie Jar | \`$fetch\` 不自动跟踪 cookie 时，手动解析 \`Set-Cookie\` 头 |
| 验证检测 | 用正则匹配验证页关键词（如 \`verifyBox\`、\`challenge-form\`） |
| 自定义加密 | 每个站点的防火墙加密逻辑不同，需逆向前端 JS |
| 重试逻辑 | 验证成功后带 cookie 二次请求原始 URL |

---

## Template 6: 直播源 + 多 CDN × 多画质

适用于直播平台（斗鱼、虎牙等），核心特点：实时流地址、多 CDN 线路、多画质切换、加密签名。

\`\`\`js
/**
 * [源名] XPTV 直播脚本
 * 站点: https://live.example.com
 * 类型: 直播源 + CDN/画质矩阵
 */

const CryptoJS = createCryptoJS();
const UA = 'Mozilla/5.0 (iPhone; CPU iPhone OS 14_0 like Mac OS X) AppleWebKit/605.1.15';
const SITE = 'https://live.example.com';

// ===== 工具：随机设备 ID =====
function randHex(len) {
  return Array.from({ length: len }, () => Math.floor(Math.random() * 16).toString(16)).join('');
}

// ===== 工具：对象转 query string =====
function toQS(obj) {
  return Object.keys(obj)
    .filter(k => obj[k] != null && obj[k] !== '')
    .map(k => \`\${k}=\${obj[k]}\`)
    .join('&');
}

// ===== 迭代 MD5 签名（示例）=====
async function getSignedParams(roomId) {
  const did = randHex(32);
  const tt = Math.floor(Date.now() / 1000);

  const encRes = await $fetch.get(\`\${SITE}/api/encrypt?did=\${did}\`, {
    headers: { Referer: \`\${SITE}/\${roomId}\` },
  });
  const sec = argsify(encRes.data).data;

  let current = sec.rand_str;
  for (let i = 0; i < sec.enc_time; i++) {
    current = CryptoJS.MD5(current + sec.key).toString();
  }
  const auth = CryptoJS.MD5(current + sec.key + roomId + tt).toString();

  return { v: '22032021', did, tt, auth, enc_data: sec.enc_data };
}

async function getLocalInfo() {
  return jsonify({ ver: 1, name: '直播源名', api: 'csp_live_xxx', type: 4 });
}

async function getConfig() {
  return jsonify({
    ver: 1, title: '直播源名', site: SITE,
    tabs: [
      { name: '热门', ext: { id: 'hot' }, ui: 1 },
      { name: '游戏', ext: { id: 'game' }, ui: 1 },
      { name: '娱乐', ext: { id: 'ent' }, ui: 1 },
    ],
  });
}

async function getCards(ext) {
  ext = argsify(ext);
  const { id, page = 1 } = ext;
  const { data } = await $fetch.get(\`\${SITE}/api/rooms?type=\${id}&page=\${page}\`, {
    headers: { 'User-Agent': UA },
  });
  const json = argsify(data);
  const list = json.data.list.map(e => ({
    vod_id: String(e.rid),
    vod_name: e.roomName,
    vod_pic: e.roomSrc,
    vod_duration: e.isLive ? \`🔴 \${e.hn}\` : '未开播',
    ext: { id: String(e.rid) },
  }));
  return jsonify({ list });
}

async function getTracks(ext) {
  ext = argsify(ext);
  const { id } = ext;
  const lists = [];

  const baseParams = await getSignedParams(id);
  const signHeaders = {
    Referer: \`\${SITE}/\${id}\`,
    'Content-Type': 'application/x-www-form-urlencoded',
  };

  const firstRes = await $fetch.post(
    \`\${SITE}/api/play/\${id}\`,
    toQS({ ...baseParams, rate: '0' }),
    { headers: signHeaders },
  );
  const firstData = argsify(firstRes.data).data;

  const qualities = (firstData.multirates || [])
    .slice(0, 5)
    .map(r => ({ name: r.name, rate: r.rate }));
  if (!qualities.length) {
    qualities.push({ name: '原画', rate: 0 }, { name: '高清', rate: 2 });
  }

  const cdns = (firstData.cdnsWithName || []).slice(0, 3);
  const cdnList = cdns.length
    ? cdns
    : [{ name: '默认', cdn: firstData.rtmp_cdn || 'default' }];

  for (const cdn of cdnList) {
    const line = { title: cdn.name, tracks: [] };
    for (const q of qualities) {
      try {
        const res = await $fetch.post(
          \`\${SITE}/api/play/\${id}\`,
          toQS({ ...baseParams, rate: q.rate, cdn: cdn.cdn }),
          { headers: signHeaders },
        );
        const d = argsify(res.data);
        if (d.error === 0) {
          const url = d.data.rtmp_url
            ? \`\${d.data.rtmp_url}/\${d.data.rtmp_live}\`
            : d.data.url || d.data.live_url || '';
          if (url) {
            line.tracks.push({
              name: q.name,
              ext: { id, url },
            });
          }
        }
      } catch (e) {
        console.log(\`[\${cdn.name}] \${q.name} failed\`);
      }
    }
    if (line.tracks.length) lists.push(line);
  }

  return jsonify({ list: lists });
}

async function getPlayinfo(ext) {
  ext = argsify(ext);
  const { id, url } = ext;
  return jsonify({
    urls: [url],
    headers: [{
      'User-Agent': UA,
      Referer: \`\${SITE}/\${id}\`,
      'Accept-Encoding': 'identity',
    }],
  });
}

async function search(ext) {
  ext = argsify(ext);
  const { text, page = 1 } = ext;
  const did = randHex(32);
  const { data } = await $fetch.get(
    \`\${SITE}/api/search?kw=\${encodeURIComponent(text)}&page=\${page}\`,
    { headers: { 'User-Agent': UA, Cookie: \`did=\${did}\` } },
  );
  const json = argsify(data);
  const list = json.data.results
    .filter(e => e.isLive)
    .map(e => ({
      vod_id: String(e.rid),
      vod_name: e.roomName,
      vod_pic: e.roomSrc,
      vod_duration: e.nickName,
      ext: { id: String(e.rid) },
    }));
  return jsonify({ list });
}
\`\`\`

### 关键点

| 技术 | 说明 |
|------|------|
| 迭代 MD5 签名 | N 轮 \`MD5(current + key)\` 后再拼接 room ID 和时间戳生成 auth |
| 随机设备 ID | \`randHex(32)\` 模拟设备指纹，避免单连接限制 |
| CDN × 画质矩阵 | 先获取 \`cdnsWithName\` + \`multirates\`，双重循环逐个请求 |
| 直播流地址 | 通常为 \`rtmp_url + '/' + rtmp_live\` 或独立 \`url\`/\`live_url\` |
| 未开播处理 | \`isLive\` 为 false 时返回提示而非空列表 |
| getPlayinfo 直传 | 直播流地址不需要二次解密，直接返回 URL + Referer 头 |

---


---

## Template 6 进阶：实战补充

基于虎牙等平台的真实开发经验，补充以下实战模式。

### 1. HTML 嵌入流数据提取

许多直播平台不在 API 返回流地址，而是嵌入 HTML 页面的 JS 变量中（如 `window.HNF_GLOBAL_INIT`）。

```js
/**
 * 模式A: window.XXX = {...}; 形式提取
 * 适用: 虎牙 HNF_GLOBAL_INIT、B站 __INITIAL_STATE__ 等
 */
function extractWindowVar(html, varName) {
  const re = new RegExp(`window\\.${varName}\\s*=\\s*(.*?)</script>`, 's');
  const m = html.match(re);
  if (!m) return null;
  let s = m[1].trim().replace(/;\s*$/, '');
  s = s.replace(/function\s*\([^}]*\}/g, '""');   // 清理 function
  s = s.replace(/\\u([0-9A-Fa-f]{4})/g, (_, h) => String.fromCharCode(parseInt(h, 16)));
  try { return JSON.parse(s); } catch { return null; }
}

/**
 * 模式B: 大括号/方括号计数法
 * 比正则更可靠，适合深层嵌套 JSON
 */
function extractByCount(html, marker, type) {
  const idx = html.indexOf(marker);
  if (idx === -1) return null;
  const open = type === 'array' ? '[' : '{';
  const close = type === 'array' ? ']' : '}';
  const start = html.lastIndexOf(open, idx);
  if (start === -1) return null;
  let depth = 0;
  for (let i = start; i < html.length && i < start + 50000; i++) {
    if (html[i] === open) depth++;
    if (html[i] === close) depth--;
    if (depth === 0) {
      try { return JSON.parse(html.substring(start, i + 1)); }
      catch { return null; }
    }
  }
  return null;
}
```

### 2. 直播状态判断

```js
// eLiveStatus: 2=直播中, 3=回放/录像, 其他=离线
function resolveLiveState(roomInfo) {
  const s = roomInfo.eLiveStatus || 0;
  if (s === 2) return { state: 'live', info: roomInfo.tLiveInfo };
  if (s === 3) return { state: 'replay', info: roomInfo.tReplayInfo || roomInfo.tRecentLive };
  return { state: 'offline', info: roomInfo.tRecentLive };
}
```

### 3. 动态 Anticode 构建

预签名 URL 会过期（30-60秒）。正确做法是从 `fm` 字段动态计算 `wsSecret`：

```js
function buildAntiCode(streamName, uid, antiCode) {
  const p = parseQuery(antiCode);
  if (!p.fm) return antiCode;

  const ctype = p.ctype || 'huya_pc_exe';
  const t = parseInt(p.t || '0') || 0;
  const isWap = t === 103;
  const seqId = uid + Date.now();
  const hash = CryptoJS.MD5(`${seqId}|${ctype}|${t}`).toString();

  // PC端 UID 循环左移 8 位
  const convUid = isWap ? uid : (((uid << 8) | (uid >>> 24)) >>> 0);
  const fm = CryptoJS.enc.Utf8.stringify(CryptoJS.enc.Base64.parse(p.fm));
  const prefix = fm.split('_')[0] || '';

  const wsSecret = CryptoJS.MD5(`${prefix}_${convUid}_${streamName}_${hash}_${p.wsTime}`).toString();

  return [
    `wsSecret=${wsSecret}`, `wsTime=${p.wsTime}`, `seqid=${seqId}`,
    `ctype=${ctype}`, `ver=1`, `fs=${p.fs || ''}`,
    `fm=${encodeURIComponent(p.fm)}`, `t=${t}`,
    isWap ? `uid=${uid}` : `u=${convUid}`,
  ].join('&');
}
```

### 4. 双协议输出

同一画质同时提供 FLV（延迟低）和 HLS（兼容好）：

```js
for (const br of qualityList) {
  const ratio = br.iBitRate > 0 ? `&ratio=${br.iBitRate}` : '';
  // FLV
  tracks.push({
    name: br.sDisplayName,
    ext: { url: `${stream.sFlvUrl}/${stream.sStreamName}.flv?${flvAnti}${ratio}&codec=264`, type: 'flv' }
  });
  // HLS
  tracks.push({
    name: `${br.sDisplayName} HLS`,
    ext: { url: `${stream.sHlsUrl}/${stream.sStreamName}.${stream.sHlsUrlSuffix || 'm3u8'}?${hlsAnti}${ratio}`, type: 'm3u8' }
  });
}
```

### 5. 搜索 API 对照表

| 平台 | 搜索 URL | 响应路径 |
|------|---------|---------|
| 虎牙 | `search.cdn.huya.com/?m=Search&do=getSearchContent&q=X&typ=-5` | `response["3"].docs` |
| 斗鱼 | `search.douyu.com/api/search?keyword=X` | `data.room` |
| B站 | `api.bilibili.com/x/web-interface/search/type?search_type=live` | `data.result.live_room` |

## Template 7: 多层加密解密的 getPlayinfo

适用于播放地址经过多次加密的站点（cupfox 类型）。核心思路：播放页提取 vid → POST API → 根据 urlmode 选择解码器。

\`\`\`js
/**
 * getPlayinfo: 多层加密解密
 * 适用场景：播放页有 player_aaaa 全局变量，API 返回加密 URL
 */

const CryptoJS = createCryptoJS();
const cheerio = createCheerio();
const UA = 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_0 like Mac OS X) AppleWebKit/605.1.15';
const SITE = 'https://example.com';

// ===== 解码器 1：字符映射替换 =====
const Decoder1 = {
  sign(encodedStr) {
    try {
      const decodedRaw = this.xorDecode(encodedStr);
      const parts = decodedRaw.split('/');
      const cipherMap = JSON.parse(base64(parts[0]));
      const plainMap = JSON.parse(base64(parts[1]));
      const path = base64(parts.slice(2).join('/'));
      return this.deString(cipherMap, plainMap, path);
    } catch { return ''; }
  },
  xorDecode(str) {
    const decoded = base64(str);
    const key = CryptoJS.MD5('secret_key').toString();
    let code = '';
    for (let i = 0; i < decoded.length; i++) {
      code += String.fromCharCode(decoded.charCodeAt(i) ^ key.charCodeAt(i % key.length));
    }
    return base64(code);
  },
  deString(cipherList, plainList, text) {
    let result = '';
    for (const ch of text) {
      if (/[a-zA-Z]/.test(ch) && plainList.includes(ch)) {
        const idx = cipherList.indexOf(ch);
        result += idx !== -1 && plainList[idx] ? plainList[idx] : ch;
      } else {
        result += ch;
      }
    }
    return result;
  },
};

// ===== 解码器 2：字典位移 =====
function decoder2(encoded) {
  if (!encoded) return '';
  const dict = 'PXhw7UT1B0a9kQDKZsjIASmOezxYG4CHo5Jyfg2b8FLpEvRr3WtVnlqMidu6cN';
  const lookup = {};
  for (let i = 0; i < dict.length; i++) {
    lookup[dict[i]] = dict[(i + 59) % dict.length];
  }
  const raw = base64(encoded);
  let res = '';
  for (let i = 1; i < raw.length; i += 3) {
    res += lookup[raw[i]] || raw[i];
  }
  return res;
}

// ===== 工具 =====
function base64(s) {
  return CryptoJS.enc.Utf8.stringify(CryptoJS.enc.Base64.parse(s.replace(/[\\r\\n]/g, '')));
}

// ===== 大括号计数法提取 script 中的 JSON =====
function extractPlayerJSON(html, varName) {
  const idx = html.indexOf(varName);
  if (idx === -1) return null;
  const braceStart = html.indexOf('{', idx);
  if (braceStart === -1) return null;
  let depth = 0;
  for (let i = braceStart; i < html.length && i < braceStart + 5000; i++) {
    if (html[i] === '{') depth++;
    if (html[i] === '}') depth--;
    if (depth === 0) {
      try { return JSON.parse(html.substring(braceStart, i + 1)); }
      catch { return null; }
    }
  }
  return null;
}

// ===== getPlayinfo 完整实现 =====
async function getPlayinfo(ext) {
  ext = argsify(ext);
  const { url } = ext;
  if (!url) return jsonify({ urls: [], headers: [] });

  try {
    const playUrl = url.startsWith('http') ? url : SITE + url;
    const { data } = await $fetch.get(playUrl, { headers: { 'User-Agent': UA } });
    const html = data || '';

    // Step 1: 从 script 标签提取 player_aaaa
    const playerData = extractPlayerJSON(html, 'player_aaaa');
    if (!playerData?.url) return jsonify({ urls: [], headers: [] });

    const vid = playerData.url;

    // Step 2: POST API 获取加密地址
    const apiResp = await $fetch.post(\`\${SITE}/api/play.php\`, \`vid=\${encodeURIComponent(vid)}\`, {
      headers: {
        'User-Agent': UA,
        Referer: \`\${SITE}/player.php?vid=\${vid}\`,
        'Content-Type': 'application/x-www-form-urlencoded',
      },
    });
    const json = typeof apiResp.data === 'string' ? JSON.parse(apiResp.data) : apiResp.data;

    if (json?.code !== 200 || !json.data?.url) {
      return jsonify({ urls: [], headers: [] });
    }

    // Step 3: 根据 urlmode 选择解码器
    let realUrl = json.data.url;
    if (json.data.urlmode === 1) {
      realUrl = Decoder1.sign(realUrl);
    } else if (json.data.urlmode === 2) {
      realUrl = decoder2(realUrl);
    }

    if (!realUrl) return jsonify({ urls: [], headers: [] });

    return jsonify({
      urls: [realUrl],
      headers: [{ 'User-Agent': UA, Referer: playUrl }],
    });
  } catch (e) {
    console.error('getPlayinfo error:', e.message);
    return jsonify({ urls: [], headers: [] });
  }
}
\`\`\`

### 关键点

| 技术 | 说明 |
|------|------|
| 大括号计数法 | 从 \`<script>\` 中提取 \`var xxx = {...}\` 形式的 JSON，比正则更可靠 |
| urlmode 分发 | 不同 \`urlmode\` 对应不同解码器，先获取再判断 |
| XOR + Base64 双重解码 | 常见模式：Base64 解码 → XOR 异或 → 再 Base64 解码 |
| 字符映射替换 | 两个字符串列表（cipher → plain），逐字符查表替换 |
| 字典位移 | 固定字典表，按固定偏移量查表还原字符 |
| try-catch 兜底 | getPlayinfo 是最容易出错的接口，必须有异常兜底返回 \`{ urls: [] }\` |


## Template 8: iframe 嵌套播放器 + AES Token 解密

适用于播放地址经过多层嵌套的站点（iframe → POST API → AES 解密 token）。

```js
/**
 * [源名] XPTV 脚本 — iframe 嵌套播放器
 * 站点: https://example.com
 * 类型: HTML 爬取 + iframe 嵌套播放器
 */

const CryptoJS = createCryptoJS()
const cheerio = createCheerio()
const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
const SITE = 'https://example.com'
const HEADERS = {
  'User-Agent': UA,
  Referer: SITE + '/',
  Accept: 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
}

// ===== AES Token 解密（预计算 key）=====
// ⚠️ 每个站点的 key 派生方式不同，需要逆向前端 JS
const AES_KEY = CryptoJS.enc.Utf8.parse('your-aes-key-here')
const AES_IV = CryptoJS.enc.Utf8.parse('your-aes-iv-here')

function decryptToken(encToken) {
  try {
    const decrypted = CryptoJS.AES.decrypt(encToken, AES_KEY, {
      iv: AES_IV,
      mode: CryptoJS.mode.CBC,
      padding: CryptoJS.pad.Pkcs7,
    })
    return decrypted.toString(CryptoJS.enc.Utf8)
  } catch (e) {
    return ''
  }
}

// ===== 大括号计数法提取 player_aaaa =====
function extractPlayerJSON(html) {
  const idx = html.indexOf('player_aaaa')
  if (idx === -1) return null
  const match = html.substring(idx).match(/var\s+player_aaaa\s*=\s*(\{[^;]+?\})\s*;?\s*<\/script>/)
  if (!match) return null
  try { return JSON.parse(match[1]) } catch { return null }
}

async function getLocalInfo() {
  return jsonify({ ver: 1, name: '源名', api: 'csp_xxx', type: 3 })
}

async function getConfig() {
  return jsonify({
    ver: 1, title: '源名', site: SITE,
    tabs: [
      { name: '分类1', ext: { id: 'cat1' } },
      { name: '分类2', ext: { id: 'cat2' } },
    ],
  })
}

async function getCards(ext) {
  ext = argsify(ext)
  const { id, page = 1 } = ext
  const url = page === 1
    ? `${SITE}/type/${id}.html`
    : `${SITE}/type/${id}_${page}.html`

  try {
    const { data } = await $fetch.get(url, { headers: HEADERS })
    const $ = cheerio.load(data)
    const list = []

    $('.video-item').each((_, el) => {
      const $el = $(el)
      const $a = $el.find('a').first()
      const href = $a.attr('href') || ''
      const idMatch = href.match(/\/detail\/(\d+)\.html/)
      if (!idMatch) return

      list.push({
        vod_id: idMatch[1],
        vod_name: $el.find('.title').text().trim(),
        vod_pic: $el.find('img').attr('data-src') || '',
        vod_remarks: $el.find('.label').first().text().trim(),
        ext: { id: idMatch[1] },
      })
    })

    return jsonify({ list, page })
  } catch (e) {
    return jsonify({ list: [], page })
  }
}

async function getTracks(ext) {
  ext = argsify(ext)
  const { id } = ext

  try {
    const { data } = await $fetch.get(`${SITE}/detail/${id}.html`, { headers: HEADERS })
    const $ = cheerio.load(data)
    const lists = []

    // 线路名
    const lineNames = []
    $('.tab-item').each((_, el) => {
      const name = $(el).text().trim()
      if (name) lineNames.push(name)
    })

    // 剧集列表
    $('.scroll-content').each((i, el) => {
      const lineName = lineNames[i] || `线路${i + 1}`
      const tracks = []
      $(el).find('a').each((_, a) => {
        const href = $(a).attr('href') || ''
        const name = $(a).text().trim()
        if (href && name) {
          tracks.push({ name, ext: { url: href } })
        }
      })
      if (tracks.length) lists.push({ title: lineName, tracks })
    })

    return jsonify({ list: lists })
  } catch (e) {
    return jsonify({ list: [] })
  }
}

async function getPlayinfo(ext) {
  try {
    ext = argsify(ext)
    const { url } = ext
    if (!url) return jsonify({ urls: [] })

    const playUrl = SITE + url
    const { data } = await $fetch.get(playUrl, { headers: HEADERS })

    // 提取 player_aaaa
    const player = extractPlayerJSON(data)
    if (!player || !player.url) return jsonify({ urls: [] })

    const vid = player.url
    const from = player.from || ''

    // 某些源直接返回 m3u8
    if (vid.startsWith('http') && vid.includes('.m3u8')) {
      return jsonify({
        urls: [vid],
        headers: [{ 'User-Agent': UA, Referer: playUrl }],
      })
    }

    // 根据 from 类型构造 iframe URL
    // ⚠️ 每个站点的映射不同，需要实际分析
    const iframeUrl = `https://player.example.com/play.php?id=${vid}&referer=${encodeURIComponent(playUrl)}`

    // 获取 iframe 页面
    const { data: iframeHtml } = await $fetch.get(iframeUrl, {
      headers: {
        'User-Agent': UA,
        Referer: SITE + '/',
        'sec-fetch-dest': 'iframe',
        'sec-fetch-mode': 'navigate',
      },
    })

    // 动态提取 POST 端点（$.post("xxx.php")）
    const postMatch = iframeHtml.match(/\$\.post\("([^"]+)"/)
    const postEndpoint = postMatch ? postMatch[1] : 'api.php'

    // 提取 vid, t, token
    const vidMatch = iframeHtml.match(/var\s+vid\s*=\s*"([^"]+)"/)
    const tMatch = iframeHtml.match(/var\s+t\s*=\s*"([^"]+)"/)
    const tokenMatch = iframeHtml.match(/var\s+token\s*=\s*"([^"]+)"/)

    if (vidMatch && tMatch && tokenMatch) {
      const decryptedToken = decryptToken(tokenMatch[1])
      if (decryptedToken) {
        const postBody = `vid=${encodeURIComponent(vidMatch[1])}&t=${tMatch[1]}&token=${encodeURIComponent(decryptedToken)}&act=0&play=1`

        const { data: respData } = await $fetch.post(
          `https://player.example.com/${postEndpoint}`,
          postBody,
          {
            headers: {
              'User-Agent': UA,
              Referer: iframeUrl,
              'Content-Type': 'application/x-www-form-urlencoded',
              Origin: 'https://player.example.com',
              'X-Requested-With': 'XMLHttpRequest',
            },
          }
        )

        const result = typeof respData === 'string' ? JSON.parse(respData) : respData
        if (result.code === 200 && result.url) {
          const headers = { 'User-Agent': UA }
          if (result.referer !== 'never') headers.Referer = playUrl
          return jsonify({ urls: [result.url], headers: [headers] })
        }
      }
    }

    return jsonify({ urls: [] })
  } catch (e) {
    console.error('getPlayinfo error:', e)
    return jsonify({ urls: [] })
  }
}

async function search(ext) {
  ext = argsify(ext)
  const { text, wd, page = 1 } = ext
  const keyword = text || wd || ''
  if (!keyword) return jsonify({ list: [], page })

  try {
    const url = `${SITE}/vod/search.html?wd=${encodeURIComponent(keyword)}`
    const { data } = await $fetch.get(url, { headers: HEADERS })
    const $ = cheerio.load(data)
    const list = []

    $('.video-item').each((_, el) => {
      const $el = $(el)
      const $a = $el.find('a').first()
      const href = $a.attr('href') || ''
      const idMatch = href.match(/\/detail\/(\d+)\.html/)
      if (!idMatch) return

      list.push({
        vod_id: idMatch[1],
        vod_name: $el.find('.title').text().trim(),
        vod_pic: $el.find('img').attr('data-src') || '',
        ext: { id: idMatch[1] },
      })
    })

    return jsonify({ list, page })
  } catch (e) {
    return jsonify({ list: [], page })
  }
}
```

### 关键点

| 技术 | 说明 |
|------|------|
| iframe 提取 | 从播放页获取 `player_aaaa` 的 `from` 字段，映射到 iframe URL |
| 动态端点发现 | 正则 `$.post("xxx.php")` 提取实际 POST 端点 |
| AES Token 解密 | iframe 页面的 `token` 变量用 AES 解密后 POST 给 API |
| Sec-Fetch 头 | iframe 请求需要 `sec-fetch-dest: iframe` 等浏览器特征头 |
| 跨域 POST | `Origin` 和 `X-Requested-With` 头用于通过 CORS 校验 |
| 错误兜底 | 每层都 try-catch，任何环节失败返回 `{ urls: [] }` |


## Template 9: Smart Play API + execB 解密

适用于通过远程 API 获取加密播放地址，再用本地 `execB()` 解密的站点。典型流程：

```
播放页 → player_aaaa(含 playPageUrl/secretKeySeed/timestamp)
→ POST 远程 API (带签名) → 返回加密 URL
→ execB(encryptedUrl, timestamp) → 明文播放地址
```

### 识别特征

- 播放页的 artplayer/iframe 页面中有 `const isSmartPlay = true`
- HTML 中有 `const playPageUrl`、`const secretKeySeed`、`const timestamp`
- 网络请求中有 POST 到外部域名的 API（如 `ticktockwow.com`、`smartplay`）
- `execB()` 函数被 jsjiami.com v6 混淆，无法静态分析

### 逆向方法

**⚠️ execB 的 key derivation 必须通过运行时 hook 捕获，无法静态还原。**

参见 `knowledge/xptv-runtime-debug.md` 使用 Puppeteer + CryptoJS hook。

### 签名算法

常见模式（需实际验证）：
```javascript
// 简单: signature = MD5(String(timestamp))
// 复杂: signature = MD5(timestamp + secret)
// HMAC: signature = HmacMD5(timestamp, secret)
```

### 模板代码

```javascript
/**
 * [源名] XPTV 脚本 — Smart Play API
 * 站点: https://example.com
 * 类型: HTML 爬取 + Smart Play API + execB 解密
 */

const CryptoJS = createCryptoJS();
const cheerio = createCheerio();
const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36';
const SITE = 'https://example.com';

// ★ 运行时捕获的隐藏 secret（混淆代码中硬编码，站点更新后可能变化）
const HIDDEN_SECRET = 'CAPTURED_FROM_HOOK';

// ===== execB 解密 =====
function execBDecrypt(encryptedUrl, timestamp) {
  if (!encryptedUrl || !timestamp) return '';

  // hex → ASCII（player_aaaa.url 通常是 hex 编码）
  let ct = encryptedUrl;
  if (/^[0-9a-fA-F]+$/.test(ct) && ct.length % 2 === 0) {
    let s = '';
    for (let i = 0; i < ct.length; i += 2) {
      s += String.fromCharCode(parseInt(ct.substr(i, 2), 16));
    }
    ct = s;
  }

  // Key derivation（★ 每个站点不同，必须 hook 获取）
  const md5Hex = CryptoJS.MD5(timestamp + HIDDEN_SECRET).toString();

  // 常见模式: hex 字符转 ASCII hex 编码
  // MD5 hex 前 16 字符 → IV, 后 16 字符 → Key
  function toHexAscii(s) {
    return Array.from(s).map(c => c.charCodeAt(0).toString(16).padStart(2, '0')).join('');
  }
  const keyHex = toHexAscii(md5Hex.slice(16, 32));
  const ivHex  = toHexAscii(md5Hex.slice(0, 16));

  try {
    const key = CryptoJS.enc.Hex.parse(keyHex);
    const iv  = CryptoJS.enc.Hex.parse(ivHex);
    const dec = CryptoJS.AES.decrypt(ct, key, {
      iv, mode: CryptoJS.mode.CBC, padding: CryptoJS.pad.Pkcs7,
    });
    return dec.toString(CryptoJS.enc.Utf8);
  } catch { return ''; }
}

// ===== Smart Play API 调用 =====
async function callSmartPlayAPI(vkey, code) {
  // ★ 签名算法（每个站点不同，必须验证）
  const t = Math.floor(Date.now() / 1000);
  const signature = CryptoJS.MD5(String(t)).toString();

  const body = JSON.stringify({ vkey, code, t, signature });

  try {
    const { data } = await $fetch.post(
      'https://api.example.com/smartplay',  // ★ 替换为实际 API endpoint
      body,
      {
        headers: {
          'Content-Type': 'application/json',
          'User-Agent': UA,
          Referer: SITE + '/',
          Origin: SITE,
        },
      }
    );
    return typeof data === 'string' ? JSON.parse(data) : data;
  } catch { return null; }
}

// ===== 其他接口（标准 HTML 爬取） =====
async function getLocalInfo() {
  return jsonify({ ver: 1, name: '源名', api: 'csp_xxx', type: 3 });
}

async function getConfig() {
  return jsonify({
    ver: 1, title: '源名', site: SITE,
    tabs: [
      { name: '电影', ext: { id: '1' } },
      { name: '电视剧', ext: { id: '2' } },
    ],
  });
}

async function getCards(ext) {
  ext = argsify(ext);
  const { id, page = 1 } = ext;
  // ... 标准 HTML 爬取，参考 Template 2
  return jsonify({ list: [], page });
}

async function getTracks(ext) {
  ext = argsify(ext);
  // ... 标准 HTML 爬取
  return jsonify({ list: [] });
}

// ===== getPlayinfo（核心：Smart Play API + execB） =====
async function getPlayinfo(ext) {
  ext = argsify(ext);
  const { url } = ext;
  if (!url) return jsonify({ urls: [] });

  try {
    const playUrl = url.startsWith('http') ? url : SITE + url;
    const { data } = await $fetch.get(playUrl, {
      headers: { 'User-Agent': UA, Referer: SITE + '/' },
    });

    const html = data || '';

    // 提取 HTML 中的动态变量
    const tsMatch = html.match(/const\s+timestamp\s*=\s*"(\d+)"/);
    const seedMatch = html.match(/const\s+secretKeySeed\s*=\s*"([^"]+)"/);
    const vkeyMatch = html.match(/const\s+playPageUrl\s*=\s*"([^"]+)"/);

    const timestamp = tsMatch ? tsMatch[1] : '';
    const secretKeySeed = seedMatch ? seedMatch[1] : '';
    const vkey = vkeyMatch ? vkeyMatch[1] : '';

    if (!timestamp) return jsonify({ urls: [] });

    // 方案 1: Smart Play API
    if (vkey && secretKeySeed) {
      const apiResp = await callSmartPlayAPI(vkey, secretKeySeed);
      if (apiResp?.code === 200 && apiResp.url) {
        const decryptedUrl = execBDecrypt(apiResp.url, timestamp);
        if (decryptedUrl.startsWith('http')) {
          return jsonify({ urls: [decryptedUrl], headers: [{ 'User-Agent': UA, Referer: playUrl }] });
        }
      }
    }

    // 方案 2: player_aaaa.url 直接解密
    const playerData = extractScriptJSON(html, 'player_aaaa');
    if (playerData?.url && playerData.encrypt === 3) {
      const decryptedUrl = execBDecrypt(playerData.url, timestamp);
      if (decryptedUrl.startsWith('http')) {
        return jsonify({ urls: [decryptedUrl], headers: [{ 'User-Agent': UA, Referer: playUrl }] });
      }
    }

    return jsonify({ urls: [] });
  } catch (e) {
    return jsonify({ urls: [] });
  }
}

// 辅助：从 HTML 提取 JSON
function extractScriptJSON(html, varName) {
  const re = new RegExp('var\\s+' + varName + '\\s*=\\s*(\\{[\\s\\S]+?\\})\\s*;?\\s*<\\/script>');
  const match = html.match(re);
  if (!match) return null;
  try { return JSON.parse(match[1]); } catch { return null; }
}

async function search(ext) {
  // ... 标准搜索
  return jsonify({ list: [] });
}
```

### 关键点

| 要素 | 说明 |
|------|------|
| HIDDEN_SECRET | 必须通过 Puppeteer hook 运行时捕获，无法静态还原 |
| API endpoint | 从 artplayer HTML 中 grep `ticktockwow`/`smartplay`/`webvideo` 找到 |
| 签名算法 | hook 网络请求对比 `t` 和 `signature`，常见为 `MD5(String(t))` |
| timestamp | HTML 中 `const timestamp` 的值，用于 API 签名和 execB 解密 |
| vkey | HTML 中 `const playPageUrl` 的值（base64 编码） |
| code | HTML 中 `const secretKeySeed` 的值（传给 API，非 execB 使用） |
| execB key derivation | MD5(timestamp + hiddenSecret) → hex 字符转 ASCII hex 编码 → AES key/iv |
