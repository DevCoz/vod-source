---
name: xptv-script-debugging
description: "Validate and debug XPTV .xptv.js scripts with a local Node.js harness. Use when: user sends .xptv.js file, asks to debug/validate/test XPTV script, or reports playback issues. Triggers: xptv, debug, .xptv.js, smoke test, 播放不了, 除錯, 寫源測試."
version: 2.1.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [xptv, debugging, javascript, harness, smoke-test]
    related_skills: [xptv-script-development, systematic-debugging]
---

# XPTV Script Debugging

## Quick Start

```bash
# 1. Save script
cp my_script.xptv.js ~/.xptv-scripts/

# 2. Smoke test
cd ~/.xptv-debugger
node xptv_harness.js smoke ~/.xptv-scripts/my_script.xptv.js --keyword 測試

# 3. If fails → run failing step directly
node xptv_harness.js run ~/.xptv-scripts/my_script.xptv.js --fn getPlayinfo --ext '{"url":"..."}'
```

## Commands

| Command | Description |
|---------|-------------|
| `node xptv_harness.js smoke <script> [opts]` | Full 6-step smoke test |
| `node xptv_harness.js run <script> --fn <name> --ext '{...}'` | Run single function |
| `node xptv_harness.js --help` | Show all options |
| `debug_xptv.sh <script> [keyword] [extra_args]` | Shell wrapper |

**Options:** `--keyword`, `--page`, `--tab-index`, `--skip-search`, `--timeout <sec>`, `--config '{"token":"..."}'`, `--no-cache`

**Workspace:** `~/.xptv-debugger/`

## Harness Runtime

| Helper | Usage |
|--------|-------|
| `jsonify(obj)` | Serialize return — **all 6 functions must use this** |
| `argsify(ext)` | Parse ext JSON → object |
| `$fetch.get(url, opts)` | → `{ data, status, respHeaders, url }` |
| `$fetch.post(url, body, opts)` | Body as 2nd arg (NOT axios style) |
| `createCheerio()` | → cheerio module, use `.load(data)` |
| `createCryptoJS()` | → CryptoJS (MD5, AES, etc.) |
| `$config_str` | JSON config (token scripts) |
| `$cache.get/set` | Stub (returns null) |

## Smoke Test Flow

```
getLocalInfo()  →  getConfig()  →  getCards(tab)  →  getTracks(card)  →  getPlayinfo(track)  →  search()
     ↓                ↓                ↓                 ↓                   ↓                  ↓
 {ver,name}      {tabs:[...]}    {list:[...]}      {list:[{tracks}]}    {urls:[...]}        {list:[...]}
```

Each function must return `jsonify({...})` with the schema above.

## Diagnostic Decision Tree

```
smoke test 失敗
├─ Missing required functions?
│  └─ 加 stub: async function getLocalInfo(ext) { return jsonify({name:"test",ver:1}) }
│
├─ getLocalInfo / getConfig 失敗?
│  └─ 語法錯誤 → 檢查 JS syntax
│
├─ getCards 空列表?
│  ├─ curl 測試站點是否存活 → 404/blocked = 站點掛了
│  ├─ 站點活著但空 → selector 變了，檢查 HTML
│  └─ 參考 references/case-studies.md 中的 SSR 站點處理
│
├─ getTracks 失敗?
│  └─ ext.url 缺失或 detail 頁解析錯誤
│
├─ getPlayinfo 無 urls?
│  ├─ 播放器解析失敗 → 試 multi-pattern fallback（見 Key Patterns）
│  └─ player_aaaa JSON.parse 報錯 → 用 brace counting
│
├─ search 空結果?
│  ├─ 偶發 → rate limiting（等 30s 重試）
│  └─ 必現 → 參數格式錯或 API 變了
│
└─ code:1004 / 请先完成验证?
   └─ GeeTest CAPTCHA → 無法在 harness 繞過，加 null check 防崩潰
```

## Error Cheat Sheet

| Error | Cause | Fix |
|-------|-------|-----|
| `Missing required functions` | Not all 6 interfaces | Add stub for missing ones |
| `did not return a JSON string` | Returned raw object | Wrap: `return jsonify({...})` |
| `getCards returned empty list` | Selector wrong / JS-rendered | `curl` raw HTML to verify |
| `getTracks returned no track groups` | Detail parse broken | Check `ext.url` from getCards |
| `getPlayinfo no urls array` | Wrong schema | All paths must return `jsonify({ urls: [], headers: [] })` |
| `$config_str is not defined` | Token script | `--config '{"token":"xxx"}'` |
| `fetch failed` | Site down | `curl -sI URL` first |
| `code:1004` | GeeTest required | Cannot bypass — add null checks |
| `JSON.parse` on `player_aaaa` fails | `lastIndexOf('}')` wrong | Use brace counting |
| Search empty (intermittent) | Rate limit ~30s | Wait and retry |
| `argsify failed` | Bad JSON ext | Check ext payload |

## Key Patterns

### $fetch.post — 3 params (NOT axios)
```javascript
await $fetch.post(url, 'key=value', { headers: {...} });        // form
await $fetch.post(url, jsonify({ wd: kw }), { headers: {...} }); // json
```

### $fetch return — `respHeaders`
```javascript
const { data, respHeaders } = await $fetch.get(url, { headers });
// Use respHeaders — not headers, not responseHeaders
```

### cheerio — `.load(data)`
```javascript
var $ = createCheerio().load(data);  // ✅
var $ = createCheerio(data);          // ❌ does NOT parse
```

### Player parsing — fallback chain
```javascript
// 1. window.PLAYER_CONFIG.m3u8
// 2. jwplayer().setup({ file: "..." })
// 3. player_aaaa = { url: "..." }  ← brace counting, NOT lastIndexOf
// 4. Direct .m3u8/.mp4 in HTML
```

### JSON-escaped HTML (jqqzx.cc pattern)
```javascript
if (data.charCodeAt(0) === 34) {  // starts with "
  try { data = JSON.parse(data); } catch (e) {}
}
```

### HTTP→HTTPS (Android compat)
```javascript
if (url.startsWith('http://')) url = url.replace('http://', 'https://');
```

## Workflow (with checkpoints)

1. Save to `~/.xptv-scripts/`
2. Smoke test → check output
3. **⬡ Checkpoint:** 確認失敗步驟和錯誤訊息，再繼續
4. Re-run failing function with `run` mode
5. Inspect raw HTML with curl if needed
6. Fix script
7. **⬡ Checkpoint:** 重新跑 full smoke test，確認 6 步全綠
8. Sync: `cp ~/.xptv-scripts/X.xptv.js ~/.xptv-debugger/xptv-extensions/js/`

## Verification

Ready when all pass:
- [ ] All 6 functions exist
- [ ] Smoke test reaches `getPlayinfo()`
- [ ] `playinfo.urls` is non-empty array
- [ ] `search()` returns list structure
- [ ] No schema mismatches

## References

- `references/case-studies.md` — CupFox, 91porn, symx, heiliao, radio.cn, haijiao, etc.
- `references/anti-bot.md` — GeeTest, rate limiting, strencode2, obfuscated scripts
- `references/pr-workflow.md` — upstream comparison, git workflow, PR creation
