# XPTV API Reference

## 环境与工具库

```js
const $config = argsify($config_str)
const cheerio = createCheerio()
const CryptoJS = createCryptoJS()

// 日志: http://ip:8110/log
$print("xxx")

// 缓存
const v = $cache.get('key')
$cache.set('key', 'value')
$cache.del('key')

// 提示
$utils.toastInfo('xxx')
$utils.toastError('xxx')

// 系统信息
$utils.os()   // e.g. "tvOS/18.1"
$utils.app()  // e.g. "2.0"
```

---

## 1. getLocalInfo() — 本地源信息

**用途**: XPTV 识别和管理该源。**仅本地 `.xptv.js` 文件需要此方法**，远程订阅源不需要。

**返回**:
```js
{
  ver: 1,                    // 固定为 1
  name: "源名称",
  api: "csp_唯一标识符",     // 唯一，不可重复
  type: 3,                   // 可选，VOD 通常为 3
}
```

**示例**:
```js
async function getLocalInfo() {
  return jsonify({
    ver: 1,
    name: "播剧网",
    api: "csp_ysxq",
    type: 3,
  });
}
```

---

## 2. getConfig() — 源配置

**用途**: 返回导航标签页配置

**返回**:
```js
{
  ver: 1,
  title: "源标题",
  site: "https://example.com",
  tabs: [
    {
      name: "标签名称",
      ext: { id: "分类ID" }   // 传给 getCards
    }
  ]
}
```

**横式图片**：如果卡片图片为横式（宽屏），在 tab 中加 `ui: 1`：
```js
tabs: [
  { name: '电影', ext: { id: '1' }, ui: 1 },
]
```

---

## 3. getCards(ext) — 视频列表

**入参 ext**:
```js
{
  id: "分类ID",       // 来自 tabs[].ext.id
  page: 1,            // 分页，默认 1
  filters: {}         // 可选，筛选参数字典 [String: String]
}
```

**解构写法**:
```js
const { page = 1, id, filters = {} } = ext;
```

**返回**:
```js
{
  list: [
    {
      vod_id: "唯一ID",
      vod_name: "视频名",
      vod_pic: "封面URL",        // 可选
      vod_remarks: "更新至12集",  // 可选
      vod_duration: "片长",       // 可选（直播源可显示在线人数）
      vod_time: "更新时间",       // 可选
      vod_pubdate: "上映日期",    // 可选
      ext: { url: "详情页URL" }   // 传给 getTracks
    }
  ],
  filter: [                       // 可选，筛选定义
    {
      key: "type",
      name: "类型",
      init: "all",
      value: [
        { n: "全部", v: "all" },
        { n: "喜剧", v: "喜剧" }
      ]
    }
  ]
}
```

**Filter 协议**:
- `filter[].key` → 下次请求的 `ext.filters[key]`
- 缺少筛选键时按 `init` 处理
- 非法值回退到 `init`
- 响应无 `filter` 字段（或为空）→ 视为无筛选页面

---

## 4. getTracks(ext) — 播放线路

**入参 ext**:
```js
{
  id: "视频ID",
  url: "详情URL"    // 来自 getCards 的 ext
}
```

**返回（在线播放源）**:
```js
{
  list: [
    {
      title: "线路名称",
      tracks: [
        {
          name: "第1集",
          ext: { url: "播放链接" }  // 传给 getPlayinfo
        }
      ]
    }
  ],
  info: {                           // 可选
    vod_pic: "真实封面URL",
    vod_desc: "剧情简介"
  }
}
```

**返回（网盘源）**:
```js
{
  list: [
    {
      title: "夸克网盘",
      tracks: [
        {
          name: "S01E01.1080P",
          pan: "https://pan.quark.cn/s/xxx",  // 用 pan 参数
          ext: {}
        }
      ]
    }
  ]
}
```

**网盘模式**: tracks 中用 `pan` 字段代替 `ext.url`，`getPlayinfo()` 返回 `{ urls: [] }`

---

## 5. getPlayinfo(ext) — 播放地址

**入参 ext**:
```js
{
  url: "播放链接"   // 来自 getTracks 的 ext.url
}
```

**返回（在线播放源）**:
```js
{
  urls: ["https://example.com/video.m3u8"],
  headers: [{ "User-Agent": "...", "Referer": "..." }]  // 可选
}
```

**带外挂字幕**:
```js
{
  urls: ["https://example.com/video.m3u8"],
  headers: [{ "User-Agent": "...", "Referer": "..." }],
  subtitles: [
    { name: "中文字幕", url: "https://xx.com/1.srt" },
    { name: "English", url: "https://xx.com/1.en.srt" }
  ]
}
```

**网盘源**: 返回 `{ urls: [] }`

---

## 6. search(ext) — 搜索

**入参 ext**:
```js
{
  text: "搜索关键词",   // 或 wd，取决于源站
  page: 1
}
```

**返回**: 与 getCards 相同
```js
{
  list: [{ vod_id, vod_name, vod_pic, vod_remarks, ext }],
  page: 1
}
```

---

## 数据序列化

- **返回**: 必须 `jsonify(obj)` → JSON string
- **入参**: 必须 `argsify(ext)` → JS object

## 网盘类型支持

| 网盘 | 支持 | URL 格式 |
|------|------|----------|
| 夸克 | ✅ | `https://pan.quark.cn/s/xxx` |
| 阿里 | ✅ | `https://www.alipan.com/s/xxx` |
| 115 | ✅ | `https://115.com/s/xxx` |
| 天翼 | ✅ | `https://cloud.189.cn/t/xxx` |
| 百度 | ❌ | 不支持 |
| 迅雷 | ❌ | 不支持 |
| 磁力 | ❌ | 不支持 |

## XPTV JSC 环境约束

XPTV 运行在 JavaScriptCore (JSC)，不是 Node.js。

**可用全局函数**：
- `createCryptoJS()` — 返回 CryptoJS 实例
- `createCheerio()` — 返回 cheerio 实例
- `loadJSEncrypt()` — 返回 JSEncrypt 实例（RSA）

**不可用**：
- ❌ `Buffer` — 用 `CryptoJS.enc.Base64.parse()`
- ❌ `atob`/`btoa` — 用 CryptoJS
- ❌ `require()` — 用全局函数
- ❌ `new URL()` / `URLSearchParams` — 用正则解析

**URL 参数提取（JSC 兼容）**：
```js
function extractParam(urlStr, param) {
  const match = urlStr.match(new RegExp('[?&]' + param + '=([^&]+)'));
  if (match && match[1]) {
    try { return decodeURIComponent(match[1]); } catch (e) { return match[1]; }
  }
  return null;
}
```
