---
name: decode-js
description: JavaScript deobfuscation tool based on Babel AST analysis. Handles jsjiami.com (v6/v7), javascript-obfuscator, sojson, jjencode, and common obfuscation patterns. Use when encountering obfuscated JavaScript code that needs to be deobfuscated for analysis.
version: 1.0.0
tags: [javascript, deobfuscation, reverse-engineering, babel]
---

# decode-js

JavaScript 反混淆工具，基於 Babel AST 分析。安裝在 `~/tools/decode-js/`。

## 支援的混淆類型

| 類型 | 說明 | 指令 |
|------|------|------|
| `common` | 高頻局部混淆（死代碼、控制流扁平化等） | `decode-js -t common` |
| `sojson` | jsjiami.com v6 混淆 | `decode-js -t sojson` |
| `sojsonv7` | jsjiami.com v7 混淆 | `decode-js -t sojsonv7` |
| `obfuscator` | javascript-obfuscator 混淆 | `decode-js -t obfuscator` |
| `jjencode` | JJEncode 編碼 | `decode-js -t jjencode` |
| `awsc` | 阿里雲 AWSC 混淆 | `decode-js -t awsc` |

## 使用方式

```bash
# 基本用法
decode-js -t <type> -i <input.js> -o <output.js>

# 範例：反混淆 jsjiami.com v6
decode-js -t sojson -i obfuscated.js -o decoded.js

# 範例：反混淆 javascript-obfuscator
decode-js -t obfuscator -i obfuscated.js -o decoded.js
```

## 自動偵測混淆類型

如果不知道混淆類型，可以按順序嘗試：

1. 先試 `sojson`（jsjiami.com v6 最常見）
2. 再試 `sojsonv7`（v7 版本）
3. 再試 `obfuscator`（javascript-obfuscator）
4. 最後試 `common`（通用處理）

識別方法：
- 看到 `_0xodk = 'jsjiami.com.v6'` → 用 `sojson`
- 看到 `_0xodk = 'jsjiami.com.v7'` → 用 `sojsonv7`
- 看到大量 `_0x` 開頭變量 + 字符串陣列旋轉 → 用 `obfuscator`
- 看到 `var _=~[];var __=~[];` 等 JJEncode 特徵 → 用 `jjencode`

## 環境需求

- Node.js 22+（已安裝在 `$NODE_HOME/`）
- decode-js 位於 `~/tools/decode-js/`
- wrapper 腳本：`~/tools/decode-js/decode-js`

## 注意事項

- 輸入文件只能包含混淆代碼，不能有其他非混淆內容
- `sojson` 類型對 jsjiami.com v6 效果最好（能解開 stringArray、控制流等）
- `sojsonv7` 可能對某些變體不穩定
- 解混淆後的代碼可能仍需手動分析（如加密函數的 key/IV）
