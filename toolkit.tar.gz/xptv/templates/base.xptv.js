/**
 * [源名] XPTV 脚本
 * 站点: https://example.com
 * 类型: MacCMS API / HTML 爬取 / 網盤源
 *
 * 使用方法：
 *   1. 將此文件重命名為 `[name].xptv.js`
 *   2. 修改 SITE、API、UA 等常量
 *   3. 實作六個接口
 *   4. 本地測試：node xptv_harness.js smoke [name].xptv.js
 */

const CryptoJS = createCryptoJS()
const cheerio = createCheerio()

// ===== 常量 =====
const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
const SITE = 'https://example.com'

// ===== 工具函數 =====

// 從 <script> 標籤中提取 JSON 變量
function extractScriptJSON(html, varName) {
  var re = new RegExp('var\\s+' + varName + '\\s*=\\s*(\\{[\\s\\S]+?\\})\\s*;?\\s*<\\/script>')
  var match = html.match(re)
  if (!match) return null
  try { return JSON.parse(match[1]) } catch { return null }
}

// 相對 URL 補全
function fixUrl(href) {
  if (!href) return ''
  if (href.startsWith('http')) return href
  if (href.startsWith('//')) return 'https:' + href
  return SITE + (href.startsWith('/') ? '' : '/') + href
}

// ===== 接口實現 =====

// 1. 本地源信息（本地 .xptv.js 必須實現）
async function getLocalInfo() {
  return jsonify({
    ver: 1,
    name: '源名',
    api: 'csp_uniquename',  // 必須全局唯一
    type: 3,                // VOD=3, 直播=4
  })
}

// 2. 源配置（分類標籤）
async function getConfig() {
  return jsonify({
    ver: 1,
    title: '源名',
    site: SITE,
    tabs: [
      { name: '電影', ext: { id: '1' } },
      { name: '電視劇', ext: { id: '2' } },
      // 橫式圖片加 ui: 1
      // { name: '綜藝', ext: { id: '3' }, ui: 1 },
    ],
  })
}

// 3. 卡片列表
async function getCards(ext) {
  ext = argsify(ext)
  var id = ext.id
  var page = ext.page || 1

  try {
    // TODO: 根據實際 API 構建 URL
    var url = SITE + '/api.php/provide/vod/?ac=list&t=' + id + '&pg=' + page
    var resp = await $fetch.get(url, { headers: { 'User-Agent': UA, Referer: SITE + '/' } })
    var data = argsify(resp.data)

    var list = []
    // TODO: 根據實際數據結構解析
    for (var item of (data.list || [])) {
      list.push({
        vod_id: String(item.vod_id),
        vod_name: item.vod_name,
        vod_pic: item.vod_pic,
        vod_remarks: item.vod_remarks || '',
        ext: { id: String(item.vod_id) },
      })
    }

    return jsonify({ list: list, page: page })
  } catch (error) {
    return jsonify({ list: [], page: page })
  }
}

// 4. 播放線路 + 劇集
async function getTracks(ext) {
  ext = argsify(ext)
  var id = ext.id
  if (!id) return jsonify({ list: [], info: {} })

  try {
    // TODO: 獲取詳情頁
    var url = SITE + '/api.php/provide/vod/?ac=detail&ids=' + id
    var resp = await $fetch.get(url, { headers: { 'User-Agent': UA, Referer: SITE + '/' } })
    var data = argsify(resp.data)

    var info = {}
    var lines = []

    // TODO: 根據實際數據結構解析播放線路
    // 示例：解析 vod_play_from 和 vod_play_url
    var vod = (data.list || [])[0]
    if (vod) {
      var froms = (vod.vod_play_from || '').split('$$$')
      var urls = (vod.vod_play_url || '').split('$$$')

      for (var i = 0; i < froms.length; i++) {
        var tracks = []
        var episodes = (urls[i] || '').split('#')
        for (var ep of episodes) {
          var parts = ep.split('$')
          if (parts.length >= 2) {
            tracks.push({ name: parts[0], ext: { url: parts[1] } })
          }
        }
        if (tracks.length > 0) {
          lines.push({ title: froms[i] || '線路' + (i + 1), tracks: tracks })
        }
      }
    }

    return jsonify({ list: lines, info: info })
  } catch (error) {
    return jsonify({ list: [], info: {} })
  }
}

// 5. 播放地址
async function getPlayinfo(ext) {
  ext = argsify(ext)
  var url = ext.url
  if (!url) return jsonify({ urls: [] })

  try {
    // TODO: 解析實際播放地址
    // 簡單情況：url 就是 m3u8 直鏈
    if (url.startsWith('http')) {
      return jsonify({
        urls: [url],
        headers: [{ 'User-Agent': UA, Referer: SITE + '/' }],
      })
    }

    // TODO: 複雜情況：需要解密、二次請求等
    // 參考 knowledge/xptv-patterns.md 的 Pattern 20/27（execB 解密）

    return jsonify({ urls: [] })
  } catch (error) {
    return jsonify({ urls: [] })
  }
}

// 6. 搜索
async function search(ext) {
  ext = argsify(ext)
  var text = ext.text || ext.wd || ''
  var page = ext.page || 1
  if (!text) return jsonify({ list: [], page: page })

  try {
    // TODO: 根據實際搜索 API 構建 URL
    var url = SITE + '/api.php/provide/vod/?ac=list&wd=' + encodeURIComponent(text) + '&pg=' + page
    var resp = await $fetch.get(url, { headers: { 'User-Agent': UA, Referer: SITE + '/' } })
    var data = argsify(resp.data)

    var list = []
    for (var item of (data.list || [])) {
      list.push({
        vod_id: String(item.vod_id),
        vod_name: item.vod_name,
        vod_pic: item.vod_pic,
        vod_remarks: item.vod_remarks || '',
        ext: { id: String(item.vod_id) },
      })
    }

    return jsonify({ list: list, page: page })
  } catch (error) {
    return jsonify({ list: [], page: page })
  }
}
