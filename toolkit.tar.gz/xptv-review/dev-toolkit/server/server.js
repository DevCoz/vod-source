import express from 'express'
import * as funcs from '../src/debug.js'

const app = express()
app.use(express.text({ type: '*/*' }))

const PORT = process.env.PORT || 3000
const REQUEST_TIMEOUT = parseInt(process.env.TIMEOUT || '25000') // 单接口超时 ms

// CORS
app.use((req, res, next) => {
    res.header('Access-Control-Allow-Origin', '*')
    res.header('Access-Control-Allow-Headers', 'Content-Type')
    if (req.method === 'OPTIONS') return res.sendStatus(200)
    next()
})

// Request logging
app.use((req, res, next) => {
    const ts = new Date().toISOString().slice(11, 19)
    const body = typeof req.body === 'string' ? req.body.substring(0, 300) : ''
    console.log(`[${ts}] ${req.method} ${req.path}${body ? '  body=' + body : ''}`)
    req._startTime = Date.now()
    const origEnd = res.end
    res.end = function (...args) {
        const ms = Date.now() - req._startTime
        console.log(`[${ts}] ${req.method} ${req.path} → ${res.statusCode} (${ms}ms)`)
        origEnd.apply(this, args)
    }
    next()
})

// Health check + auto-test
app.get('/', async (_req, res) => {
    const routes = Object.keys(funcs).map((name) => {
        const method = name === 'getConfig' || name === 'getLocalInfo' ? 'GET' : 'POST'
        return { name, method, path: `/${name}` }
    })
    res.json({ ok: true, routes, timeout: REQUEST_TIMEOUT + 'ms' })
})

// Auto-test endpoint: GET /test — runs all 6 interfaces
app.get('/test', async (_req, res) => {
    const results = {}
    const run = async (name, fn, body) => {
        const start = Date.now()
        try {
            const data = body ? await fn(body) : await fn()
            const parsed = typeof data === 'string' ? JSON.parse(data) : data
            const ms = Date.now() - start
            let summary = `${ms}ms`
            if (parsed.list) summary += ` | ${parsed.list.length} items`
            if (parsed.tabs) summary += ` | ${parsed.tabs.length} tabs`
            if (parsed.urls) summary += ` | ${parsed.urls.length} urls`
            if (parsed.name) summary += ` | ${parsed.name}`
            results[name] = { ok: true, summary }
        } catch (err) {
            results[name] = { ok: false, error: err.message, ms: Date.now() - start }
        }
    }

    // Run all 6 interfaces
    await run('getLocalInfo', funcs.getLocalInfo)
    await run('getConfig', funcs.getConfig)
    await run('getCards', funcs.getCards, '{"page":1,"id":"1"}')
    // getTracks: use first card from getCards if available
    try {
        const cardsData = await funcs.getCards('{"page":1,"id":"1"}')
        const cards = typeof cardsData === 'string' ? JSON.parse(cardsData) : cardsData
        if (cards.list && cards.list[0]) {
            await run('getTracks', funcs.getTracks, JSON.stringify({ url: cards.list[0].ext?.url || cards.list[0].vod_id }))
        } else {
            results.getTracks = { ok: false, error: 'no cards to test with' }
        }
    } catch (e) {
        results.getTracks = { ok: false, error: e.message }
    }
    await run('search', funcs.search, '{"text":"test"}')
    // getPlayinfo: skip by default (needs valid ext from getTracks)
    results.getPlayinfo = { ok: null, summary: 'skipped (needs valid ext from getTracks)' }

    const passed = Object.values(results).filter(r => r.ok === true).length
    const failed = Object.values(results).filter(r => r.ok === false).length
    const skipped = Object.values(results).filter(r => r.ok === null).length

    res.json({
        summary: `${passed} passed, ${failed} failed, ${skipped} skipped`,
        results,
    })
})

// Register interface routes with timeout
Object.keys(funcs).forEach((fnName) => {
    const handler = async (req, res) => {
        // Wrap in timeout
        const timer = setTimeout(() => {
            if (!res.headersSent) {
                console.error(`[${fnName}] TIMEOUT after ${REQUEST_TIMEOUT}ms`)
                res.status(504).json({ success: false, error: `timeout after ${REQUEST_TIMEOUT}ms` })
            }
        }, REQUEST_TIMEOUT)

        try {
            const body = (fnName === 'getConfig' || fnName === 'getLocalInfo') ? undefined : req.body
            const result = body !== undefined ? await funcs[fnName](body) : await funcs[fnName]()
            clearTimeout(timer)
            if (!res.headersSent) res.send(result)
        } catch (err) {
            clearTimeout(timer)
            console.error(`[${fnName}] ERROR:`, err.stack || err.message)
            if (!res.headersSent) {
                res.status(500).json({ success: false, error: err.message })
            }
        }
    }

    if (fnName === 'getConfig' || fnName === 'getLocalInfo') {
        app.get(`/${fnName}`, handler)
    } else {
        app.post(`/${fnName}`, handler)
    }
})

const server = app.listen(PORT, () => {
    console.log(`XPTV dev server running on http://localhost:${PORT}`)
    console.log(`  GET  http://localhost:${PORT}/           → health + routes`)
    console.log(`  GET  http://localhost:${PORT}/test        → auto-test all interfaces`)
    console.log(`  GET  http://localhost:${PORT}/getLocalInfo`)
    console.log(`  GET  http://localhost:${PORT}/getConfig`)
    console.log(`  POST http://localhost:${PORT}/getCards`)
    console.log(`  POST http://localhost:${PORT}/getTracks`)
    console.log(`  POST http://localhost:${PORT}/getPlayinfo`)
    console.log(`  POST http://localhost:${PORT}/search`)
    console.log(`  Request timeout: ${REQUEST_TIMEOUT}ms`)
})

// Graceful shutdown
const shutdown = (signal) => {
    console.log(`\n${signal} received, shutting down...`)
    server.close(() => {
        console.log('Server closed.')
        process.exit(0)
    })
    setTimeout(() => process.exit(1), 3000)
}
process.on('SIGINT', () => shutdown('SIGINT'))
process.on('SIGTERM', () => shutdown('SIGTERM'))
