import axios from 'axios'

// ===== $fetch: 模拟 XPTV 内置的 HTTP 客户端 =====
const DEFAULT_TIMEOUT = 20000 // 20s 默认超时

const $fetch = {
    get: async (url, options = {}) => {
        const cfg = {
            ...options,
            responseType: 'text',
            timeout: options.timeout || DEFAULT_TIMEOUT,
            validateStatus: () => true, // 不抛 HTTP 错误
        }
        const resp = await axios.get(url, cfg)
        return {
            data: resp.data,
            status: resp.status,
            headers: resp.headers || {},
        }
    },
    download: async (url, options = {}) => {
        const cfg = {
            ...options,
            responseType: 'arraybuffer',
            timeout: options.timeout || DEFAULT_TIMEOUT,
            validateStatus: () => true,
        }
        const resp = await axios.get(url, cfg)
        return {
            data: resp.data,
            status: resp.status,
            headers: resp.headers || {},
        }
    },
    post: async (url, body, options = {}) => {
        const cfg = {
            ...options,
            responseType: 'text',
            timeout: options.timeout || DEFAULT_TIMEOUT,
            validateStatus: () => true,
        }
        const resp = await axios.post(url, body, cfg)
        return {
            data: resp.data,
            status: resp.status,
            headers: resp.headers || {},
        }
    },
}

// ===== 基础工具 =====
const jsonify = (obj) => JSON.stringify(obj)
const argsify = (str) => {
    if (typeof str === 'object' && str !== null) return str
    return JSON.parse(str)
}

const $print = (...args) => {
    console.log('[XPTV]', ...args)
}

// ===== $cache: 模拟 XPTV 内置缓存 =====
const _cache = new Map()
const $cache = {
    get: (key) => {
        const entry = _cache.get(key)
        if (!entry) return null
        if (entry.expire > 0 && Date.now() > entry.expire) {
            _cache.delete(key)
            return null
        }
        return entry.value
    },
    set: (key, value, ttlSeconds = 0) => {
        _cache.set(key, {
            value,
            expire: ttlSeconds > 0 ? Date.now() + ttlSeconds * 1000 : 0,
        })
    },
    del: (key) => _cache.delete(key),
}

// ===== $utils: 模拟 XPTV 内置工具 =====
const $utils = {
    toastInfo: (msg) => console.log(`[TOAST:INFO] ${msg}`),
    toastError: (msg) => console.log(`[TOAST:ERROR] ${msg}`),
    os: () => 'DevToolkit/1.0',
    app: () => '2.0',
}

export { $fetch, jsonify, argsify, $print, $cache, $utils }
