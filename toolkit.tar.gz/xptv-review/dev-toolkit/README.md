# XPTV Dev Toolkit

本地开发和测试 XPTV 脚本的工具集。

## 目录结构

```
dev-toolkit/
├── server/server.js    # Express 测试服务器（6个接口）
├── utils/utils.js      # $fetch / jsonify / argsify / $print 模拟
├── src/
│   ├── debug.js        # 你的源码（在此编辑）
│   ├── sub-debug.js    # 远程代理模式（连接本地 server）
│   ├── hook-template.js # Puppeteer 运行时 hook（反混淆用）
│   └── debug.json      # XPTV 订阅配置示例
├── rollup.config.js    # ES module → XPTV 格式转换
└── package.json
```

## 快速开始

```bash
# 1. 安装依赖
cd dev-toolkit && npm install

# 2. 编写源码
#    编辑 src/debug.js，实现6个接口

# 3. 启动测试服务器
npm start              # http://localhost:3000
# 或带自定义端口
PORT=8080 npm start

# 4. 测试接口
curl http://localhost:3000/                          # 健康检查 + 路由列表
curl http://localhost:3000/getLocalInfo              # getLocalInfo
curl http://localhost:3000/getConfig                 # getConfig
curl -X POST http://localhost:3000/getCards -H "Content-Type: text/plain" -d '{"page":1}'
curl -X POST http://localhost:3000/search -H "Content-Type: text/plain" -d '{"text":"测试"}'

# 5. 热重载开发
npm run dev

# 6. 打包为 XPTV 格式
npm run build           # → dist/output.xptv.js
```

## 环境变量

| 变量 | 默认值 | 说明 |
|------|--------|------|
| `PORT` | 3000 | 服务器端口 |
| `XPTV_API_HOST` | localhost | sub-debug.js 连接的主机 |
| `XPTV_API_PORT` | 3000 | sub-debug.js 连接的端口 |

## 运行时 Hook（反混淆）

针对 jsjiami 等混淆的播放页，使用 Puppeteer hook 提取加密参数：

```bash
# 1. 安装 puppeteer-core（不在 package.json 默认依赖中，按需安装）
npm install puppeteer-core

# 2. 修改 src/hook-template.js 中的 TARGET_URL 和 REFERER

# 3. 运行
npm run hook
# 输出：AES key/iv、MD5 记录、网络请求、解密后的播放 URL
```
