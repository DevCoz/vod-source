/**
 * XPTV 混淆代码运行时 Hook 模板
 *
 * 用法：
 *   1. 修改 TARGET_URL 为实际的 artplayer iframe URL
 *   2. 修改 REFERER 为实际的播放页 URL
 *   3. npm install puppeteer-core
 *   4. node src/hook-template.js
 *
 * 输出：
 *   - AES decrypt 调用记录（key/iv/结果）
 *   - MD5 调用记录（输入/输出）
 *   - 网络请求记录（API endpoint/参数）
 *   - 成功解密的播放 URL
 */

import puppeteer from 'puppeteer-core'
import { writeFileSync } from 'fs'

// ★★★ 修改这里 ★★★
const TARGET_URL = 'https://example.com/static/player/artplayer/?url=HEX_ENCODED_URL'
const REFERER = 'https://example.com/play/xxx-1-1.html'
const CHROME_PATH = '/usr/bin/chromium' // 或 '/usr/bin/google-chrome'
const WAIT_SECONDS = 12 // 等待页面执行的时间

const HOOK_SCRIPT = `
  window.__AES__ = [];
  window.__MD5__ = [];
  window.__OK__ = [];
  window.__NET__ = [];

  // 拦截 XMLHttpRequest
  const OrigXHR = XMLHttpRequest;
  XMLHttpRequest = function() {
    const xhr = new OrigXHR();
    const origSend = xhr.send;
    const origOpen = xhr.open;
    xhr.open = function(m, u) { this.__url = u; return origOpen.apply(this, arguments); };
    xhr.send = function(body) {
      if (body) window.__NET__.push({ method: 'POST', url: this.__url, body: String(body).substring(0, 600) });
      return origSend.apply(this, arguments);
    };
    return xhr;
  };

  // 拦截 fetch
  const origFetch = window.fetch;
  window.fetch = async function(...args) {
    const url = typeof args[0] === 'string' ? args[0] : args[0]?.url;
    const body = args[1]?.body;
    window.__NET__.push({ method: 'FETCH', url, body: String(body).substring(0, 600) });
    return origFetch.apply(this, args);
  };

  // 等 CryptoJS 加载后自动 hook
  const _iv = setInterval(() => {
    if (typeof CryptoJS !== 'undefined' && !window.__CH__) {
      window.__CH__ = true;
      clearInterval(_iv);

      const _aes = CryptoJS.AES.decrypt;
      const _md5 = CryptoJS.MD5;

      CryptoJS.AES.decrypt = function(ct, key, cfg) {
        const rec = { key: null, iv: null };
        try { rec.key = key?.toString?.(); } catch {}
        try { rec.iv = cfg?.iv?.toString?.(); } catch {}
        try {
          const d = _aes.call(this, ct, key, cfg);
          const t = d.toString(CryptoJS.enc.Utf8);
          rec.utf8 = t?.substring(0, 400);
          rec.hex = d.toString()?.substring(0, 120);
          rec.ok = t?.startsWith('http') || t?.includes('.m3u8') || t?.includes('.mp4');
          if (rec.ok) {
            window.__OK__.push({ url: t, key: rec.key, iv: rec.iv });
            console.log('[CAP-AES] ✓ URL=' + t.substring(0, 120));
          }
        } catch(e) { rec.err = e.message; }
        window.__AES__.push(rec);
        return _aes.call(this, ct, key, cfg);
      };

      CryptoJS.MD5 = function(msg) {
        const r = _md5.call(this, msg);
        window.__MD5__.push({ in: String(msg).substring(0, 300), out: r.toString() });
        return r;
      };

      console.log('[HOOK] CryptoJS hooked');
    }
  }, 50);
`

;(async () => {
    console.log('[*] Launching browser...')
    const browser = await puppeteer.launch({
        executablePath: CHROME_PATH,
        headless: 'new',
        args: ['--no-sandbox', '--disable-setuid-sandbox', '--disable-gpu', '--disable-dev-shm-usage'],
    })

    const page = await browser.newPage()
    await page.setUserAgent(
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
    )
    await page.setExtraHTTPHeaders({ Referer: REFERER })

    // 注入 hook（必须在页面加载前）
    await page.evaluateOnNewDocument(HOOK_SCRIPT)

    // 监控 API 响应
    page.on('response', async (res) => {
        const url = res.url()
        if (url.includes('api') || url.includes('smart') || url.includes('webvideo') || url.includes('play')) {
            try {
                const t = await res.text()
                console.log('[API-RES]', res.status(), url.substring(0, 80), '→', t.substring(0, 300))
            } catch {}
        }
    })

    page.on('console', (msg) => {
        const t = msg.text()
        if (t.includes('[HOOK]') || t.includes('[CAP-]')) console.log('  PAGE:', t)
    })

    console.log('[*] Navigating to:', TARGET_URL)
    try {
        await page.goto(TARGET_URL, { waitUntil: 'networkidle0', timeout: 50000 })
    } catch {
        console.log('[!] Navigation timeout (expected for long-polling)')
    }

    console.log('[*] Waiting ' + WAIT_SECONDS + 's for execution...')
    await new Promise((r) => setTimeout(r, WAIT_SECONDS * 1000))

    const data = await page.evaluate(() => ({
        aes: window.__AES__ || [],
        md5: window.__MD5__ || [],
        ok: window.__OK__ || [],
        net: window.__NET__ || [],
        hooked: window.__CH__ || false,
    }))

    await browser.close()

    // 输出结果
    console.log('\n' + '='.repeat(50))
    console.log('CAPTURE RESULTS')
    console.log('='.repeat(50))
    console.log('CryptoJS hooked:', data.hooked)
    console.log('AES calls:', data.aes.length)
    console.log('MD5 calls:', data.md5.length)
    console.log('Successful decryptions:', data.ok.length)
    console.log('Network calls:', data.net.length)

    if (data.ok.length > 0) {
        console.log('\n[✓] DECRYPTED URLs:')
        data.ok.forEach((r, i) => {
            console.log('  [' + i + '] URL:', r.url)
            console.log('      Key:', r.key)
            console.log('      IV: ', r.iv)
        })
    }

    if (data.md5.length > 0) {
        console.log('\n[MD5] Calls:')
        data.md5.forEach((m, i) => {
            console.log('  [' + i + '] MD5("' + m.in.substring(0, 80) + '") = ' + m.out)
        })
    }

    if (data.aes.length > 0) {
        console.log('\n[AES] Calls:')
        data.aes.forEach((a, i) => {
            const status = a.ok ? '✓' : a.err ? '✗' : '·'
            console.log('  [' + i + '] ' + status + ' key=' + (a.key || '?').substring(0, 40) + ' iv=' + (a.iv || '?').substring(0, 32))
            if (a.utf8) console.log('        → ' + a.utf8.substring(0, 100))
            if (a.err) console.log('        err: ' + a.err)
        })
    }

    if (data.net.length > 0) {
        console.log('\n[NET] Requests:')
        data.net.forEach((n, i) => {
            console.log('  [' + i + '] ' + n.method + ' ' + (n.url || '?').substring(0, 80))
            if (n.body) console.log('        body: ' + n.body.substring(0, 200))
        })
    }

    // 保存完整日志
    const outfile = 'hook-result.json'
    writeFileSync(outfile, JSON.stringify(data, null, 2))
    console.log('\n[*] Full log saved to:', outfile)

    // 推导 key derivation
    if (data.ok.length > 0 && data.md5.length > 0) {
        console.log('\n[HINT] To derive key algorithm, compare:')
        console.log('  MD5 input → MD5 output (32 hex chars)')
        console.log('  AES key/iv (32 hex chars each)')
        console.log('  Look for pattern: key = hexAscii(md5.slice(...)), iv = hexAscii(md5.slice(...))')
    }
})()
