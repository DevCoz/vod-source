---
name: decode-js
description: JavaScript deobfuscation tool based on Babel AST analysis. Handles jsjiami.com (v6/v7), javascript-obfuscator, sojson, jjencode, and common obfuscation patterns. Use when encountering obfuscated JavaScript code that needs to be deobfuscated for analysis.
version: 1.0.0
tags: [javascript, deobfuscation, reverse-engineering, babel]
---

# decode-js

JavaScript 反混淆工具，基于 Babel AST 分析。安装在 `~/tools/decode-js/`。

## 支援的混淆类型

| 类型 | 说明 | 指令 |
|------|------|------|
| `common` | 高频局部混淆（死代码、控制流扁平化等） | `decode-js -t common` |
| `sojson` | jsjiami.com v6 混淆 | `decode-js -t sojson` |
| `sojsonv7` | jsjiami.com v7 混淆 | `decode-js -t sojsonv7` |
| `obfuscator` | javascript-obfuscator 混淆 | `decode-js -t obfuscator` |
| `jjencode` | JJEncode 编码 | `decode-js -t jjencode` |
| `awsc` | 阿里云 AWSC 混淆 | `decode-js -t awsc` |

## 使用方式

```bash
# 基本用法
decode-js -t <type> -i <input.js> -o <output.js>

# 范例：反混淆 jsjiami.com v6
decode-js -t sojson -i obfuscated.js -o decoded.js

# 范例：反混淆 javascript-obfuscator
decode-js -t obfuscator -i obfuscated.js -o decoded.js
```

## 自动侦测混淆类型

如果不知道混淆类型，可以按顺序尝试：

1. 先试 `sojson`（jsjiami.com v6 最常见）
2. 再试 `sojsonv7`（v7 版本）
3. 再试 `obfuscator`（javascript-obfuscator）
4. 最后试 `common`（通用处理）

识别方法：
- 看到 `_0xodk = 'jsjiami.com.v6'` → 用 `sojson`
- 看到 `_0xodk = 'jsjiami.com.v7'` → 用 `sojsonv7`
- 看到大量 `_0x` 开头变量 + 字符串阵列旋转 → 用 `obfuscator`
- 看到 `var _=~[];var __=~[];` 等 JJEncode 特征 → 用 `jjencode`

## 环境需求

- Node.js 22+（已安装在 `$NODE_HOME/`）
- decode-js 位于 `~/tools/decode-js/`
- wrapper 脚本：`~/tools/decode-js/decode-js`

## 注意事项

- 输入文件只能包含混淆代码，不能有其他非混淆内容
- `sojson` 类型对 jsjiami.com v6 效果最好（能解开 stringArray、控制流等）
- `sojsonv7` 可能对某些变体不稳定
- 解混淆后的代码可能仍需手动分析（如加密函数的 key/IV）
