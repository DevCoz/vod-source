# XPTV 开发工具包 (XPTV Development Toolkit)

三个 Hermes Agent Skill 的整合包，用于开发、调试和分析 XPTV 本地脚本（`.xptv.js`）。

## 包含的 Skill

### 1. xptv-script-development
XPTV 本地脚本开发指南。涵盖：
- 六个必要接口（`getLocalInfo`, `getConfig`, `getCards`, `getTracks`, `getPlayinfo`, `search`）
- MacCMS API 源、HTML 抓取源、网盘源 三种类型
- AES-CBC 解密、base64 处理、player_aaaa 解析
- TVBox 脚本转换、Douban API、体育直播 filter
- SPA/SSR 网站处理、图片 CDN 兼容性
- 大量实战案例和可复用的 pattern

### 2. xptv-script-debugging
XPTV 脚本调试工具指南。涵盖：
- 本地 Node.js harness 测试（smoke test、单步执行）
- 六步烟雾测试流程
- 常见错误诊断树
- GeeTest CAPTCHA、rate limiting、obfuscated code 处理
- 案例研究：91porn、heiliao、radio.cn、kisskh、lmm85 等

### 3. decode-js
JavaScript 反混淆工具指南。支持：
- jsjiami.com v6/v7 (`sojson` / `sojsonv7`)
- javascript-obfuscator (`obfuscator`)
- JJEncode (`jjencode`)
- 阿里云 AWSC (`awsc`)
- 通用局部混淆 (`common`)

## 环境需求

### XPTV 脚本开发
- XPTV App（执行 `.xptv.js` 脚本）
- 无需额外安装 — 脚本在 XPTV 的 JavaScriptCore 环境中执行

### XPTV 脚本调试
- Node.js 22+
- xptv-debugger harness（`xptv_harness.js`）
- 脚本存放目录（默认 `~/.xptv-scripts/`）

### decode-js
- Node.js 22+
- decode-js 工具（需另行安装）

## 快速开始

### 写一个新源

1. 阅读 `SKILL.md` 了解接口规范
2. 从 `templates/base.xptv.js` 开始
3. 根据目标站点类型（MacCMS / HTML 抓取 / 网盘）选择对应模板
4. 实现六个接口，确保每个都用 `jsonify()` 包裹

### 调试脚本

```bash
# 烟雾测试
node xptv_harness.js smoke ~/.xptv-scripts/my_script.xptv.js --keyword 测试

# 单步执行
node xptv_harness.js run ~/.xptv-scripts/my_script.xptv.js --fn getPlayinfo --ext '{"url":"..."}'

# 分析站点类型
node xptv_harness.js analyze https://example.com
```

### 反混淆 JS

```bash
# jsjiami.com v6
decode-js -t sojson -i obfuscated.js -o decoded.js

# javascript-obfuscator
decode-js -t obfuscator -i obfuscated.js -o decoded.js
```

## 目录结构

```
xptv-toolkit/
├── SKILL.md                              # 主开发指南（精简版，引用 knowledge/）
├── README.md                             # 本文件
├── xptv_harness.js                       # CLI 测试工具
├── templates/
│   └── base.xptv.js                      # 基础脚本模板
├── knowledge/
│   ├── xptv-api-reference.md             # 六大接口参考
│   ├── xptv-toolbox.md                   # 工具函数库
│   ├── xptv-templates.md                 # 9 个模板（MacCMS/HTML/网盘/直播/iframe/Smart Play）
│   ├── xptv-dev-guide.md                 # 创建新源的执行步骤
│   ├── xptv-debug-guide.md               # 调试流程、错误速查表
│   ├── xptv-patterns.md                  # 27 种可复用代码模式
│   ├── xptv-case-studies.md              # 实战逆向案例（kisskh/douyu/libvio 等）
│   ├── xptv-debugging-case-studies.md    # 调试案例（CupFox/91porn/heiliao 等）
│   ├── xptv-troubleshooting.md           # 常见问题排查
│   ├── xptv-runtime-debug.md             # Puppeteer hook 反混淆
│   ├── xptv-anti-bot.md                  # 反爬虫和 CAPTCHA 处理
│   ├── xptv-image-cdn-compatibility.md   # 图片 CDN 兼容性表
│   └── xptv-pr-workflow.md               # Git/PR 工作流
├── dev-toolkit/
│   ├── server/server.js                  # Express 测试服务器
│   ├── utils/utils.js                    # $fetch / jsonify / argsify 模拟
│   ├── src/debug.js                      # 你的源码（在此编辑）
│   ├── rollup.config.js                  # ES module → XPTV 格式转换
│   └── package.json
└── decode-js/
    ├── SKILL.md                          # JS 反混淆指南
    ├── src/main.js                       # 主入口
    └── src/plugin/                       # 各混淆器插件
```

## License

MIT
