/**
 * XPTV 站点截图工具 — 用 Puppeteer 截取目标站点页面
 * 用途：分析页面结构、检查选择器、调试图片加载
 *
 * 使用方法：
 *   npm install puppeteer-core
 *   node scripts/screenshot.mjs "https://example.com" [output.png]
 */

import puppeteer from 'puppeteer-core';

const TARGET_URL = process.argv[2] || 'https://example.com';
const OUTPUT = process.argv[3] || 'screenshot.png';

(async () => {
  const browser = await puppeteer.launch({
    executablePath: process.env.CHROME || '/usr/bin/chromium',
    headless: 'new',
    args: ['--no-sandbox', '--disable-setuid-sandbox', '--disable-gpu'],
  });

  const page = await browser.newPage();
  await page.setViewport({ width: 1280, height: 800 });
  await page.setUserAgent('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36');

  console.log(`[*] Navigating to ${TARGET_URL}...`);
  try {
    await page.goto(TARGET_URL, { waitUntil: 'networkidle2', timeout: 30000 });
  } catch (e) {
    console.log('[!] Page load timeout, proceeding with screenshot...');
  }

  await page.screenshot({ path: OUTPUT, fullPage: true });
  console.log(`[✓] Screenshot saved to ${OUTPUT}`);

  // 输出页面基本信息
  const info = await page.evaluate(() => ({
    title: document.title,
    imgCount: document.querySelectorAll('img').length,
    linkCount: document.querySelectorAll('a').length,
    hasNuxt: !!document.querySelector('[data-server-rendered]') || !!window.__NUXT__,
    hasReact: !!document.querySelector('[data-reactroot]'),
    firstImgs: Array.from(document.querySelectorAll('img')).slice(0, 5).map(img => ({
      src: img.src?.substring(0, 100),
      dataSrc: img.dataset?.src?.substring(0, 100) || '',
    })),
  }));

  console.log('\n[*] Page Info:');
  console.log(`  Title: ${info.title}`);
  console.log(`  Images: ${info.imgCount}, Links: ${info.linkCount}`);
  console.log(`  SPA: ${info.hasNuxt ? 'Nuxt' : info.hasReact ? 'React' : 'No'}`);
  if (info.firstImgs.length) {
    console.log('  First images:');
    info.firstImgs.forEach((img, i) => {
      console.log(`    [${i}] src: ${img.src}`);
      if (img.dataSrc) console.log(`        data-src: ${img.dataSrc}`);
    });
  }

  await browser.close();
})();
