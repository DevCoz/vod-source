# XPTV Debugger — Git & PR Workflow

## Check if script is from a fork

```bash
cd /path/to/repo
git remote -v                    # Check origin
git remote add upstream https://github.com/UPSTREAM/REPO.git
git fetch upstream
git diff main upstream/main -- js/script.js
```

## PR creation workflow

```bash
git checkout -b fix-description
git commit -m "fix: description"
git push origin fix-description
# Create PR via GitHub web or gh CLI
```

## Authentication (automated environments)

**Recommended:** GitHub Personal Access Token via curl:
```bash
curl -H "Authorization: token YOUR_GITHUB_TOKEN" \
  -X POST https://api.github.com/repos/UPSTREAM/REPO/pulls \
  -d '{"title":"Fix","body":"Description","head":"fork:branch","base":"main"}'
```

**gh CLI:**
```bash
export GH_TOKEN="your_token"
gh pr create --base upstream:main --head your-branch --title "Title" --body "Body"
```

**Limitations:**
- `gh auth login --web` requires interactive terminal (device code flow)
- Background processes can't reliably handle interactive prompts
- Token needs `repo` scope (private) or `public_repo` (public)
