XPTV开发文档

## 工具库
```js
// 常用库
const $config = argsify($config_str)
const cheerio = createCheerio()
const CryptoJS = createCryptoJS()

// 配置
$config_str

// 日志打印
$print("xxx") // http://ip:8110/log

// 网络请求
const { data } = $fetch.get('http://xx.com', {headers: {}})
const { data } = await $fetch.post('http://xx.com', {name: 'xx'}, {headers: {}})
const json = argsify(data)

// 缓存
const v = $cache.get('key')
$cache.set('key', 'value')
$cache.del('key')

// 提示
$utils.toastInfo('xxx')
$utils.toastError('xxx')

// 系统
$utils.os() // tvOS/18.1

// 版本
$utils.app() // 2.0
```

## 接口定义
```js
// 本地js文件才需要此方法
async function getLocalInfo() {
  const appConfig = {
    ver: 1,
    name: "玩偶哥哥(本地)",
    api: "csp_wogg_local",
  }
  return jsonify(appconfig)
}

async function getConfig() {
  const appConfig = {
    ver: 1,
    title: "xxx",
    site: "https://xxx.com/",
    tabs: [{
      name: '最近更新',
      ext: {  // ext在当请求 getCards 回传
        id: 0,
      },
    }]
  }
  return jsonify(appconfig)
}

async function getCards(ext) {
  ext = argsify(ext)
  // ext.filters: [String: String]?，与 filter[].key 对应
  const { page, id, filters = {} } = ext
  let cards = []
  return jsonify({
      list: [{
        vod_id: '',
        vod_name: '',
        vod_pic: '',
        vod_remarks: '',
        ext: {  // ext在当请求 getTracks 回传
          url: `xxx`,
        },
      }],
      filter: [{
        key: 'type',
        name: '类型',
        init: 'all',
        value: [
          { n: '全部', v: 'all' },
          { n: '喜剧', v: '喜剧' },
        ],
      }],
  });
}

async function getTracks(ext) {
  ext = argsify(ext)
  const { url } = ext
  return jsonify({
      list: [{
        title: '默认',
        tracks: [{
          name: '',
          pan: '', // 网盘
          ext: {  // ext在当请求 getPlayinfo 回传
            url: '', 
          }
        }]
      }],
  });
}

async function getPlayinfo(ext) {
  ext = argsify(ext)
  let url = ext.url
  return jsonify({ 
    urls: [url],
    headers: [{'User-Agent': '', Referer: ''}], // 可选
  })
}

async function search(ext) {
  ext = argsify(ext)
  let cards = []
  return jsonify({
      list: cards,
  })
}
```

### getCards 过滤协议

- 请求入参：
  - `ext.id`: 当前 tab/class 标识（可选）
  - `ext.page`: 分页请求参数（可选，仅请求侧使用）
  - `ext.filters`: 筛选参数字典（可选），类型为 `[String: String]?`
    - 键名与响应 `filter[].key` 一致
    - 例如：`{ "id": "home", "page": 1, "filters": { "type": "all" } }`
- 响应字段：
  - `list`: 卡片数组
  - `filter`: 筛选定义数组（可选）

`filter` 结构：

```json
[
  {
    "key": "type",
    "name": "类型",
    "init": "all",
    "value": [
      { "n": "全部", "v": "all" },
      { "n": "喜剧", "v": "喜剧" }
    ]
  }
]
```

请求/响应约定：

 - `filter[].key` 对应下一次请求的 `ext.filters[key]`。
 - 请求缺少某个筛选键时，脚本应按该项 `init` 处理。
- 如果响应没有 `filter` 字段（或为空），视为无筛选页面。
- 非法筛选值建议回退到 `init`（或 `all`）以保证正常返回 `list`。
