# XPTV 运行时调试 — 混淆代码逆向

## 何时使用

当 getPlayinfo 的加密逻辑被 **jsjiami.com v6** 或其他混淆工具保护时，静态分析（正则、AST、手动阅读）通常不可行。此时需要 **运行时 hook**：让浏览器实际执行混淆代码，同时拦截 CryptoJS 调用以捕获真实参数。

**典型症状：**
- `execB()` / `execA()` 函数名存在但内部全是 `_0x` 变量
- 正则提取到 `timestamp` / `secretKeySeed` 但解密全部返回空
- 尝试了 10+ 种 key/IV 组合无一命中
- 代码包含 RC4 字符串解密、死代码注入、反调试检测

## 前置条件

- 系统安装了 Chromium / Chrome（`which chromium` 或 `which google-chrome`）
- Node.js 可用
- 可以 `npm install puppeteer-core`（不需要下载浏览器）

## 流程总览

```
1. 获取目标页面 HTML（curl / web_fetch）
2. 识别加密函数（execB / decrypt / decode）和变量（timestamp, secretKeySeed）
3. 识别 API endpoint（grep ticktockwow / smartplay / webvideo）
4. 用 Puppeteer + CryptoJS hook 运行页面，捕获真实 key/IV
5. 还原 key derivation 算法，写入 XPTV 脚本
```

## Step 1: 侦察（不启动浏览器）

```bash
# 1. 获取播放页 HTML，找到 player_aaaa 和 iframe URL
curl -s 'https://example.com/play/xxx-1-1.html' -H 'User-Agent: Mozilla/5.0' | \
  grep -oP 'player_aaaa\s*=\s*\{[^;]*\}'

# 2. 获取 artplayer / iframe 页面，找到 CryptoJS + execB
curl -s 'https://example.com/static/player/artplayer/?url=XXX' \
  -H 'User-Agent: Mozilla/5.0' \
  -H 'Referer: https://example.com/play/xxx-1-1.html' | \
  grep -oP '(const|var|let)\s+(isSmartPlay|secretKeySeed|timestamp|playPageUrl)\s*=\s*[^;]+'

# 3. 搜索 API endpoint
curl -s 'https://example.com/static/player/artplayer/?url=XXX' \
  -H 'User-Agent: Mozilla/5.0' | \
  grep -oP 'https?://[^\s"\\]+' | grep -iE 'api|smart|play|webvideo' | sort -u

# 4. 搜索混淆标识
curl -s 'https://example.com/static/player/artplayer/?url=XXX' \
  -H 'User-Agent: Mozilla/5.0' | head -5
# 确认是否有 jsjiami.com.v6 标记
```

## Step 2: Puppeteer Hook 脚本

创建 `hook-capture.js`：

```javascript
const puppeteer = require('puppeteer-core');

// ★ 替换为实际的 artplayer iframe URL
const TARGET_URL = 'https://example.com/static/player/artplayer/?url=HEX_ENCODED_URL';
const REFERER = 'https://example.com/play/xxx-1-1.html';

(async () => {
  const browser = await puppeteer.launch({
    executablePath: '/usr/bin/chromium',  // 或 '/usr/bin/google-chrome'
    headless: 'new',
    args: ['--no-sandbox', '--disable-setuid-sandbox', '--disable-gpu'],
  });

  const page = await browser.newPage();
  await page.setUserAgent('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36');
  await page.setExtraHTTPHeaders({ 'Referer': REFERER });

  // ★ 关键：在页面脚本执行前注入 hook
  await page.evaluateOnNewDocument(`
    window.__AES__ = [];
    window.__MD5__ = [];
    window.__OK__ = [];
    window.__NET__ = [];

    // 拦截网络请求（捕获 API endpoint 和参数）
    const OrigXHR = XMLHttpRequest;
    XMLHttpRequest = function() {
      const xhr = new OrigXHR();
      const origSend = xhr.send;
      xhr.send = function(body) {
        if (body) window.__NET__.push({ method: 'POST', url: this.__url, body: String(body).substring(0, 500) });
        return origSend.apply(this, arguments);
      };
      const origOpen = xhr.open;
      xhr.open = function(m, u) { this.__url = u; return origOpen.apply(this, arguments); };
      return xhr;
    };

    const origFetch = window.fetch;
    window.fetch = async function(...args) {
      const url = typeof args[0] === 'string' ? args[0] : args[0]?.url;
      const body = args[1]?.body;
      window.__NET__.push({ method: 'FETCH', url, body: String(body).substring(0, 500) });
      return origFetch.apply(this, args);
    };

    // 等 CryptoJS 加载后自动 hook
    const _iv = setInterval(() => {
      if (typeof CryptoJS !== 'undefined' && !window.__CH__) {
        window.__CH__ = true;
        clearInterval(_iv);

        const _aes = CryptoJS.AES.decrypt;
        const _md5 = CryptoJS.MD5;

        CryptoJS.AES.decrypt = function(ct, key, cfg) {
          const rec = { key: null, iv: null };
          try { rec.key = key?.toString?.(); } catch {}
          try { rec.iv = cfg?.iv?.toString?.(); } catch {}
          try {
            const d = _aes.call(this, ct, key, cfg);
            const t = d.toString(CryptoJS.enc.Utf8);
            rec.utf8 = t?.substring(0, 300);
            rec.ok = t?.startsWith('http') || t?.includes('.m3u8');
            if (rec.ok) {
              window.__OK__.push({ url: t, key: rec.key, iv: rec.iv });
              console.log('[CAP-AES] ✓ ' + t.substring(0, 100));
            }
          } catch(e) { rec.err = e.message; }
          window.__AES__.push(rec);
          return _aes.call(this, ct, key, cfg);
        };

        CryptoJS.MD5 = function(msg) {
          const r = _md5.call(this, msg);
          window.__MD5__.push({ in: String(msg).substring(0, 200), out: r.toString() });
          return r;
        };

        console.log('[HOOK] CryptoJS hooked');
      }
    }, 50);
  `);

  // 捕获 API 响应
  page.on('response', async (res) => {
    if (res.url().includes('api') || res.url().includes('smart') || res.url().includes('webvideo')) {
      try {
        const t = await res.text();
        console.log('[API-RES]', res.status(), res.url().substring(0, 80), '→', t.substring(0, 200));
      } catch {}
    }
  });

  console.log('[*] navigating...');
  try { await page.goto(TARGET_URL, { waitUntil: 'networkidle0', timeout: 50000 }); }
  catch { console.log('[!] timeout (ok)'); }

  console.log('[*] waiting 12s...');
  await new Promise(r => setTimeout(r, 12000));

  const data = await page.evaluate(() => ({
    aes: window.__AES__ || [], md5: window.__MD5__ || [],
    ok: window.__OK__ || [], net: window.__NET__ || [],
  }));

  console.log('\n===== CAPTURE =====');
  console.log('AES:', data.aes.length, 'MD5:', data.md5.length, 'OK:', data.ok.length);

  if (data.ok.length) {
    console.log('\n[✓] DECRYPTED:');
    data.ok.forEach(r => console.log('  URL:', r.url, '\n  Key:', r.key, '\n  IV:', r.iv));
  }
  if (data.md5.length) {
    console.log('\nMD5 calls:');
    data.md5.forEach(m => console.log('  MD5("' + m.in.substring(0, 60) + '") = ' + m.out));
  }
  if (data.aes.length) {
    console.log('\nAES calls:');
    data.aes.forEach(a => console.log('  key=' + (a.key||'?').substring(0,32) + ' iv=' + (a.iv||'?').substring(0,32) + (a.ok?' ✓':'')));
  }
  if (data.net.length) {
    console.log('\nNetwork:');
    data.net.forEach(n => console.log('  ' + n.method + ' ' + (n.url||'?').substring(0, 80) + (n.body ? ' body=' + n.body.substring(0, 200) : '')));
  }

  await browser.close();
})();
```

## Step 3: 运行并分析

```bash
cd /path/to/project
npm install puppeteer-core
node hook-capture.js
```

### 分析输出

**AES 调用** — 每行是一次 `CryptoJS.AES.decrypt` 调用：
```
key=30346135626562386433383666383033 iv=39323564373830663934653036373930 ✓ → https://...
```
- `key` 和 `iv` 是十六进制字符串（32 hex chars = 16 bytes = 128-bit AES key）
- `✓` 表示解密成功，`→` 后面是解密出的 URL

**MD5 调用** — 每行是一次 `CryptoJS.MD5` 调用：
```
MD5("1776481236RY7e48naFXPsLJC") = 925d780f94e0679004a5beb8d386f803
```
- `in` 是 MD5 输入（可能包含 timestamp 和隐藏 secret）
- `out` 是 MD5 输出（32 hex chars）
- **对比 AES key/iv 可以还原 key derivation 算法**

**Network 调用** — API endpoint 和请求参数：
```
FETCH https://hd.ticktockwow.com/smartplay-cache/api/webvideo_ty.php body={"vkey":"...","code":"...","t":1776482614,"signature":"..."}
```

## Step 4: 还原 Key Derivation

拿到 AES key/iv 和 MD5 输入/输出后，推导算法：

```javascript
// 示例：从 hook 输出还原
// MD5("1776481236RY7e48naFXPsLJC") = 925d780f94e0679004a5beb8d386f803
// AES key = 30346135626562386433383666383033
// AES IV  = 39323564373830663934653036373930

// 推导: key = MD5 hex 后 16 字符的 ASCII hex 编码
//        IV = MD5 hex 前 16 字符的 ASCII hex 编码
const md5Hex = '925d780f94e0679004a5beb8d386f803';
// 前 16: '925d780f94e06790' → 每个字符转 ASCII hex → '39323564373830663934653036373930' = IV ✓
// 后 16: '04a5beb8d386f803' → 每个字符转 ASCII hex → '30346135626562386433383666383033' = Key ✓

// 函数封装:
function toHexAscii(s) {
  return Array.from(s).map(c => c.charCodeAt(0).toString(16).padStart(2, '0')).join('');
}
const key = CryptoJS.enc.Hex.parse(toHexAscii(md5Hex.slice(16, 32)));
const iv  = CryptoJS.enc.Hex.parse(toHexAscii(md5Hex.slice(0, 16)));
```

## 常见模式速查

| 症状 | 可能原因 | 方案 |
|------|---------|------|
| `execB` 内全是 `_0x` 变量 | jsjiami.com v6 混淆 | 运行时 hook |
| 解密输出全是空 | Key derivation 不对 | 对比 MD5 输入和 AES key 推导 |
| AES key 看起来像 ASCII | hex 字符的 ASCII 编码 | `toHexAscii()` 转换 |
| API 签名验证失败 | 签名算法不同 | hook MD5 捕获签名计算 |
| hook 没捕获到任何调用 | hook 注入太晚 | 用 `evaluateOnNewDocument` |
| CryptoJS 未定义 | 页面用 `crypto-js.min.js` 内联 | 等待加载后替换（setInterval 检测） |

## ⚠️ 注意事项

- 隐藏 secret（如 `RY7e48naFXPsLJC`）随站点版本变化
- 每次站点更新后建议重新 hook 验证
- API endpoint 和签名算法也可能变化
- `puppeteer-core` 比 `puppeteer` 更轻量（不下载浏览器）
