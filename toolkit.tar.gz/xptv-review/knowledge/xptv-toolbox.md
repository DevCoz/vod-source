# XPTV Toolbox — 工具函数参考

## $config_str — 源配置参数

XPTV 导入源时传入的配置字符串（在源设置中填写），脚本中通过 `$config_str` 获取：

```js
const config = argsify($config_str)
// 例如导入时 ext 填了 {"api": "http://192.168.1.100:3000"}
// 则 config.api === "http://192.168.1.100:3000"

// 常见用法：本地调试代理，从配置读取 server 地址
const api = config.api || 'http://localhost:3000'
```

---

## $fetch — HTTP 请求

### GET
```js
const { data } = await $fetch.get('http://xx.com', {
  headers: { 'User-Agent': UA, 'Referer': SITE }
});
```

### POST ⚠️ 关键格式
```js
// ✅ 正确：三参数 — url, body, { headers }
const { data } = await $fetch.post('http://xx.com', { key: 'value' }, {
  headers: { 'Content-Type': 'application/json' }
});

// ✅ POST 表单（字符串 body）
const { data } = await $fetch.post('http://xx.com', 'key=value&foo=bar', {
  headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
});

// ❌ 错误：{ data, headers } 塞在第二个参数 — 不支持
const { data } = await $fetch.post('http://xx.com', {
  data: { key: 'value' },
  headers: { 'Content-Type': 'application/json' }
});
```

### 解析响应
```js
const json = argsify(data);  // JSON string → object
```

---

## createCheerio() — HTML 解析

```js
const cheerio = createCheerio();
const $ = cheerio.load(htmlData);

// 选择
const title = $('h1').text();
const link = $('a').attr('href');
const img = $('img').attr('src');

// 遍历
$('.item').each((i, el) => {
  const $el = $(el);
  const name = $el.find('h2').text().trim();
});

// 过滤
const items = $('article.bs');        // class 选择
const first = items.first();          // 第一个
const href = $el.find('a').first().attr('href');
```

---

## createCryptoJS() — 加密解密

```js
const CryptoJS = createCryptoJS();

// Base64 解码（JSC 沙箱中必须用这个）
const decoded = CryptoJS.enc.Utf8.stringify(
  CryptoJS.enc.Base64.parse(base64Str)
);

// Base64 编码
const encoded = CryptoJS.enc.Base64.stringify(
  CryptoJS.enc.Utf8.parse(text)
);

// AES 解密
const decrypted = CryptoJS.AES.decrypt(encrypted, key)
  .toString(CryptoJS.enc.Utf8);
```

---

## Base64 兼容函数

```js
function base64Decode(str) {
  try {
    if (typeof Buffer !== 'undefined') {
      return Buffer.from(str, 'base64').toString();
    } else if (typeof atob !== 'undefined') {
      return atob(str);
    } else {
      const CryptoJS = createCryptoJS();
      return CryptoJS.enc.Utf8.stringify(
        CryptoJS.enc.Base64.parse(str)
      );
    }
  } catch (e) {
    return '';
  }
}
```

---

## URL 编解码

```js
const encoded = encodeURIComponent(text);
const decoded = decodeURIComponent(text);
```

---

## 缓存

```js
const v = $cache.get('key');
$cache.set('key', 'value');
$cache.del('key');
```

---

## 系统信息

```js
$utils.os()        // "tvOS/18.1"
$utils.app()       // "2.0"
$utils.toastInfo('提示信息')
$utils.toastError('错误信息')
$print('调试日志')  // 输出到 http://ip:8110/log
```

---

## 常用请求头模板

```js
const UA = 'Mozilla/5.0 (iPhone; CPU iPhone OS 16_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.0 Mobile/15E148 Safari/604.1';

const PC_UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36';

const headers = {
  'User-Agent': UA,
  'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
  'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8',
  'Referer': SITE + '/'
};
```

---

## getCards ext 解构参考

```js
async function getCards(ext) {
  ext = argsify(ext);
  const { page = 1, id, filters = {} } = ext;
  // id: 当前 tab/class 标识（来自 tabs[].ext.id）
  // page: 分页，默认 1
  // filters: 筛选参数字典（来自 filter[].key）
  //   例如: { "type": "all", "year": "2024" }
}
```

### Filter 协议速查

- `filter[].key` → 下次请求的 `ext.filters[key]`
- 请求缺少某个筛选键时，按该项 `init` 处理
- 非法值回退到 `init`
- 响应无 `filter` 字段 → 无筛选页面

```js
// 响应中定义筛选
return jsonify({
  list: [...],
  filter: [{
    key: 'type',        // → ext.filters.type
    name: '类型',
    init: 'all',        // 默认值
    value: [
      { n: '全部', v: 'all' },
      { n: '喜剧', v: '喜剧' }
    ]
  }]
});
```

### GET 高级参数
```js
// timeout: 请求超时（毫秒）
const { data } = await $fetch.get(url, { headers: { ... }, timeout: 20000 });

// respHeaders: 访问响应头
const resp = await $fetch.get(url, { headers: { ... } });
const setCookie = resp.headers['set-cookie'];   // 或 resp.respHeaders
const rawBody = resp.data;                       // 响应体
```

### POST 返回值
```js
const resp = await $fetch.post(url, body, { headers: { ... } });
const json = typeof resp.data === 'string' ? JSON.parse(resp.data) : resp.data;
// resp.respHeaders — 部分环境使用 respHeaders 获取响应头
```

---

## 最佳实践（来自实战脚本）

### search 兼容 text 和 wd
```js
async function search(ext) {
  ext = argsify(ext);
  const { text, wd, page = 1 } = ext;
  const keyword = text || wd || '';  // 兼容两种命名
  // ...
}
```

### vod_duration 卡片附加信息
```js
// 卡片上显示额外信息（在线人数、主播名等）
list.push({
  vod_id: e.rid.toString(),
  vod_name: e.roomName,
  vod_pic: e.roomSrc,
  vod_duration: `🔥${e.hn} | ${e.nickname}`,  // 非标准但广泛使用
  ext: { id: e.rid.toString() }
});
```

### Cookie 手动管理（过盾场景）
```js
function createCookieJar() { return {}; }

function mergeSetCookie(jar, setCookieHeaders) {
  const values = Array.isArray(setCookieHeaders) ? setCookieHeaders : [setCookieHeaders];
  for (const raw of values) {
    const first = String(raw).split(';')[0];
    const idx = first.indexOf('=');
    if (idx <= 0) continue;
    jar[first.slice(0, idx).trim()] = first.slice(idx + 1).trim();
  }
}

function cookieHeaderStr(jar) {
  return Object.entries(jar).map(([k, v]) => `${k}=${v}`).join('; ');
}

// 使用: 从 resp.headers['set-cookie'] 提取, 拼接后作为 Cookie 头发送
mergeSetCookie(jar, resp.headers?.['set-cookie'] || []);
const cookie = cookieHeaderStr(jar);
```

### 全局 try-catch + 兜底返回
```js
async function getConfig() {
  try {
    // ... 正常逻辑
    return jsonify({ ver: 1, title: 'xxx', site: SITE, tabs: [...] });
  } catch (error) {
    console.error('getConfig error:', error.message || error);
    // 兜底：即使失败也返回有效结构，不返回空
    return jsonify({ ver: 1, title: 'xxx', site: SITE, tabs: [{ name: '全部', ext: { id: 'all' } }] });
  }
}
```

### CDN × 画质矩阵（直播源）
```js
// 先请求一次拿 CDN 列表 + 画质列表
const firstRes = await $fetch.post(url, toQS({...baseParams, rate: '0'}), { headers });
const { cdnsWithName, multirates } = argsify(firstRes.data).data;

// 双重循环：每条CDN × 每个画质
for (const cdn of cdnsWithName.slice(0, 3)) {
  for (const q of multirates.slice(0, 5)) {
    const res = await $fetch.post(url, toQS({...baseParams, rate: q.rate, cdn: cdn.cdn}), { headers });
    // 收集播放地址...
  }
}
```

### toQueryString 工具函数
```js
function toQueryString(obj) {
  return Object.keys(obj)
    .filter(k => obj[k] != null && obj[k] !== '')
    .map(k => `${k}=${obj[k]}`)
    .join('&');
}
```

### 随机设备 ID（防限连）
```js
function randHex(len) {
  return Array.from({ length: len }, () => Math.floor(Math.random() * 16).toString(16)).join('');
}
const did = randHex(32);

// 常见用法：作为 Cookie 或 API 参数
headers: { Cookie: `dy_did=${did}; acf_did=${did}` }
```
