# XPTV Debugger — Anti-Bot & Obfuscation Reference

## Rate Limiting

**Symptoms:** Search returns "没有搜索到相关的内容" even for known keywords. Intermittent failures.

**Diagnosis:**
1. Test with known keyword
2. Wait 30-60 seconds, retry
3. If succeeds after waiting → rate limiting confirmed

**Example (hanju7.com):** ~30 second interval required between searches.

**Key:** Some sites disguise rate limiting as empty results or "parameter error". Not a code bug.

---

## API Verification Errors (code:1004)

```json
{"code":1004,"data":null,"message":"请先完成验证"}
```

**What works:** getCards, getTracks
**What fails:** search, getPlayinfo → code:1004

**This is NOT a code bug** — server-side anti-bot enforcement. Cannot bypass without solving CAPTCHA or finding alternative endpoints.

**Workaround:** Add defensive null checks so script doesn't crash:
```javascript
var parsed = JSON.parse(response);
if (!parsed || !parsed.data) return jsonify({ list: [] });
```

---

## GeeTest v4 CAPTCHA

**Cannot be bypassed with pure JS.** Requires browser CDP for trusted mouse events.

### Browser Analysis Steps

1. **Find captcha_id:** `document.querySelector('[class*="geetest_captcha_"]')?.className.match(/geetest_captcha_([a-f0-9]+)/)?.[1]`

2. **Extract background image:** `document.querySelector('.geetest_bg')?.style.backgroundImage`

3. **Analyze cutout position** with canvas pixel analysis (~80px slider piece width)

4. **CDP drag simulation:**
   ```
   Input.dispatchMouseEvent type="mousePressed" x=startX y=startY button="left"
   Input.dispatchMouseEvent type="mouseReleased" x=endX y=endY button="left"
   ```

**Limitations:**
- JS `MouseEvent` has `isTrusted: false` → GeeTest rejects
- GeeTest analyzes mouse movement patterns (acceleration, jitter)
- GeeTest API behind Cloudflare — server-side fetch blocked
- Must be solved in-browser

---

## strencode2() — Encoded Video URLs (91porn)

**Site:** 91porn.com uses `strencode2()` to hide real MP4 URLs.

**Pattern:** The visible `<source src="...">` tag is commented out (fake/dead CDN). Real URL is URL-encoded hex inside `document.write(strencode2("..."))`.

**Extraction (JSC-safe, no decodeURIComponent needed):**
```javascript
const encodeMatch = data.match(/strencode2\(\"([^\"]+)\"\)/);
if (encodeMatch) {
    const mp4Match = encodeMatch[1].match(/https?%3a%2f%2f[^"'\s%]+\.mp4[^"'\s%]*/i);
    if (mp4Match) {
        videoUrl = mp4Match[0]
            .replace(/%3a/gi, ':').replace(/%2f/gi, '/')
            .replace(/%3f/gi, '?').replace(/%3d/gi, '=')
            .replace(/%26/gi, '&').replace(/%2b/gi, '+');
    }
}
```

**Anti-patterns to watch:**
- Commented-out `<source>` tags (`<!-- <source ... -->`)
- `strencode2()` / `strencode()` / `eval()` / `atob()` encoding
- Double-slash in CDN URLs (`//path/` → normalize to `/path/`)
- Multiple CDN domains (some dead, some alive)

---

## Patching Obfuscated Scripts

When script is obfuscated (e.g., jsjiami.com.v7), direct edits are fragile. Patch defensively.

### Adding null checks

Common crash: `JSON['parse'](...)['data']['list'].map(...)` when `data` is null.

```javascript
// Find the pattern
node -e 'const c=require("fs").readFileSync("script.js","utf8");const i=c.indexOf("JSON[");console.log(c.substring(i-20,i+150))'

// Patch: add null check before chained access
var _r=JSON['parse'](...);if(!_r||!_r['data'])return jsonify({'list':[]});return _r['data']['list'][...](...)
```

### Rules for obfuscated code patching:
1. Use exact string matching (whitespace matters)
2. Choose variable names unlikely to collide (e.g., `_0x305699r`)
3. Use `var` not `const` for compatibility
4. Test with full smoke test after patching
