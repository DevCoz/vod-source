## Known Image CDN Compatibility in XPTV

Tested 2026-04-14. XPTV's image loader (WebView) may not load images from certain CDNs even when the CDN has no hotlink protection.

| CDN Domain | Works in XPTV? | Sites Using It | Notes |
|---|---|---|---|
| `pic.cshsst.cn` | ❌ BLOCKED | heiliao.com, chigua.com, hsex.tv | Server returns 200 with any Referer, but XPTV cannot load. Possible SSL/TLS or UA issue in XPTV WebView. |
| `51cg1.com` | ✅ YES | chigua.com | Small images (logos) work fine |
| `hls.pirpbv.cn` | ✅ (video) | chigua.com | Video m3u8 works, but not tested as image CDN |
| `ic-vt-nss.xhcdn.com` | ✅ YES | xhamster.com | Thumbnails load fine |

### Workaround Attempts (All Failed for pic.cshsst.cn)

1. ❌ HTTP vs HTTPS — both fail in XPTV
2. ❌ Different Referer headers — server accepts any, XPTV still fails
3. ❌ Double-slash fix (`//upload` → `/upload`) — didn't help
4. ❌ URL trim — no whitespace issue
5. ❌ `//` to `https://` protocol fix — didn't help
6. ❌ og:image from article pages — returns site logo, not article images
7. ❌ JavaScript `loadBannerDirect()` extraction — URLs correct, XPTV can't load

### Recommendation

If a target site uses `pic.cshsst.cn` for images, accept that thumbnails will not display in XPTV. Focus on making article titles, playback, and search work correctly. This is a platform-level limitation that requires XPTV app update to fix.
