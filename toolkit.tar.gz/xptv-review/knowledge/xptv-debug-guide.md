# XPTV 脚本调试指南

## 调试流程

### D1: 收集信息
- 脚本内容
- 错误症状（列表为空？无法播放？搜索无结果？）
- 目标站点 URL

### D2: 定位问题

**当用户报告症状时，先收集信息（D1），再按症状匹配排查路径：**

| 症状                          | 优先检查                                     | 自动触发 |
|-------------------------------|---------------------------------------------|---------|
| 列表为空                       | 选择器、请求头、动态加载、编码               | 要求用户提供脚本+URL |
| 无法播放                       | getPlayinfo URL、Referer、加密               | 要求提供脚本+播放页URL |
| $fetch.post 异常               | 参数格式（三参数 vs 两参数）                 | 检查代码中 post() 调用 |
| Base64 失败                    | 用 CryptoJS，不用 Buffer/atob                | 搜索脚本中 Buffer/atob |
| 分页不工作                     | 参数名(page/pg/paged)、起始值                | 要求提供列表页URL |
| 搜索无结果                     | 参数名(wd/text/q)、编码                      | 要求提供搜索URL |
| 中文乱码                       | CDATA解析、URL编码                           | 要求提供原始响应 |
| 搜索被验证码拦截                | smart_verify、PHPSESSID cookie               | 检查响应含「安全验证」 |
| iframe 播放器无结果            | iframe src、POST 端点、token 解密            | 要求提供播放页URL+player_aaaa |
| SPA 站点列表为空               | 检测 __NUXT__/__NEXT_DATA__、找 API endpoint | web_fetch 分析页面 |
| 图片 CDN 不加载                | Referer/UA 热链接保护、XPTV WebView 限制     | 检查 image-cdn-compatibility |
| execB 解密失败                 | jsjiami 混淆 → 运行时 hook                   | grep jsjiami 标识 |

**🔎 自动修复**
定位到问题根因后直接修复，修复后重测验证。

### D3: 修复并验证
修复后再次执行 smoke test 检查清单。

## 诊断决策树

```
smoke test 失败
├─ 缺少必要函数？
│  └─ 加 stub: async function getLocalInfo() { return jsonify({name:"test",ver:1}) }
│
├─ getLocalInfo / getConfig 失败？
│  └─ 语法错误 → 检查 JS syntax
│
├─ getCards 空列表？
│  ├─ curl 测试站点是否存活 → 404/blocked = 站点挂了
│  ├─ 站点活着但空 → selector 变了，检查 HTML
│  └─ 参考 xptv-case-studies.md 中的 SSR 站点处理
│
├─ getTracks 失败？
│  └─ ext.url 缺失或详情页解析错误
│
├─ getPlayinfo 无 urls？
│  ├─ 播放器解析失败 → 试 multi-pattern fallback
│  └─ player_aaaa JSON.parse 报错 → 用 brace counting
│
├─ search 空结果？
│  ├─ 偶发 → rate limiting（等 30s 重试）
│  └─ 必现 → 参数格式错或 API 变了
│
└─ code:1004 / 请先完成验证？
   └─ GeeTest CAPTCHA → 无法在 harness 绕过，加 null check 防崩溃
```

## 错误速查表

| Error | 原因 | 修复 |
|-------|------|------|
| `Missing required functions` | 6 个接口没全实现 | 补齐缺失的接口 |
| `did not return a JSON string` | 返回了原始对象 | 包装: `return jsonify({...})` |
| `getCards returned empty list` | 选择器错误 / JS 渲染 | `curl` 原始 HTML 验证 |
| `getTracks returned no track groups` | 详情页解析失败 | 检查 `ext.url` 来自 getCards |
| `getPlayinfo no urls array` | schema 不对 | 所有路径必须返回 `jsonify({ urls: [] })` |
| `$config_str is not defined` | 需要配置的脚本 | `--config '{"token":"xxx"}'` |
| `fetch failed` | 站点挂了 | `curl -sI URL` 先确认 |
| `code:1004` | 需要 GeeTest 验证 | 无法绕过 — 加 null check |
| `JSON.parse` on `player_aaaa` 失败 | `lastIndexOf('}')` 位置错误 | 用 brace counting |
| Search 空（偶发） | 限流 ~30s | 等待后重试 |
| `argsify failed` | ext JSON 格式错误 | 检查 ext payload |

## 关键模式速查

### $fetch.post — 三参数（不是 axios 风格）
```javascript
await $fetch.post(url, 'key=value', { headers: {...} });        // form
await $fetch.post(url, jsonify({ wd: kw }), { headers: {...} }); // json
```

### $fetch 返回值 — 用 `respHeaders`
```javascript
const { data, respHeaders } = await $fetch.get(url, { headers });
// 用 respHeaders — 不是 headers，不是 responseHeaders
```

### cheerio — `.load(data)`
```javascript
var $ = createCheerio().load(data);  // ✅
var $ = createCheerio(data);          // ❌ 不会解析
```

### Player 解析 — 降级链
```javascript
// 1. window.PLAYER_CONFIG.m3u8
// 2. jwplayer().setup({ file: "..." })
// 3. player_aaaa = { url: "..." }  ← brace counting，不要用 lastIndexOf
// 4. 直接 .m3u8/.mp4 在 HTML 中
```

### JSON 转义的 HTML（jqqzx.cc 模式）
```javascript
if (data.charCodeAt(0) === 34) {  // 以 " 开头
  try { data = JSON.parse(data); } catch (e) {}
}
```

### HTTP→HTTPS（Android 兼容）
```javascript
if (url.startsWith('http://')) url = url.replace('http://', 'https://');
```

## 标准错误报告格式

```javascript
// 统一错误报告函数（所有脚本复用）
function reportError(interfaceName, url, error) {
  $print(`[${interfaceName}] ${url} → ${error.message || error}`)
}

// 使用示例
try {
  // ... 业务逻辑
} catch (e) {
  reportError('getPlayinfo', url, e)
  return jsonify({ urls: [] })
}
```

## Error Recovery

| 场景 | 处理 |
|------|------|
| 站点无法访问 | 检查 URL、UA、备用方案；尝试 HTTP 降级 |
| API 格式不符 | 打印前 500 字符分析；XML→JSON→HTML fallback |
| 加密未知 | 提供前端 JS 逆向；jsjiami → runtime-debug.md |
| 选择器不匹配 | web_fetch 分析 DOM；尝试 3+ 备选选择器 |
| SPA 无数据 | __NUXT__ 解析 / API endpoint / tag 页兜底 |
| 图片 CDN 不显示 | 平台限制，确保播放正常；检查 image-cdn-compatibility |
| getCards 空列表 | 确认站点存活(curl)；检查分页参数(page/pg/paged)；检查 UA/Referer |
| getTracks 空剧集 | 给兜底 track `{name:'播放', ext:{url}}`；检查详情页选择器 |
| 网络超时 | 设置 timeout 20s；重试 1 次；仍失败报告用户 |
| 搜索被 CAPTCHA 拦截 | 检测 smart_verify → POST 获取 token；无解则返回空+提示用户 |
| 分类 URL 404 | 检查 ?sort= / ?filter= 查询参数；对比导航与实际可访问 URL |
| $fetch 无法获取 cookie | 用 respHeaders（非 headers）取 Set-Cookie；手动拼接 Cookie 头 |
| 中文乱码 | XML 用 CDATA 正则；URL 用 encodeURIComponent |
| 同一站点多播放器类型 | 按 player_aaaa.from 分支处理（ykbox/vxdev/tudou/直接m3u8） |

## 验证清单

修复完成后确认：
- [ ] 所有 6 个接口都存在
- [ ] Smoke test 能跑到 `getPlayinfo()`
- [ ] `playinfo.urls` 是非空数组
- [ ] `search()` 返回 list 结构
- [ ] 无 schema 不匹配
