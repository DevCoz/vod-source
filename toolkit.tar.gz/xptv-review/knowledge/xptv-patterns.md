# XPTV 可复用模式库

经过实战验证的代码模式，可直接复用到新脚本中。

---

## Pattern 1: 图片方向检测（横式/直式 → ui: 1）

**用途**：确定卡片图片方向，在 `getConfig()` 中设置 `ui: 1`。

```bash
python3 -c "
import urllib.request, struct
def get_image_size(url):
    req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0', 'Range': 'bytes=0-8191'})
    data = urllib.request.urlopen(req).read()
    if data[:2] == b'\xff\xd8':
        i = 2
        while i < len(data) - 9:
            if data[i] == 0xff and data[i+1] in [0xc0,0xc1,0xc2]:
                return struct.unpack('>H',data[i+7:i+9])[0], struct.unpack('>H',data[i+5:i+7])[0]
            i += 2
    elif data[:8] == b'\x89PNG\r\n\x1a\n':
        return struct.unpack('>I',data[16:20])[0], struct.unpack('>I',data[20:24])[0]
    return None, None
for url in ['URL1','URL2','URL3']:
    w,h = get_image_size(url)
    if w and h: print(f'{w}x{h} -> {\"横式\" if w>h else \"直式\"}')"
```

**应用**：横式图片 → 每个 tab 加 `ui: 1`

---

## Pattern 2: WordPress 懒加载图片提取（extractImg）

**问题**：WordPress 站点 `$('img').attr('src')` 返回 `javascript:;` 占位符。

```js
function extractImg($el) {
  const $img = $el.find('img').first();
  if (!$img.length) return '';

  const attrs = [
    'data-lazy-src', 'data-src', 'data-original', 'data-lazy',
    'data-bg', 'data-srcset', 'data-thumb', 'data-poster',
    'data-image', 'data-lazy-srcset', 'src'
  ];

  for (const attr of attrs) {
    let val = $img.attr(attr) || '';
    if (!val || val === 'javascript:;' || val.startsWith('data:') ||
        val.includes('loading.gif') || val.length < 10) continue;
    if (attr.includes('srcset')) {
      val = val.split(',')[0].trim().split(/\s+/)[0];
    }
    if (val.startsWith('//')) val = 'https:' + val;
    if (val.startsWith('http') || val.startsWith('/')) return val;
  }

  // Fallback: background-image style
  const $bg = $el.find('[style*="background"]').first();
  if ($bg.length) {
    const style = $bg.attr('style') || '';
    const m = style.match(/url\(['"]?([^'")\s]+)/);
    if (m && m[1] && !m[1].startsWith('data:')) {
      let url = m[1];
      if (url.startsWith('//')) url = 'https:' + url;
      return url;
    }
  }
  return '';
}
```

**优先级**：`data-lazy-src`（WP Rocket）> `data-src` > `data-original` > `src`

---

## Pattern 3: iframe → external player → m3u8 提取（两步法）

**流程**：播放页有 iframe → 外部播放器域 → DPlayer 含 `var vid="m3u8"`

```js
// Step 1: 提取 iframe src
const iframeMatch = data.match(/<iframe[^>]+src=["']([^"']+)["']/i);
if (iframeMatch) {
  let iframeSrc = iframeMatch[1];
  if (iframeSrc.startsWith('/')) iframeSrc = SITE + iframeSrc;

  // Step 2: 获取 iframe 内容
  const { data: iframeData } = await $fetch.get(iframeSrc, {
    headers: { 'User-Agent': UA, 'Referer': url }
  });

  // Step 3: 提取播放 URL
  const vidMatch = iframeData.match(/var\s+vid\s*=\s*["']([^"']+)["']/);
  if (vidMatch && vidMatch[1]) {
    return jsonify({
      urls: [vidMatch[1]],
      headers: [{ 'User-Agent': UA, 'Referer': iframeSrc }]
    });
  }
}
```

**要点**：Referer 设为 iframe URL，外部播放器可能用 `var vid=`、`var url=` 或 DPlayer config。

---

## Pattern 4: SPA/SSR 框架检测

```js
const isSPA = data.includes('nuxt-link') || data.includes('__NUXT__') ||
              data.includes('__NEXT_DATA__') || data.includes('data-v-') ||
              data.includes('__NUXT_DATA__');
const hasPlaceholders = (data.match(/src="\/static\//g) || []).length > 5;

// 检测 SSR 数据嵌入
const nuxtMatch = data.match(/window\.__NUXT__\s*=\s*([\s\S]*?);?\s*<\/script>/);
const nextMatch = data.match(/<script id="__NEXT_DATA__"[^>]*>([\s\S]*?)<\/script>/);
```

---

## Pattern 5: SPA API Discovery Workflow

分阶段调试 SPA 站点：
1. **Phase 1**: Dump `<img>` 标签属性，确认是否全是占位符
2. **Phase 2**: 搜索原始 HTML 中的 CDN 域名和图片 URL
3. **Phase 3**: 分析页面结构（`__NUXT__`、`__INITIAL_STATE__`）
4. **Phase 4**: 扫描 REST API 路径（`/api/v1/list`、`/api/posts` 等）
5. **Phase 5**: 用发现的 API 构建生产脚本

---

## Pattern 6: `var pp` JSON 多线路

**场景**：详情页 JS 变量包含所有播放线路。

```js
const ppMatch = data.match(/var\s+pp\s*=\s*(\{[^;]+\});/);
if (ppMatch) {
  const pp = JSON.parse(ppMatch[1]);
  pp.la.forEach(item => {
    if (Array.isArray(item) && item.length >= 5) {
      tracks.push({
        name: item[1],        // 线路名
        ext: { url: item[4] } // m3u8 URL
      });
    }
  });
}
```

**要点**：`pp.la` 数组包含 `[lineId, lineName, ?, ?, m3u8Url]` 元组。

---

## Pattern 7: DPlayer config 属性提取

**场景**：DPlayer 播放器的 `config` 属性包含 JSON 播放配置。

```js
const configRegex = /config='([^']+)'/g;
let match, idx = 1;
while ((match = configRegex.exec(data)) !== null) {
  try {
    const config = JSON.parse(match[1].replace(/\\\//g, '/'));
    const videoUrl = config.video?.url || '';
    if (videoUrl) {
      tracks.push({ name: `视频${idx}`, ext: { url: videoUrl } });
      idx++;
    }
  } catch (e) { }
}
```

**要点**：一篇文章可有多个 DPlayer 实例，正则循环捕获全部。

---

## Pattern 8: `var player_aaaa` iframe 构造

**场景**：中国 VOD 站点常见，提取 `vid`、`url`、`from` 字段构造 iframe URL。

```js
const playerMatch = data.match(/var\s+player_aaaa\s*=\s*(\{[^<]+?\})\s*;?\s*<\/script>/);
if (playerMatch) {
  try {
    const player = JSON.parse(playerMatch[1]);
    const vid = player.vid || player.url || '';
    const from = player.from || '';
    // 根据 from 类型构造 iframe URL（参见案例 5）
  } catch (e) { }
}
```

**要点**：不要尝试还原 TVBox 的多步 API 调用链，直接构造 iframe URL 最简单。

---

## Pattern 9: Lazy-loaded image（loadImg 函数）

```js
const imgEl = $el.find('img[onload]');
const onload = imgEl.attr('onload') || '';
const imgMatch = onload.match(/loadImg\([^,]+,'([^']+)'/);
const img = imgMatch ? imgMatch[1] : '';
```

---

## Pattern 10: onclick handler 剧集提取

**场景**：用 `onclick` 而非 `<a href>` 传递剧集 ID。

```js
$('li a[onclick]').each((i, el) => {
  const $el = $(el);
  const onclick = $el.attr('onclick') || '';
  const name = $el.text().trim();
  const match = onclick.match(/funcName\(\s*['"]([^'"]+)['"]/);
  if (match && name) {
    tracks.push({
      name: name,
      ext: { epId: match[1] }
    });
  }
});
```

---

## Pattern 11: Inline script JSON 提取（大括号计数法）

**问题**：`lastIndexOf('}')` 会捕获后续 script 标签的 `}`。

```js
function extractJSON(html, varName) {
  const idx = html.indexOf(varName);
  if (idx === -1) return null;
  const braceStart = html.indexOf('{', idx);
  if (braceStart === -1) return null;
  let depth = 0;
  for (let i = braceStart; i < html.length && i < braceStart + 5000; i++) {
    if (html[i] === '{') depth++;
    if (html[i] === '}') depth--;
    if (depth === 0) {
      try { return JSON.parse(html.substring(braceStart, i + 1)); }
      catch { return null; }
    }
  }
  return null;
}
```

---

## Pattern 12: CDN domain 不同于主域名

**场景**：主域返回 SPA shell，CDN 域返回 SSR 内容。

**发现方法**：
1. 检查 `link[rel="canonical"]`
2. 在 HTML 中搜索 CDN URL
3. 用浏览器 network 面板

**解决方案**：用 CDN 域名作为 `SITE`。

---

## Pattern 13: Ad filtering on mixed content pages

```js
$('a.cursor-pointer').each((i, el) => {
  const $el = $(el);
  if ($el.hasClass('tjtagmanager') || $el.attr('target') === '_blank') return;
  const href = $el.attr('href') || '';
  if (!/\/archives\/\d+\//.test(href)) return;  // 只保留内部文章链接
  // ... 提取卡片数据
});
```

---

## Pattern 14: Tag-based search fallback

**场景**：搜索页需要 JS 渲染（SPA），但 tag 页是 SSR。

```js
// 搜索页 SPA 无法解析 → 用 tag 页兜底
const url = `${SITE}/tag/${encodeURIComponent(keyword)}/`;
const { data } = await $fetch.get(url, { headers });
// 按分类列表相同方式解析
```

---

## Pattern 15: Sort via query parameter

```js
async function getCards(ext) {
  const { id, page = 1 } = ext;
  let url;
  if (id === 'hot') {
    url = `${SITE}/list-${page}.htm?sort=hot`;
  } else {
    url = `${SITE}/${id}-${page}.htm`;
  }
}
```

**诊断**：先用 curl 测试 URL 状态码，404 时检查 `?sort=` 或 `?filter=` 参数。

---

## Pattern 16: Audio/Radio 源模式

### CDN 保留测试
```python
from concurrent.futures import ThreadPoolExecutor
def check_url(date_str):
    url = f'https://cdn.com/c_{code}/{date_str}/{code}_{date_str}_{suffix}.m4a'
    r = requests.head(url, headers=headers, timeout=5)
    return (date_str, r.status_code)
with ThreadPoolExecutor(max_workers=20) as ex:
    results = list(ex.map(check_url, test_dates))
```

### 历史 URL 生成
```js
const daysBack = ch.longRetention ? 1095 : 30;
for (let d = 1; d <= daysBack; d++) {
  const dt = new Date(today);
  dt.setDate(dt.getDate() - d);
  const dateStr = dt.toISOString().slice(0, 10).replace(/-/g, '');
  const audioUrl = `https://cdn.com/c_${ch.code}/${dateStr}/${ch.code}_${dateStr}_${ch.suffix}.m4a`;
}
```

**注意**：XPTV 图片加载器不支持 `data:image/...` 数据 URI。

---

## Pattern 17: Douban MiniApp API + 网盘搜索模式

```js
const DOUBAN_API = 'https://frodo.douban.com/api/v2';
const doubanHeaders = {
  'User-Agent': 'Mozilla/5.0 (iPhone; CPU iPhone OS 16_0 like Mac OS X) ... MicroMessenger/8.0.0...',
  'Referer': 'https://servicewechat.com/wx2f9b06c1de1ccfca/84/page-frame.html',
};

// 网盘搜索 API
const SEARCH_API = 'https://so.252035.xyz/api/search';
const url = `${SEARCH_API}?cloud_types=quark,uc,115,aliyun&kw=${encodeURIComponent(keyword)}`;
```

**要点**：
- Douban 必须用 WeChat MiniApp UA，否则返回 code 997
- Referer 中的 wxid（`wx2f9b06c1de1ccfca`）可能随版本变化，如失效请在浏览器 Network 面板中查找正确的 wxid
- 搜索结果 `note`/`title` 可能含 HTML 标签，需 `.replace(/<[^>]+>/g, '')`

---

## Pattern 18: TVBox T4/VOD Source Conversion

### T4 → XPTV 映射
| TVBox | XPTV |
|-------|------|
| `getClasses()` | `getConfig()` tabs |
| `getCategoryList()` | `getCards(ext)` |
| Detail page → play links | `getTracks(ext)` |
| Play handler | `getPlayinfo(ext)` |

### 事件未开始兜底
```js
// getTracks: 检查赛事是否已开始
if (!detail_url || detail_url === SITE || remark === '暂无') {
  return jsonify({
    list: [{ title: name, tracks: [{ name: '比赛尚未开始', ext: { wait: true } }] }]
  });
}
```

### Filter 模式
```js
const filterList = {
  '1': [{ key: 'cateId', name: '类型', value: [{ n: 'NBA', v: '1' }, ...] }],
};

async function getCards(ext) {
  const cateId = ext.filters?.cateId || ext.id;
  // 用 cateId 构建请求
  return jsonify({ list, filter: filterList[ext.id] || [] });
}
```

---

## Pattern 19: TVBox Filter Pattern

XPTV 使用 `filterList` 常量 + `getCards()` 返回 filter：
1. `filterList` 是脚本顶部的独立常量
2. `getConfig()` 返回纯 tab `{ name, ext }`，不含 filter
3. `getCards()` 根据 tab 的 `id` 从 `filterList[id]` 取 filter 返回
4. 用户选择筛选时 `ext.filters.cateId` 覆盖 tab id

---

## Pattern 20: Smart Play API + execB 解密

**识别特征**：播放页有 `const isSmartPlay = true`，`const timestamp`，`const secretKeySeed`。

```js
// execB 解密
function execBDecrypt(encryptedUrl, timestamp) {
  let ct = encryptedUrl;
  // hex → ASCII
  if (/^[0-9a-fA-F]+$/.test(ct) && ct.length % 2 === 0) {
    let s = '';
    for (let i = 0; i < ct.length; i += 2)
      s += String.fromCharCode(parseInt(ct.substr(i, 2), 16));
    ct = s;
  }
  // Key derivation（必须通过运行时 hook 获取）
  const md5Hex = CryptoJS.MD5(timestamp + HIDDEN_SECRET).toString();
  function toHexAscii(s) {
    return Array.from(s).map(c => c.charCodeAt(0).toString(16).padStart(2, '0')).join('');
  }
  const key = CryptoJS.enc.Hex.parse(toHexAscii(md5Hex.slice(16, 32)));
  const iv = CryptoJS.enc.Hex.parse(toHexAscii(md5Hex.slice(0, 16)));
  const dec = CryptoJS.AES.decrypt(ct, key, { iv, mode: CBC, padding: Pkcs7 });
  return dec.toString(CryptoJS.enc.Utf8);
}
```

**要点**：
- `HIDDEN_SECRET` 必须通过 Puppeteer hook 运行时捕获，无法静态还原
- `vkey` = HTML 中 `const playPageUrl` 的值
- `code` = HTML 中 `const secretKeySeed` 的值
- 签名算法常见为 `MD5(String(timestamp))`

---

## Pattern 21: SxxExx 剧集分割（内联下载页）

**用途**：当剧集内联在 HTML 段落中（如 `S05E01.1080P | 百度盘 | 迅雷盘 | 夸克盘`），按剧集标记拆分并关联网盘链接。

```javascript
// Episode extraction by HTML split (SxxExx pattern)
// 支持格式: S01E01, s1e1, EP01, E01
const contentHtml = article.html() || '';
const sections = contentHtml.split(/(?=[Ss]\d{1,2}[Ee]\d{1,2})|(?=[Ee][Pp]?\s*\d{1,3})/);

sections.forEach(section => {
  const epMatch = section.match(/([Ss]\d{1,2}[Ee]\d{1,2}|[Ee][Pp]?\s*\d{1,3})/);
  if (!epMatch) return;
  const epNum = epMatch[1].toUpperCase().replace(/\s+/g, '');
  
  // 提取画质信息（解码 HTML entities 和 URL 编码字符）
  const qualityMatch = section.match(/[Ss]\d{1,2}[Ee]\d{1,2}[.\s]*?([^\s<|]*?(?:P|p)\b|[^\s<|]*?字幕)|[Ee][Pp]?\s*\d{1,3}[.\s]*?([^\s<|]*?(?:P|p)\b|[^\s<|]*?字幕)/);
  const quality = qualityMatch
    ? (qualityMatch[1] || qualityMatch[2] || '').replace(/&amp.*/, '').replace(/&[^;]+;/, '')
    : '';
  const cleanQuality = quality
    ? '.' + decodeURIComponent(quality).replace(/\s+/g, '')
    : '';

  const $section = cheerio.load('<div>' + section + '</div>')('div');
  let firstPan = '';
  
  $section.find('a').each((i, a) => {
    const href = $(a).attr('href') || '';
    if (detectPanType(href) && !firstPan) {
      firstPan = href;
    }
  });

  if (firstPan) {
    tracks.push({
      name: epNum + cleanQuality,
      pan: firstPan,
      ext: {}
    });
  }
});
```

**关键点**：
- 用 `(?=S\d{2}E\d{2})` 正向前瞻断言分割，保留剧集标记
- 画质信息可能含 HTML entities（`&amp;`）和 URL 编码，需双重处理
- 同一剧集段落内可能有多个网盘链接，优先取第一个支持的网盘
- 剧集名格式：`S05E01.中英字幕.1080P`，画质拼接在集号后面

---

## Pattern 22: 多步 MD5 哈希签名循环（直播平台鉴权）

**场景**：直播平台（斗鱼等）的鉴权不是简单 MD5，而是需要多轮迭代哈希。

**来源**：douyu.js 实战逆向

```js
// 从 API 获取加密参数
const encRes = await $fetch.get(`https://www.douyu.com/wgapi/livenc/liveweb/websec/getEncryption?did=${did}`)
const sec = argsify(encRes.data).data

// 多步 MD5 循环签名
let current = sec.rand_str
for (let i = 0; i < sec.enc_time; i++) {
  current = CryptoJS.MD5(current + sec.key).toString()
}
const auth = CryptoJS.MD5(current + sec.key + roomId + timestamp).toString()
```

**关键点**：
- `enc_time` 控制循环次数（通常 3-10 次）
- 每轮用上一轮结果 + 固定 key
- 最终签名拼接 room ID 和时间戳
- `rand_str` 是服务端返回的随机盐值

---

## Pattern 23: 对象转 form-urlencoded 字符串（POST 辅助函数）

**场景**：某些 API 需要 `application/x-www-form-urlencoded` 格式的 POST body，但 `$fetch.post()` 只接受字符串。

**来源**：douyu.js

```js
function toQueryString(obj) {
  return Object.keys(obj)
    .filter(k => obj[k] != null && obj[k] !== '')
    .map(k => `${k}=${obj[k]}`)
    .join('&')
}

// 使用方式
const body = toQueryString({ v: '22032021', did, tt, auth, rate: '0' })
await $fetch.post(url, body, {
  headers: {
    'Content-Type': 'application/x-www-form-urlencoded',
    Referer: 'https://www.douyu.com/' + roomId,
  }
})
```

**对比**：
- ❌ `$fetch.post(url, { key: value })` — 会发送 JSON
- ✅ `$fetch.post(url, 'key=value&k2=v2', { headers })` — form-urlencoded

---

## Pattern 24: 搜索接口 Cookie 注入（动态 DID）

**场景**：搜索 API 校验 Cookie 中的设备 ID，缺少则返回空或拦截。

**来源**：douyu.js

```js
function generateRandomHexString(length) {
  return Array.from({ length }, () => Math.floor(Math.random() * 16).toString(16)).join('')
}

async function search(ext) {
  ext = argsify(ext)
  const text = encodeURIComponent(ext.text)
  const page = ext.page || 1
  const did = generateRandomHexString(32)

  const { data } = await $fetch.get(url, {
    headers: {
      'User-Agent': 'Mozilla/5.0 ...',
      Referer: 'https://www.douyu.com/search/',
      Cookie: `dy_did=${did};acf_did=${did}`,  // ← 关键
    },
  })
  // ...
}
```

**关键点**：
- DID 是 32 位随机 hex 字符串
- Cookie 字段名因平台而异（`dy_did`、`acf_did`、`PHPSESSID` 等）
- 搜索和列表可能用不同的 UA（移动端 vs 桌面端）

---

## Pattern 25: OG 标签元数据提取（详情页信息补充）

**场景**：详情页的封面图和简介不在常规 DOM 中，而在 `<meta>` OG 标签里。

**来源**：libvio.xptv.js

```js
async function getTracks(ext) {
  const resp = await $fetch.get(detailUrl, { headers })
  const $ = cheerio.load(resp.data)
  const info = {}

  // OG 标签提取
  const ogImage = $('meta[property="og:image"]').attr('content') || ''
  if (ogImage) info.vod_pic = ogImage

  info.vod_desc = $('meta[name="description"]').attr('content') || ''

  // 后续解析播放线路...
  return jsonify({ list: lines, info })
}
```

**适用站点**：影视 CMS 类（苹果 CMS、海洋 CMS 变种），封面图常设在 `og:image` 而非 `<img>` 标签。

---

## Pattern 26: 多播放线路 DOM 解析（按分组容器提取）

**场景**：详情页有多个播放源（如"线路一"、"线路二"），每个源下有独立的剧集列表。

**来源**：libvio.xptv.js

```js
// 从 h3 标签提取线路名称
const playFromNames = []
$('.stui-vodlist__head h3').each((_, el) => {
  // .clone().children().remove().end() = 只保留父元素文本，去掉子元素
  const name = $(el).clone().children().remove().end().text().trim()
  if (name && name !== '猜你喜欢') playFromNames.push(name)
})

// 按容器分组提取剧集
$('.stui-content__playlist').each((i, el) => {
  const lineName = playFromNames[i] || '线路' + (i + 1)
  const tracks = []
  $(el).find('li a').each((_, item) => {
    const epName = $(item).text().trim()
    const epLink = $(item).attr('href') || ''
    if (epName && epLink) {
      tracks.push({
        name: epName,
        ext: { url: epLink.startsWith('http') ? epLink : SITE + epLink }
      })
    }
  })
  if (tracks.length > 0) lines.push({ title: lineName, tracks })
})
```

**关键技巧**：
- `.clone().children().remove().end().text()` — 提取纯文本，排除子标签
- 线路名和剧集容器的**顺序必须对应**（h3[0] → playlist[0]）
- 相对 URL 需拼接 `SITE` 前缀

---

## Pattern 27: execB 解密降级链（Smart Play → 直接解密）

**场景**：getPlayinfo 需要多级降级——先尝试 Smart Play API，失败后回退到 player_aaaa 直接解密。

**来源**：libvio.xptv.js 实战

```js
async function getPlayinfo(ext) {
  ext = argsify(ext)
  const playUrl = ext.url.startsWith('http') ? ext.url : SITE + ext.url
  const resp = await $fetch.get(playUrl, { headers })
  const html = resp.data

  // 解析 player_aaaa 变量
  const playerData = extractScriptJSON(html, 'player_aaaa')
  if (!playerData) return jsonify({ urls: [] })

  // 提取 artplayer iframe 中的 timestamp / secretKeySeed / playPageUrl
  const artUrl = SITE + '/static/player/artplayer/?url=' + playerData.url
  const artResp = await $fetch.get(artUrl, { headers: { Referer: playUrl } })
  const artHtml = artResp.data

  const timestamp = (artHtml.match(/const\s+timestamp\s*=\s*"(\d+)"/) || [])[1]
  const secretKeySeed = (artHtml.match(/const\s+secretKeySeed\s*=\s*"([^"]+)"/) || [])[1]
  const vkey = (artHtml.match(/const\s+playPageUrl\s*=\s*"([^"]+)"/) || [])[1]

  if (!timestamp) return jsonify({ urls: [] })

  // ★ 降级链
  // 方案 1: Smart Play API
  if (vkey && secretKeySeed) {
    const apiResp = await callSmartPlayAPI(vkey, secretKeySeed)
    if (apiResp?.code === 200 && apiResp.url) {
      const decrypted = execBDecrypt(apiResp.url, timestamp)
      if (decrypted.startsWith('http')) {
        return jsonify({ urls: [decrypted], headers: [{ 'User-Agent': UA, Referer: playUrl }] })
      }
    }
  }

  // 方案 2: player_aaaa.url 直接解密（encrypt === 3）
  if (playerData.url && playerData.encrypt === 3) {
    const decrypted = execBDecrypt(playerData.url, timestamp)
    if (decrypted.startsWith('http')) {
      return jsonify({ urls: [decrypted], headers: [{ 'User-Agent': UA, Referer: playUrl }] })
    }
  }

  // 全部失败
  return jsonify({ urls: [] })
}
```

**execB 密钥派生（逆向结果，非运行时 hook）**：
```js
function execBDecrypt(encryptedUrl, timestamp) {
  let ct = encryptedUrl
  // hex → raw bytes（如果输入是纯 hex 字符串）
  if (/^[0-9a-fA-F]+$/.test(ct) && ct.length % 2 === 0) {
    let s = ''
    for (let i = 0; i < ct.length; i += 2)
      s += String.fromCharCode(parseInt(ct.substr(i, 2), 16))
    ct = s
  }
  // MD5(timestamp + secret) → 取前 16 字符做 IV，后 16 做 Key
  const md5Hex = CryptoJS.MD5(timestamp + HIDDEN_SECRET).toString()
  const toHexAscii = str => Array.from(str).map(c => c.charCodeAt(0).toString(16).padStart(2, '0')).join('')
  const key = CryptoJS.enc.Hex.parse(toHexAscii(md5Hex.slice(16, 32)))
  const iv = CryptoJS.enc.Hex.parse(toHexAscii(md5Hex.slice(0, 16)))
  try {
    return CryptoJS.AES.decrypt(ct, key, { iv, mode: CryptoJS.mode.CBC, padding: CryptoJS.pad.Pkcs7 })
      .toString(CryptoJS.enc.Utf8)
  } catch { return '' }
}
```

**关键点**：
- `extractScriptJSON()` 用正则从 `<script>` 标签中提取 JSON 变量（见 Pattern 8 的大括号计数法变体）
- artplayer iframe 页面是**独立请求**，含 timestamp 和 secretKeySeed
- `HIDDEN_SECRET` 硬编码在混淆 JS 中，站点更新后可能变化
- hex-to-raw 转换后，MD5 hex 字符串再做 hex-ASCII 编码派生 key/iv — 这是 execB 的特殊之处
