#!/usr/bin/env node

/**
 * XPTV Harness — 本地测试运行器
 *
 * 用法：
 *   node xptv_harness.js smoke <script.xptv.js> [--keyword 测试]
 *   node xptv_harness.js run   <script.xptv.js> --fn getPlayinfo --ext '{"url":"..."}'
 *   node xptv_harness.js list  <script.xptv.js>
 *   node xptv_harness.js analyze <url>
 *
 * smoke:   跑全部 6 个接口的自动测试
 * run:     单步执行指定接口
 * list:    列出脚本实现的接口
 * analyze: 分析目标站点的 API 类型
 */

import { readFileSync, existsSync } from 'fs'
import { resolve, dirname, basename } from 'path'
import { fileURLToPath } from 'url'
import axios from 'axios'
import * as cheerio from 'cheerio'
import CryptoJS from 'crypto-js'

const __dirname = dirname(fileURLToPath(import.meta.url))

// ===== XPTV 运行时模拟 =====

const DEFAULT_TIMEOUT = 20000

const $fetch = {
  get: async (url, options = {}) => {
    const cfg = {
      ...options,
      responseType: 'text',
      timeout: options.timeout || DEFAULT_TIMEOUT,
      validateStatus: () => true,
    }
    const resp = await axios.get(url, cfg)
    return {
      data: resp.data,
      status: resp.status,
      headers: resp.headers || {},
      respHeaders: resp.headers || {},  // 兼容 XPTV 的 respHeaders 访问方式
    }
  },
  download: async (url, options = {}) => {
    const cfg = {
      ...options,
      responseType: 'arraybuffer',
      timeout: options.timeout || DEFAULT_TIMEOUT,
      validateStatus: () => true,
    }
    const resp = await axios.get(url, cfg)
    return {
      data: resp.data,
      status: resp.status,
      headers: resp.headers || {},
      respHeaders: resp.headers || {},
    }
  },
  post: async (url, body, options = {}) => {
    const cfg = {
      ...options,
      responseType: 'text',
      timeout: options.timeout || DEFAULT_TIMEOUT,
      validateStatus: () => true,
    }
    const resp = await axios.post(url, body, cfg)
    return {
      data: resp.data,
      status: resp.status,
      headers: resp.headers || {},
      respHeaders: resp.headers || {},
    }
  },
}

const jsonify = (obj) => JSON.stringify(obj)
const argsify = (str) => {
  if (typeof str === 'object' && str !== null) return str
  return JSON.parse(str)
}
const $print = (...args) => console.log('[XPTV]', ...args)

const _cache = new Map()
const $cache = {
  get: (key) => {
    const entry = _cache.get(key)
    if (!entry) return null
    if (entry.expire > 0 && Date.now() > entry.expire) { _cache.delete(key); return null }
    return entry.value
  },
  set: (key, value, ttlSeconds = 0) => {
    _cache.set(key, { value, expire: ttlSeconds > 0 ? Date.now() + ttlSeconds * 1000 : 0 })
  },
  del: (key) => _cache.delete(key),
}

const $utils = {
  toastInfo: (msg) => console.log(`[TOAST:INFO] ${msg}`),
  toastError: (msg) => console.log(`[TOAST:ERROR] ${msg}`),
  os: () => 'Harness/1.0',
  app: () => '2.0',
}

// ===== 脚本加载 =====

function loadScript(scriptPath) {
  const absPath = resolve(scriptPath)
  if (!existsSync(absPath)) {
    console.error(`Error: File not found: ${absPath}`)
    process.exit(1)
  }

  let code = readFileSync(absPath, 'utf8')

  // 转换 XPTV 内置函数调用为 harness 实现
  code = code.replace(/const\s+CryptoJS\s*=\s*createCryptoJS\(\)\s*;?/g, '')
  code = code.replace(/const\s+cheerio\s*=\s*createCheerio\(\)\s*;?/g, '')

  // 用 Function 构造器模拟 XPTV 沙箱
  const wrapper = new Function(
    '$fetch', 'jsonify', 'argsify', '$print', '$cache', '$utils',
    'CryptoJS', 'cheerio',
    `${code}\n;return { getLocalInfo, getConfig, getCards, getTracks, getPlayinfo, search }`
  )

  const funcs = wrapper($fetch, jsonify, argsify, $print, $cache, $utils, CryptoJS, cheerio)

  // 过滤掉 undefined 的接口
  const available = {}
  for (const [name, fn] of Object.entries(funcs)) {
    if (typeof fn === 'function') available[name] = fn
  }
  return available
}

// ===== 带超时的接口执行 =====

async function runWithTimeout(fn, body, timeoutMs = DEFAULT_TIMEOUT) {
  return Promise.race([
    body !== undefined ? fn(body) : fn(),
    new Promise((_, reject) =>
      setTimeout(() => reject(new Error(`timeout after ${timeoutMs}ms`)), timeoutMs)
    )
  ])
}

// ===== Smoke Test =====

async function smokeTest(scriptPath, opts = {}) {
  const funcs = loadScript(scriptPath)
  const keyword = opts.keyword || 'test'
  const perInterfaceTimeout = opts.timeout || DEFAULT_TIMEOUT
  const results = {}

  const run = async (name, body) => {
    const fn = funcs[name]
    if (!fn) {
      results[name] = { ok: null, summary: 'not implemented' }
      return
    }
    const start = Date.now()
    try {
      const data = await runWithTimeout(fn, body, perInterfaceTimeout)
      const parsed = typeof data === 'string' ? JSON.parse(data) : data
      const ms = Date.now() - start
      let summary = `${ms}ms`
      if (parsed.list) summary += ` | ${parsed.list.length} items`
      if (parsed.tabs) summary += ` | ${parsed.tabs.length} tabs`
      if (parsed.urls) summary += ` | ${parsed.urls.length} urls`
      if (parsed.name) summary += ` | ${parsed.name}`
      if (parsed.ver !== undefined) summary += ` | ver=${parsed.ver}`
      results[name] = { ok: true, summary }
    } catch (err) {
      results[name] = { ok: false, error: err.message, ms: Date.now() - start }
    }
  }

  console.log(`\n🧪 Smoke test: ${basename(scriptPath)}\n`)

  // 1. getLocalInfo
  await run('getLocalInfo')

  // 2. getConfig
  await run('getConfig')

  // 3. getCards — 用 getConfig 的第一个 tab
  let firstTabExt = '{"page":1,"id":"1"}'
  try {
    const cfgData = await runWithTimeout(funcs.getConfig, undefined, perInterfaceTimeout)
    const cfg = typeof cfgData === 'string' ? JSON.parse(cfgData) : cfgData
    if (cfg?.tabs?.[0]?.ext) {
      firstTabExt = JSON.stringify({ ...cfg.tabs[0].ext, page: 1 })
    }
  } catch {}
  await run('getCards', firstTabExt)

  // 4. getTracks — 用 getCards 的第一个结果
  try {
    const cardsData = await runWithTimeout(funcs.getCards, firstTabExt, perInterfaceTimeout)
    const cards = typeof cardsData === 'string' ? JSON.parse(cardsData) : cardsData
    if (cards?.list?.[0]) {
      const trackExt = JSON.stringify({ url: cards.list[0].ext?.url || cards.list[0].vod_id })
      await run('getTracks', trackExt)

      // 5. getPlayinfo — 用 getTracks 的第一个 track
      try {
        const tracksData = await runWithTimeout(funcs.getTracks, trackExt, perInterfaceTimeout)
        const tracks = typeof tracksData === 'string' ? JSON.parse(tracksData) : tracksData
        if (tracks?.list?.[0]?.tracks?.[0]) {
          const playExt = JSON.stringify(tracks.list[0].tracks[0].ext || {})
          await run('getPlayinfo', playExt)
        } else {
          results.getPlayinfo = { ok: null, summary: 'no tracks to test with' }
        }
      } catch {
        results.getPlayinfo = { ok: null, summary: 'getTracks failed, skip' }
      }
    } else {
      results.getTracks = { ok: null, summary: 'no cards to test with' }
      results.getPlayinfo = { ok: null, summary: 'no cards to test with' }
    }
  } catch {
    results.getTracks = { ok: null, summary: 'getCards failed, skip' }
    results.getPlayinfo = { ok: null, summary: 'getCards failed, skip' }
  }

  // 6. search
  await run('search', JSON.stringify({ text: keyword, page: 1 }))

  // 打印结果
  const icons = { true: '✅', false: '❌', null: '⏭️', undefined: '❓' }
  const order = ['getLocalInfo', 'getConfig', 'getCards', 'getTracks', 'getPlayinfo', 'search']
  for (const name of order) {
    const r = results[name] || { ok: undefined, summary: 'missing' }
    const icon = icons[String(r.ok)]
    console.log(`  ${icon} ${name.padEnd(14)} ${r.summary || r.error || ''}`)
  }

  const passed = Object.values(results).filter(r => r.ok === true).length
  const failed = Object.values(results).filter(r => r.ok === false).length
  const skipped = Object.values(results).filter(r => r.ok === null || r.ok === undefined).length
  console.log(`\n  Result: ${passed} passed, ${failed} failed, ${skipped} skipped\n`)

  return { passed, failed, skipped, results }
}

// ===== 单步执行 =====

async function runSingle(scriptPath, fnName, extStr) {
  const funcs = loadScript(scriptPath)
  const fn = funcs[fnName]
  if (!fn) {
    console.error(`Error: Function '${fnName}' not found in script.`)
    console.error(`Available: ${Object.keys(funcs).join(', ') || 'none'}`)
    process.exit(1)
  }

  console.log(`\n▶ ${fnName}(${extStr || ''})\n`)
  const start = Date.now()
  try {
    const data = extStr ? await fn(extStr) : await fn()
    const ms = Date.now() - start
    const parsed = typeof data === 'string' ? JSON.parse(data) : data
    console.log(JSON.stringify(parsed, null, 2))
    console.log(`\n⏱ ${ms}ms`)
  } catch (err) {
    console.error(`❌ Error: ${err.message}`)
    console.error(err.stack)
    process.exit(1)
  }
}

// ===== List interfaces =====

function listInterfaces(scriptPath) {
  const funcs = loadScript(scriptPath)
  console.log(`\n📋 Interfaces in ${basename(scriptPath)}:\n`)
  const all = ['getLocalInfo', 'getConfig', 'getCards', 'getTracks', 'getPlayinfo', 'search']
  for (const name of all) {
    const icon = funcs[name] ? '✅' : '❌'
    console.log(`  ${icon} ${name}`)
  }
  console.log()
}

// ===== Analyze site =====

async function analyzeSite(url) {
  console.log(`\n🔍 Analyzing: ${url}\n`)

  try {
    const { data } = await $fetch.get(url, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
      },
      timeout: 15000,
    })
    const html = typeof data === 'string' ? data : JSON.stringify(data)

    const signals = []

    // MacCMS API
    if (url.includes('/api.php/provide/vod/') || html.includes('api.php/provide/vod')) {
      signals.push('✅ MacCMS API detected (/api.php/provide/vod/)')
    }

    // JSON API
    try {
      const json = typeof data === 'string' ? JSON.parse(data) : data
      if (json.list || json.data || json.results) {
        signals.push('✅ JSON API detected (has list/data/results key)')
      }
    } catch {}

    // HTML 视频列表
    if (html.includes('class="video-item"') || html.includes('class="bs"') || html.includes('class="movie-item"')) {
      signals.push('✅ HTML 视频列表 DOM detected')
    }

    // player_aaaa
    if (html.includes('player_aaaa')) {
      signals.push('✅ player_aaaa found → multi-layer encryption likely')
    }

    // iframe 播放器
    const iframeMatch = html.match(/<iframe[^>]+src=["'][^"']+["']/gi)
    if (iframeMatch && iframeMatch.length > 0) {
      signals.push(`✅ iframe detected (${iframeMatch.length} found) → iframe player pattern`)
    }

    // Smart Play
    if (html.includes('isSmartPlay') || html.includes('secretKeySeed') || html.includes('ticktockwow')) {
      signals.push('✅ Smart Play API detected')
    }

    // Cloudflare
    if (html.includes('challenge-platform') || html.includes('cf-browser-verification') || html.includes('Just a moment')) {
      signals.push('⚠️ Cloudflare protection detected')
    }

    // 验证码
    if (html.includes('安全验证') || html.includes('请输入验证码') || html.includes('verifyBox')) {
      signals.push('⚠️ CAPTCHA/verification page detected')
    }

    // SPA 框架
    if (html.includes('__NUXT__') || html.includes('__NEXT_DATA__') || html.includes('nuxt-link')) {
      signals.push('⚠️ SPA framework detected (Nuxt/Next.js) — cheerio may not see content')
    }

    // jsjiami 混淆
    if (html.includes('jsjiami.com') || html.includes('jsjiami.v')) {
      signals.push('⚠️ jsjiami obfuscation detected — runtime hook needed')
    }

    // 网盘链接
    if (html.includes('pan.quark.cn') || html.includes('alipan.com') || html.includes('115.com') || html.includes('cloud.189.cn')) {
      signals.push('✅ Cloud drive links detected → 网盘源 pattern')
    }

    // 直播流
    if (html.includes('.m3u8') || html.includes('rtmp://') || html.includes('live_url')) {
      signals.push('✅ Live stream URLs detected → 直播源 pattern')
    }

    // WordPress
    if (html.includes('wp-content') || html.includes('wordpress')) {
      signals.push('📝 WordPress site — use data-lazy-src for images')
    }

    if (signals.length === 0) {
      signals.push('❓ No clear signals — may need manual inspection')
    }

    for (const s of signals) {
      console.log(`  ${s}`)
    }

    // 推荐模板
    console.log('\n📋 Recommended template:')
    if (signals.some(s => s.includes('MacCMS'))) {
      console.log('  → Template 1 (MacCMS XML) or Template 4 (JSON API)')
    } else if (signals.some(s => s.includes('Smart Play'))) {
      console.log('  → Template 9 (Smart Play API + execB)')
    } else if (signals.some(s => s.includes('multi-layer'))) {
      console.log('  → Template 7 (multi-layer encryption)')
    } else if (signals.some(s => s.includes('iframe'))) {
      console.log('  → Template 8 (iframe player)')
    } else if (signals.some(s => s.includes('Cloud drive'))) {
      console.log('  → Template 3 (网盘源)')
    } else if (signals.some(s => s.includes('Live stream'))) {
      console.log('  → Template 6 (直播源)')
    } else if (signals.some(s => s.includes('Cloudflare'))) {
      console.log('  → Template 5 (HTML + anti-bot bypass)')
    } else {
      console.log('  → Template 2 (HTML 爬取)')
    }

  } catch (err) {
    console.error(`❌ Failed to fetch ${url}: ${err.message}`)
  }
}

// ===== CLI =====

const args = process.argv.slice(2)
const command = args[0]
const target = args[1]

function usage() {
  console.log(`
XPTV Harness — 本地测试运行器

用法：
  node xptv_harness.js smoke   <script.xptv.js> [--keyword 关键词] [--timeout ms]
  node xptv_harness.js run     <script.xptv.js> --fn <接口名> [--ext '{"..."}']
  node xptv_harness.js list    <script.xptv.js>
  node xptv_harness.js analyze <url>

示例：
  node xptv_harness.js smoke ./my_source.xptv.js
  node xptv_harness.js smoke ./my_source.xptv.js --keyword 龙珠
  node xptv_harness.js smoke ./my_source.xptv.js --timeout 30000
  node xptv_harness.js run ./my_source.xptv.js --fn getCards --ext '{"id":"1","page":1}'
  node xptv_harness.js run ./my_source.xptv.js --fn getPlayinfo --ext '{"url":"/play/xxx-1-1.html"}'
  node xptv_harness.js list ./my_source.xptv.js
  node xptv_harness.js analyze https://example.com
`)
}

if (!command || !target) {
  usage()
  process.exit(0)
}

if (command === 'smoke') {
  const kwIdx = args.indexOf('--keyword')
  const keyword = kwIdx !== -1 ? args[kwIdx + 1] : undefined
  const toIdx = args.indexOf('--timeout')
  const timeout = toIdx !== -1 ? parseInt(args[toIdx + 1]) : undefined
  smokeTest(target, { keyword, timeout }).then(r => process.exit(r.failed > 0 ? 1 : 0))
} else if (command === 'run') {
  const fnIdx = args.indexOf('--fn')
  const extIdx = args.indexOf('--ext')
  if (fnIdx === -1) {
    console.error('Error: --fn <接口名> is required for run command')
    process.exit(1)
  }
  const fnName = args[fnIdx + 1]
  const extStr = extIdx !== -1 ? args[extIdx + 1] : undefined
  runSingle(target, fnName, extStr)
} else if (command === 'list') {
  listInterfaces(target)
} else if (command === 'analyze') {
  analyzeSite(target)
} else {
  console.error(`Unknown command: ${command}`)
  usage()
  process.exit(1)
}
